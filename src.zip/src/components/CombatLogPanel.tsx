import type { GameEventLog } from '../game/gameTypes';
import { displayYear } from '../game/dayCycleClock';
import { resolveCombatLogStage, summarizeCombatEvents } from '../game/eventLog';
import {
  downloadChronicleCSV,
  downloadChronicleJSON,
  downloadChronicleLog,
  type ChronicleExportMeta,
} from '../game/eventLogExport';

interface Props {
  events: GameEventLog[];
  meta: ChronicleExportMeta;
}

const IN_GAME_LIMIT = 500;

function formatLine(evt: GameEventLog): string {
  return `Year ${displayYear(evt.year)}, Day ${evt.day} — ${evt.message}`;
}

// The chronicle array is mutated in place and handed straight in, so a memo keyed on it could never
// see a new line; every value below is derived each render.
export default function CombatLogPanel({ events, meta }: Props) {
  const combatEvents = events.filter((e) => e.type === 'combat');
  const shown = combatEvents.slice(0, IN_GAME_LIMIT);

  const stats = summarizeCombatEvents(combatEvents);

  const exportCombat = () => {
    downloadChronicleLog(combatEvents, { ...meta, villageName: `${meta.villageName} — Combat` });
  };

  if (combatEvents.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-stone-600 bg-stone-800/50 p-3 text-center">
        <p className="text-[13px] text-stone-300">No combat entries yet.</p>
        <p className="mt-1 text-[13px] text-stone-300">
          Raid outcomes after your preparation choices — no battle screen. Entries appear once raids resolve.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-3 gap-1.5 rounded-lg border border-rose-900/40 bg-rose-950/20 p-2">
        <div className="text-center">
          <p className="text-[10px] uppercase tracking-wider text-stone-300">Entries</p>
          <p className="text-sm font-bold text-rose-300">{stats.total}</p>
        </div>
        <div className="text-center">
          <p className="text-[10px] uppercase tracking-wider text-stone-300">Raids launched</p>
          <p className="text-sm font-bold text-amber-300">{stats.raids}</p>
        </div>
        <div className="text-center">
          <p className="text-[10px] uppercase tracking-wider text-stone-300">Defenses resolved</p>
          <p className="text-sm font-bold text-emerald-300">{stats.defended}</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-1">
        <button
          type="button"
          onClick={exportCombat}
          className="rounded border border-stone-600 px-2 py-0.5 text-[13px] text-stone-300 hover:bg-stone-700"
        >
          Download combat .txt
        </button>
        <button
          type="button"
          onClick={() => downloadChronicleJSON(combatEvents, meta)}
          className="rounded border border-stone-600 px-2 py-0.5 text-[13px] text-stone-300 hover:bg-stone-700"
        >
          .json
        </button>
        <button
          type="button"
          onClick={() => downloadChronicleCSV(combatEvents, meta)}
          className="rounded border border-stone-600 px-2 py-0.5 text-[13px] text-stone-300 hover:bg-stone-700"
        >
          .csv
        </button>
      </div>

      <div className="max-h-64 space-y-1 overflow-y-auto rounded-lg border border-stone-700 bg-stone-900/60 p-2">
        {shown.map((evt) => (
          <p key={evt.id} className="text-[13px] leading-relaxed text-rose-200/90">
            <span className="mr-1 font-semibold uppercase text-amber-300/90">[{resolveCombatLogStage(evt) ?? 'combat'}]</span>
            {formatLine(evt)}
          </p>
        ))}
      </div>
      {combatEvents.length > IN_GAME_LIMIT && (
        <p className="text-center text-[10px] text-stone-300">
          Showing latest {IN_GAME_LIMIT} of {combatEvents.length} combat entries (full log in save).
        </p>
      )}
    </div>
  );
}