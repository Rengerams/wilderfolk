import type { WorldState } from '../../game/gameTypes';
import { computeDynasties, isDynasty } from '../../game/familyLegacy';

/** Family legacy — living dynasties: surnames with multiple generations. */
export default function DynastyPanel({ state }: { state: WorldState }) {
  const dynasties = computeDynasties(state);
  /**
   * The chronicle's dynasty rule, read from its owner: three living generations **and** at least
   * three members. The panel used to count two-generation families, so it advertised dynasties the
   * 200-gold chapter refuses and contradicted its own "Three generations alive is a true dynasty."
   */
  const meaningful = dynasties.filter(isDynasty);

  return (
    <div className="rounded-xl border border-violet-600/40 bg-gradient-to-br from-violet-950/40 to-stone-800/50 p-3">
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <h3 className="text-sm font-bold text-violet-300">🌳 Dynasties</h3>
        <span className="font-mono text-[13px] text-stone-400">{meaningful.length}</span>
      </div>
      <p className="mb-2 text-xs leading-relaxed text-stone-300">
        Families that live across generations — founders, children, grandchildren. Three generations alive is a true dynasty.
      </p>
      {meaningful.length === 0 ? (
        <p className="text-[13px] text-stone-600">No multi-generation families yet — let the valley live a while.</p>
      ) : (
        <div className="space-y-1">
          {meaningful.map((d) => (
            <div key={d.surname} className="flex items-center justify-between gap-2 rounded-lg bg-stone-900/40 px-2 py-1.5">
              <div className="min-w-0">
                <p className="text-[13px] font-bold text-stone-200">{d.surname}</p>
                <p className="text-[11px] text-stone-300">{d.members} living family members</p>
              </div>
              <span className="shrink-0 text-xs font-semibold text-violet-300">
                {d.generationsAlive} {d.generationsAlive === 1 ? 'generation' : 'generations'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}