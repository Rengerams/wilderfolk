import { BASS_SCALE, MELODY_SCALE, PHRASE_GAP_MS } from './constants';
import { syncHtmlAudioMute, syncHtmlAudioVolume } from './htmlAudioSync';
import { audioGraph } from './graph';
import { scheduleTone } from './scheduler';
import { musicPlayer } from './trackPlayer';
import { TRACKS, TRACK_VOLUMES } from './tracks';

type PhraseFn = () => void;
const PHRASE_DURATIONS_MS = [5200, 4800, 3600];

function playMelodicPhrase() {
  const melody = [MELODY_SCALE[0], MELODY_SCALE[2], MELODY_SCALE[4], MELODY_SCALE[2], MELODY_SCALE[1], MELODY_SCALE[3], MELODY_SCALE[2], MELODY_SCALE[0]];
  melody.forEach((note, i) => scheduleTone('music', note, 1.1, 0.06, 'sine', i * 0.55));
  [BASS_SCALE[0], BASS_SCALE[2], BASS_SCALE[1], BASS_SCALE[0]].forEach((note, i) => {
    scheduleTone('music', note, 1.8, 0.035, 'triangle', i * 1.1);
  });
}

function playVariationPhrase() {
  const melody = [MELODY_SCALE[2], MELODY_SCALE[4], MELODY_SCALE[5], MELODY_SCALE[4], MELODY_SCALE[3], MELODY_SCALE[1], MELODY_SCALE[0], null];
  melody.forEach((note, i) => { if (note) scheduleTone('music', note, 1.0, 0.055, 'sine', i * 0.5); });
}

function playRestPhrase() {
  scheduleTone('music', MELODY_SCALE[0], 2.2, 0.055, 'sine', 0);
}

const PHRASES: PhraseFn[] = [playMelodicPhrase, playVariationPhrase, playRestPhrase];

class BackgroundMusicPlayer {
  private running = false;
  private spotlightSuspended = false;
  /** Invalidate asynchronous playback requests whenever the soundscape changes. */
  private playbackRevision = 0;
  private usingSamples = false;
  private usingHtmlAudio = false;
  private htmlAudio: HTMLAudioElement | null = null;
  private htmlTrackUrl: string | null = null;
  private phraseIndex = 0;
  private timeout: ReturnType<typeof setTimeout> | null = null;
  private ensurePromise: Promise<void> | null = null;

  get isRunning() {
    return this.running;
  }

  /** One continuous bed after intro — no day/night track swaps. */
  private currentTrack(): { url: string; vol: number } {
    return { url: TRACKS.gameplay, vol: TRACK_VOLUMES.gameplay };
  }

  private isAudible(): boolean {
    if (!this.running || audioGraph.isMuted) return false;
    if (this.usingHtmlAudio) {
      return this.htmlAudio != null && !this.htmlAudio.paused;
    }
    if (this.usingSamples) {
      return audioGraph.isUnlocked && musicPlayer.currentUrl != null;
    }
    return this.timeout != null && audioGraph.isUnlocked;
  }

  syncMute(muted: boolean) {
    syncHtmlAudioMute(this.htmlAudio, muted, this.running && this.usingHtmlAudio);
  }

  /** Re-apply the volume preset to the HTML element this player falls back to. */
  syncVolume() {
    syncHtmlAudioVolume(this.htmlAudio, this.currentTrack().vol, audioGraph.getLevels());
  }

  /** Start or recover gameplay music after unlock, unmute, or entering the map. */
  async ensurePlaying(): Promise<void> {
    if (this.spotlightSuspended) return;
    if (this.ensurePromise) return this.ensurePromise;
    this.ensurePromise = (async () => {
      try {
        if (this.isAudible()) return;
        if (this.running) this.stop();
        await this.start();
      } finally {
        this.ensurePromise = null;
      }
    })();
    return this.ensurePromise;
  }

  private ensureHtmlAudio(url: string): HTMLAudioElement {
    if (!this.htmlAudio || this.htmlTrackUrl !== url) {
      this.stopHtmlAudio();
      this.htmlAudio = new Audio(url);
      this.htmlAudio.loop = true;
      this.htmlAudio.preload = 'auto';
      this.htmlTrackUrl = url;
      this.syncVolume();
    }
    return this.htmlAudio;
  }

  private stopHtmlAudio() {
    if (!this.htmlAudio) return;
    this.htmlAudio.pause();
    this.htmlAudio.currentTime = 0;
    this.htmlAudio = null;
    this.htmlTrackUrl = null;
  }

  private async tryHtmlPlayback(url: string, volume: number, isCurrent: () => boolean): Promise<boolean> {
    if (audioGraph.isMuted) return false;
    const el = this.ensureHtmlAudio(url);
    syncHtmlAudioVolume(el, volume, audioGraph.getLevels());
    try {
      await el.play();
      if (!isCurrent()) {
        el.pause();
        return false;
      }
      this.usingHtmlAudio = true;
      this.usingSamples = false;
      return true;
    } catch {
      return false;
    }
  }

  async start() {
    if (this.spotlightSuspended || this.running) return;
    this.running = true;
    const revision = ++this.playbackRevision;
    const isCurrent = () => this.running && !this.spotlightSuspended
      && revision === this.playbackRevision;
    audioGraph.setMusicBrightness(false);

    const { url, vol } = this.currentTrack();

    if (await this.tryHtmlPlayback(url, vol, isCurrent)) return;
    if (!isCurrent()) return;

    const unlocked = await audioGraph.unlock();
    if (!isCurrent()) return;
    if (unlocked) {
      const ok = await musicPlayer.playLoop(url, 'music', vol, 1.4, isCurrent);
      if (!isCurrent()) return;
      if (ok) {
        this.usingSamples = true;
        this.usingHtmlAudio = false;
        return;
      }
    }

    if (!isCurrent()) return;
    this.usingSamples = false;
    this.usingHtmlAudio = false;
    this.phraseIndex = 0;
    this.scheduleProcedural();
  }

  /** Temporarily hand the music bus to Spotlight, restoring its prior state once. */
  suspendForSpotlight(): () => void {
    if (this.spotlightSuspended) return () => undefined;
    const shouldResume = this.running;
    this.spotlightSuspended = true;
    this.stop();
    let restored = false;
    return () => {
      if (restored) return;
      restored = true;
      this.spotlightSuspended = false;
      if (shouldResume) {
        const pending = this.ensurePromise;
        // An old async start must settle before starting a replacement session.
        if (pending) {
          void pending.then(
            () => { if (!this.spotlightSuspended) void this.ensurePlaying(); },
            () => { if (!this.spotlightSuspended) void this.ensurePlaying(); },
          );
        } else {
          void this.ensurePlaying();
        }
      }
    };
  }

  stop() {
    this.playbackRevision++;
    this.running = false;
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
    this.stopHtmlAudio();
    if (this.usingSamples) musicPlayer.stop(0.8);
    this.usingSamples = false;
    this.usingHtmlAudio = false;
  }

  /**
   * Day/night used to swap tracks and restart the bed (annoying).
   * Keep one continuous loop — mood is only filter/ambience elsewhere if needed.
   */
  async setNightMode(_isNight: boolean) {
    /* no-op: continuous gameplay music */
  }

  private scheduleProcedural() {
    if (!this.running || this.usingSamples || this.usingHtmlAudio) return;
    const current = this.phraseIndex % PHRASES.length;
    if (!audioGraph.isMuted && audioGraph.isUnlocked) PHRASES[current]();
    this.phraseIndex++;
    this.timeout = setTimeout(() => this.scheduleProcedural(), PHRASE_DURATIONS_MS[current] + PHRASE_GAP_MS);
  }
}

export const backgroundMusic = new BackgroundMusicPlayer();