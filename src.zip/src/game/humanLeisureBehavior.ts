import type { Building, Entity, WorldState } from './gameTypes';
import { enterHumanBuilding, commuteHumanToBuilding, venueGatherPosition, crowdGatherPosition, homeStandPosition } from './simulation/humanMovement';
import { faceVelocity, setVelocityToward, steerEntityToward } from './simulation/movementSteering';
import { PER_TICK_RATE_SCALE, TICKS_PER_HOUR } from './dayCycle';
import { getChildCustodian, hasResidenceAssignment } from './housingModel';
import { getWorkSchedule, isOnWorkScheduleShift } from './workSchedule';
import { getHourOfDay, getAbsoluteCalendarDay } from './dayCycleClock';
import { BuildingType } from './buildings';
import { pickSocialImpulse, type SocialBuildingPicker } from './socialLife';
import { isPlayerHuman } from './playerHuman';
import { adjustHumanStaminaFromEnergy } from './simulation/humanPhysiology';
import { requestDialogue } from './dialogueTrees';
import { isDialogueBusy } from './humanChat';
import { prefersHomeTonightFor } from './humanSchedule';
import type { TickContext } from './simulation/simulationTypes';
import { forEachAdaptiveInRadius, socialAdaptiveOptions, SOCIAL_STAGGER, SOCIAL_FRIENDSHIP_RADIUS } from './adaptiveSpatialQuery';
import { seededRandomForRun, personDayRoll } from './simRng';
import { pickBeautySpot } from './beautyGrid';

/** A free child has a 72% chance to choose a nearby playmate each hour. */
const KID_PLAY_CHANCE = 0.72;
const CHILD_PLAYMATE_REFRESH_TICKS = TICKS_PER_HOUR;
const childPlaymateByWorld = new WeakMap<WorldState, WeakMap<Entity, { tickBucket: number; mate?: Entity }>>();

export function tickHumanChildLeisure(args: {
  state: WorldState;
  entity: Entity;
  speed: number;
  hourOfDay: number;
  onSchedule: boolean;
  allHumans: Entity[];
  entityById?: ReadonlyMap<number, Entity>;
  pickSocialBuilding?: SocialBuildingPicker;
  updatedBuildings: Building[];
  buildingById: Map<number, Building>;
  humanSocialGrid: TickContext['humanSocialGrid'];
  width: number;
  height: number;
  livingHumanAt: (id: number | null | undefined) => Entity | undefined;
  suppressIdleInitial: boolean;
}): boolean {
  if (args.onSchedule || !args.entity.isJuvenile || !isPlayerHuman(args.entity)) return args.suppressIdleInitial;
  const { state, entity, speed, hourOfDay, allHumans, updatedBuildings, buildingById, humanSocialGrid, width, height, livingHumanAt } = args;
  let childCache = childPlaymateByWorld.get(state);
  if (!childCache) {
    childCache = new WeakMap();
    childPlaymateByWorld.set(state, childCache);
  }
  const tickBucket = Math.floor(state.tick / CHILD_PLAYMATE_REFRESH_TICKS);
  let cached = childCache.get(entity);
  if (!cached || cached.tickBucket !== tickBucket) {
    const playmates: Entity[] = [];
    forEachAdaptiveInRadius(
      humanSocialGrid,
      allHumans,
      entity.x,
      entity.y,
      SOCIAL_FRIENDSHIP_RADIUS,
      (human) => {
        if (human.id !== entity.id && human.alive && human.isJuvenile && isPlayerHuman(human)) playmates.push(human);
      },
      socialAdaptiveOptions('social', allHumans.length, width, height),
    );
    const mate = playmates.length > 0 && personDayRoll(entity.id, state.tick, 718 + tickBucket) < KID_PLAY_CHANCE
      ? playmates[(entity.id + tickBucket) % playmates.length]
      : undefined;
    cached = { tickBucket, mate };
    childCache.set(entity, cached);
  }
  const mate = cached.mate;
  const impulse = pickSocialImpulse(entity, state, updatedBuildings, [], [], args.pickSocialBuilding);

  if (!impulse.stayHome) {
    if (mate?.alive && Math.hypot(mate.x - entity.x, mate.y - entity.y) <= SOCIAL_FRIENDSHIP_RADIUS) {
      const pdist = Math.hypot(mate.x - entity.x, mate.y - entity.y) || 1;
      if (pdist > 16) {
        setVelocityToward(entity, mate.x, mate.y, speed, 0.7);
      } else {
        entity.vx = Math.sin(state.tick * 0.2 + entity.id) * speed * 0.45;
        entity.vy = Math.cos(state.tick * 0.18 + mate.id) * speed * 0.45;
        if (seededRandomForRun(`chat-kid:${entity.id}:${state.tick}`) < 0.06 * PER_TICK_RATE_SCALE) {
          requestDialogue({
            eventKey: 'child.play', speaker: entity, tick: state.tick,
            selectionRoll: personDayRoll(entity.id, state.tick, 719),
            durationHours: 4 / TICKS_PER_HOUR,
          });
        }
      }
      faceVelocity(entity);
      return true;
    }
  }
  const mother = entity.motherId != null ? livingHumanAt(entity.motherId) : undefined;
  const father = entity.fatherId != null ? livingHumanAt(entity.fatherId) : undefined;
  const freeParent = [mother, father].find((parent) => parent?.alive && isPlayerHuman(parent) && !prefersHomeTonightFor(getWorkSchedule(state), parent.id, state.tick, hourOfDay) && !isOnWorkScheduleShift(state, hourOfDay)) ?? [mother, father].find((parent) => parent?.alive);
  const follow = freeParent ?? getChildCustodian(entity, allHumans, args.entityById);
  if (follow?.alive && personDayRoll(entity.id, state.tick, 601) > 0.22) {
    const distance = Math.hypot(follow.x - entity.x, follow.y - entity.y) || 1;
    if (distance > 22) {
      steerEntityToward(entity, follow.x, follow.y, speed, 0.55);
    } else if (distance > 8) {
      setVelocityToward(entity, follow.x, follow.y, speed, 0.18);
    }
    return true;
  }
  if (hasResidenceAssignment(entity)) {
    const residence = buildingById.get(entity.residenceBuildingId!);
    if (residence?.completed) {
      commuteHumanToBuilding(entity, residence, speed, true);
      return true;
    }
  }
  return args.suppressIdleInitial;
}


export function idleDestination(
  state: WorldState,
  entity: Entity,
  venues: readonly Building[],
  buildingById: ReadonlyMap<number, Building>,
): { x: number; y: number } {
  const roll = personDayRoll(entity.id, state.tick, 812);

  if (roll < 0.34 && hasResidenceAssignment(entity)) {
    const home = buildingById.get(entity.residenceBuildingId!);
    if (home?.completed) return homeStandPosition(home, entity.id);
  }

  if (roll < 0.67 && venues.length > 0) {
    // The nearest of the tick's own venue list — a handful of buildings, not the whole array.
    let best = venues[0];
    let bestDist = Infinity;
    for (const b of venues) {
      const dist = Math.hypot(b.x - entity.x, b.y - entity.y);
      if (dist < bestDist) {
        bestDist = dist;
        best = b;
      }
    }
    return venueGatherPosition(best, entity.id);
  }

  // "Go to a tree": the prettiest ground near them, spread so neighbours do not overlap.
  const pretty = pickBeautySpot(state.beautyGrid ?? null, entity.x, entity.y, 6);
  return crowdGatherPosition(pretty.x, pretty.y, entity.id);
}

export function tickAdultLeisureMotive(args: {
  state: WorldState;
  entity: Entity;
  speed: number;
  allHumans: Entity[];
  pickSocialBuilding?: SocialBuildingPicker;
  updatedBuildings: Building[];
  buildingById: Map<number, Building>;
  humanSocialGrid: TickContext['humanSocialGrid'];
  width: number;
  height: number;
  livingHumanAt: (id: number | null | undefined) => Entity | undefined;
  settlerChat: (entity: Entity, context: 'social' | 'home', chance: number) => void;
  settlerPairChat: (entityA: Entity, entityB: Entity, context: 'social' | 'home', chance: number) => void;
  suppressIdleInitial: boolean;
}): { suppressIdle: boolean; spouseEarly?: Entity } {
  const { state, entity, speed, allHumans, updatedBuildings, buildingById, humanSocialGrid, width, height, livingHumanAt, settlerChat, settlerPairChat } = args;
  // Mourning is leisure, never a reason to leave a paid shift.
  // Deterministically offer rare visits to a grave of a parent, spouse or child.
  if (!isOnWorkScheduleShift(state, getHourOfDay(state.tick)) && state.graveRecords?.length) {
    const day = getAbsoluteCalendarDay(state.tick);
    if (day % 17 === entity.id % 17 && personDayRoll(entity.id, state.tick, 1621) < 0.22) {
      const relative = state.graveRecords.find((grave) =>
        grave.faction === 'player' && grave.deceasedId != null &&
        (grave.deceasedId === entity.motherId || grave.deceasedId === entity.fatherId ||
         grave.deceasedId === entity.partnerId || (entity.childrenIds ?? []).includes(grave.deceasedId))
      );
      const yard = relative ? buildingById.get(relative.graveyardId ?? -1) : undefined;
      if (yard?.completed && yard.type === BuildingType.Graveyard) {
        const spot = venueGatherPosition(yard, entity.id);
        if (Math.hypot(entity.x - spot.x, entity.y - spot.y) > 18) {
          steerEntityToward(entity, spot.x, spot.y, speed * 0.5);
        } else {
          entity.vx *= 0.2;
          entity.vy *= 0.2;
        }
        return { suppressIdle: true };
      }
    }
  }
  const nearbyAdults: Entity[] = [];
  if ((state.tick + entity.id) % SOCIAL_STAGGER === 0) {
    forEachAdaptiveInRadius(humanSocialGrid, allHumans, entity.x, entity.y, SOCIAL_FRIENDSHIP_RADIUS, (h) => {
      if (h.alive && isPlayerHuman(h) && !h.isJuvenile) nearbyAdults.push(h);
    }, socialAdaptiveOptions('social', allHumans.length, width, height));
  }
  const spouseEarly = entity.partnerId != null ? livingHumanAt(entity.partnerId) : undefined;
  if (spouseEarly?.alive && !nearbyAdults.some((h) => h.id === spouseEarly.id)) nearbyAdults.push(spouseEarly);
  const impulse = pickSocialImpulse(entity, state, updatedBuildings, nearbyAdults, [], args.pickSocialBuilding);
  let suppressIdle = args.suppressIdleInitial;
  if (impulse.motive !== 'none') {
    if (impulse.dialogueEvent && seededRandomForRun(`chat-bubble:${entity.id}:${state.tick}`) < 0.08 * PER_TICK_RATE_SCALE && !isDialogueBusy(entity)) {
      requestDialogue({
        eventKey: impulse.dialogueEvent, speaker: entity, tick: state.tick,
        selectionRoll: impulse.dialogueRoll,
        durationHours: 4 / TICKS_PER_HOUR,
      });
    }
    if (impulse.stayHome && hasResidenceAssignment(entity)) {
      const home = buildingById.get(entity.residenceBuildingId!);
      if (home?.completed) {
        commuteHumanToBuilding(entity, home, speed * (impulse.motive === 'sick_day' ? 0.7 : 0.9), true, 1);
        if (impulse.motive === 'sick_day') adjustHumanStaminaFromEnergy(entity, 0.25 * PER_TICK_RATE_SCALE);
        suppressIdle = true;
      }
    } else if (impulse.company?.alive && impulse.building) {
      const b = impulse.building; const cx = b.x + b.width / 2; const cy = b.y + b.height * 0.92;
      const dist = Math.hypot((impulse.company.x + cx) / 2 - entity.x, (impulse.company.y + cy) / 2 - entity.y) || 1;
      if (dist > 16) { steerEntityToward(entity, (impulse.company.x + cx) / 2, (impulse.company.y + cy) / 2, speed, 0.48); } else settlerPairChat(entity, impulse.company, 'home', 0.1);
      suppressIdle = true;
    } else if (impulse.company?.alive) {
      const c = impulse.company; const dist = Math.hypot(c.x - entity.x, c.y - entity.y) || 1;
      if (dist > 16) { steerEntityToward(entity, c.x, c.y, speed, 0.5); }
      else if (impulse.motive === 'comfort_neighbor') { settlerPairChat(entity, c, 'social', 0.12); if (isPlayerHuman(c)) adjustHumanStaminaFromEnergy(c, 0.15 * PER_TICK_RATE_SCALE); }
      else if (impulse.motive === 'care_pregnant') settlerPairChat(entity, c, 'home', 0.12);
      suppressIdle = true;
    } else if (impulse.building) {
      const b = impulse.building;
  
      const spot = venueGatherPosition(b, entity.id);
      const arrived = Math.hypot(entity.x - spot.x, entity.y - spot.y) < 20;
      if (arrived) enterHumanBuilding(entity, b);
      if (!arrived) steerEntityToward(entity, spot.x, spot.y, speed * 0.5);
      else if (impulse.motive === 'sunday_service' || impulse.motive === 'grief' || impulse.motive === 'day_off') { entity.vx *= 0.2; entity.vy *= 0.2; if (seededRandomForRun(`chat-social:${entity.id}:${state.tick}`) < 0.05 * PER_TICK_RATE_SCALE) settlerChat(entity, 'social', 0.1); }
      else if (impulse.motive === 'market_errand' || impulse.motive === 'birthday') { adjustHumanStaminaFromEnergy(entity, 0.2 * PER_TICK_RATE_SCALE); settlerChat(entity, 'social', 0.1); }
      suppressIdle = true;
    }
  }
  return { suppressIdle, spouseEarly };
}