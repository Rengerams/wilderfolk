import { HUMAN_ADULT_MIN_AGE } from './daycycleconstants';
import type { ElectionCeremonyPhase, ElectionCeremonyState, Entity, WorldState } from './gameTypes';
import { maybeOfferValleyDebate } from './storyEvents';
import { recordElectionPromises, tickElectionPromises } from './electionPromises';
import { BuildingType, EntityType } from './gameTypes';
import { DAYS_PER_YEAR, getAgeInYears, TICKS_PER_HOUR } from './dayCycle';
import { isImprisoned } from './housingModel';
import { displayYear } from './dayCycleClock';
import { logEvent } from './eventLog';
import { addNotification } from './simEffects';
import { isPlayerHuman } from './playerHuman';
import { requestDialogue, dialogueHoursFromNominalTicks } from './dialogueTrees';
import { ensureEntitySkills } from './skills';
import { simulateElectionVotes } from './electionVotes';
import { applyLeaderOccupation, syncLeaderHouseResidency } from './leaderHouse';
import { findPlayerTownHall } from './playerTownHall';
import { seededRandomForRun } from './simRng';
import { humanDisplayName } from './citizenId';
import { friendCount, MAX_CLOSE_FRIENDS_PER_SETTLER, startFeud } from './relationships';
import { getEcosystemHealth } from './dailyEcology';
import { computeDynasties } from './familyLegacy';

/**
 * Years between scheduled (end-of-term) elections.
 *
 * 2 = a session-length decision from playtesting, not a lore figure (developer,
 * 2026-09-08: a 10-year term "is like maybe 100 hours real life", and ordinary
 * sessions are not five hours long). Arithmetic behind that: an in-game day is 72
 * real seconds at 1× (`gameLoop.BASE_TICKS_PER_SECOND = 1`, `TICKS_PER_DAY = 72`),
 * so a year is ~7.2 h at 1× and ~2.4 h at a nominal 3× (`SPEED_OPTIONS` in
 * `App.tsx`). Treat the higher multipliers as nominal only: the loop can request at
 * most `MAX_PIPELINE_DEPTH` (4) worker ticks per round-trip, so the achievable rate
 * falls short of the selected one as the colony grows. A 10-year term therefore
 * spans many sittings at any speed a player actually sustains, so most colonies
 * never reached a second election; the term was shortened 10 → 5 → 2 during play so
 * a campaign contains several.
 */
export const ELECTION_INTERVAL_YEARS = 2;
/** 1/6 year = two in-game months between a vacancy and the succession election. */
export const VACANCY_ELECTION_DELAY_YEARS = 1 / 6;
export const ELECTION_PARTY_DAYS: number = 1;
export const ELECTION_PARTY_NAME = 'Election Revelry';

/** Feud score the strongest loser opens against the winner — at most one per election. */
const ELECTION_LOSS_FEUD_SCORE = 30;

// Months are a display division of the one canonical year (`dayCycle`/`dayCycleClock` →
// `gameConstants.Time.DAYS_PER_YEAR`), not a second calendar: the audit flagged the old local
// `DAYS_PER_YEAR = 30 * 12` as a second definition that would drift silently if the year changed.
const MONTHS_PER_YEAR = 12;

/**
 * A ceremony is **one in-game day**, not two in-game months.
 *
 * Owner, 2026-09-30, watching a village that had stood still in a ring around the Town Hall: *"they
 * are in a circle"*, *"they not walking"*, then *"but a ceromeny should maybe take one day?"* and
 * *"not months"*. The gossip beat used to run `GOSSIP_MONTHS = 2` — **two in-game months** — and
 * `humanTick` holds *every eligible adult* at its ring slot for as long as the ceremony is live
 * (`humanTick.ts:722`, `suppressIdle` and `onSchedule` both set), so the village stopped walking,
 * working and eating for a fifth of a year. The gossip itself never needed the hold: it is delivered
 * by `tickElectionGossip` on its own cadence from `tickElectionCeremony`, independent of where anyone
 * stands. An election is a scheduled event `ELECTION_INTERVAL_YEARS` years apart, so a day of
 * assembly is the ceremony the owner asked for, and the ring maths (`getElectionGatherTarget`) is
 * untouched.
 */
const CEREMONY_GATHERING_HOURS = 8;
const CEREMONY_GOSSIP_HOURS = 10;
const CEREMONY_TENSION_HOURS = 6;

function getPhaseTicks(phase: 'gathering' | 'gossip' | 'tension'): number {
  switch (phase) {
    case 'gathering':
      return CEREMONY_GATHERING_HOURS * TICKS_PER_HOUR;
    case 'gossip':
      return CEREMONY_GOSSIP_HOURS * TICKS_PER_HOUR;
    case 'tension':
      return CEREMONY_TENSION_HOURS * TICKS_PER_HOUR;
  }
}

/**
 * Why a leadership election is being held.
 *
 * `term` is the scheduled election that ends a normal term: every
 * ELECTION_INTERVAL_YEARS (2) years, at Years 2, 4, 6, … The token was named
 * `decennial` under the original 10-year term and stopped matching once terms
 * were shortened (5 years, now 2), so it is `term`; `validateVillageLeaderOnLoad`
 * migrates saves that still carry the old token.
 */
export type LeadershipElectionReason = 'founding' | 'term' | 'succession';
export type { ElectionCeremonyPhase, ElectionCeremonyState } from './gameTypes';

export interface LeadershipScoreBreakdown {
  entityId: number;
  name: string;
  totalScore: number;
  skillPoints: number;
  experiencePoints: number;
  battlePoints: number;
  familyPoints: number;
  promisePoints: number;
  communityPoints: number;
  recordPoints: number;
  titlePoints: number;
}

export interface IncumbentRecordAssessment {
  economyPoints: number;
  scandalPoints: number;
  villageHealthPoints: number;
  totalPoints: number;
  scandalCount: number;
  economyStatus: 'good' | 'fair' | 'poor';
  villageStatus: 'good' | 'fair' | 'poor';
  scandalStatus: 'clean' | 'tainted';
}

const RECORD_ECONOMY_GOOD = 6;
const RECORD_ECONOMY_POOR = -6;
const RECORD_SCANDAL_CLEAN = 3;
const RECORD_SCANDAL_EACH = -2;
const RECORD_VILLAGE_GOOD = 4;
const RECORD_VILLAGE_POOR = -6;
const RECORD_POSITIVE_CAP = 12;
const RECORD_NEGATIVE_CAP = -12;
const TITLE_MERIT_BONUS = 30;

/**
 * Merit per year served past adulthood, at the top of the witnessed age range.
 */
const EXPERIENCE_MERIT_PER_YEAR = 0.5;
/** One capped trade is worth 50 merit; expertise across trades is capped at 100. */
const SKILL_MERIT_PER_POINT = 0.5;
const SKILL_MERIT_CAP = 60;
/** Merit per close friendship (`relationships.friendCount`, the ≥60 bond the owner calls a friend). */
const COMMUNITY_MERIT_PER_FRIEND = 2;
/** Merit for being married, the household half of standing. */
const COMMUNITY_MERIT_MARRIED = 8;

export interface ElectionAnnouncement {
  title: string;
  message: string;
  leaderName: string;
  changed: boolean;
  reason: LeadershipElectionReason;
}

export interface ElectionBuildupNotice {
  title: string;
  message: string;
}

/**
 * A leader's or candidate's display name for notices.
 *
 * Delegates to `citizenId.humanDisplayName`, the owner of this format. This was a private copy whose
 * fallback was `'Unknown'`, while `workforce` carried a second copy falling back to `'Settler'` and
 * the owner says `'A settler'` — so one nameless settler had three names depending on which log line
 * mentioned them (`tests/settlerNameFallback.singleOwner.test.ts`).
 */
export function formatSettlerName(entity: Entity): string {
  return humanDisplayName(entity);
}

function leadershipAgeYears(
  entity: Entity,
  state: Pick<WorldState, 'year' | 'dayInYear' | 'tick'>,
): number {
  return Math.max(entity.age, getAgeInYears(entity, state));
}

function assessVillageEconomy(state: WorldState): 'good' | 'fair' | 'poor' {
  const humans = Math.max(1, state.humanPopulation);
  const foodPerCapita = state.resources.food / humans;
  const foodFill = state.storageMax.food > 0 ? state.resources.food / state.storageMax.food : 0;
  const activeTrades = state.tradeRoutes.filter((r) => r.active).length;

  let score = 0;
  if (state.villageReputation >= 50) score += 2;
  else if (state.villageReputation >= 25) score += 1;
  else if (state.villageReputation < 15) score -= 2;

  if (foodPerCapita >= 15) score += 2;
  else if (foodPerCapita < 5) score -= 2;

  if (foodFill >= 0.35) score += 1;
  if (state.resources.gold >= 50) score += 1;
  if (activeTrades >= 2) score += 1;
  else if (activeTrades === 0 && state.year > 5) score -= 1;

  if (score >= 3) return 'good';
  if (score <= -2) return 'poor';
  return 'fair';
}

function assessVillageHealth(state: WorldState): 'good' | 'fair' | 'poor' {
  const humans = Math.max(1, state.humanPopulation);
  const recentDeaths = state.eventLog.filter(
    (e) => e.type === 'death' && e.year >= state.year - 2,
  ).length;

  let score = 0;
  const ecoHealth = getEcosystemHealth(state);
  if (ecoHealth >= 60) score += 1;
  else if (ecoHealth < 30) score -= 2;

  if (state.villageReputation >= 40) score += 1;
  else if (state.villageReputation < 20) score -= 2;

  if (recentDeaths > humans * 0.15) score -= 2;
  if (state.disasters.length > 0) score -= 1;
  if (state.resources.food <= 0 && humans > 3) score -= 2;

  if (score >= 2) return 'good';
  if (score <= -2) return 'poor';
  return 'fair';
}

function scandalEventTargetsLeader(e: { entityName?: string }, leader: Entity): boolean {
  if (!e.entityName) return false;
  const base = leader.name || '';
  const full = leader.surname ? `${base} ${leader.surname}` : base;
  const titled = leader.title ? `${full} ${leader.title}` : full;
  return e.entityName === base || e.entityName === full || e.entityName === titled;
}

function countLeaderScandalsDuringTerm(state: WorldState, leader: Entity): number {
  const sinceYear = state.leaderSinceYear;

  return state.eventLog.filter((e) => {
    if (e.year < sinceYear) return false;
    if (e.type === 'scandal') return scandalEventTargetsLeader(e, leader);
    if (e.type === 'event' && e.message?.includes('imprisoned for scandal')) {
      return scandalEventTargetsLeader(e, leader);
    }
    return false;
  }).length;
}

export function getIncumbentRecordAssessment(
  state: WorldState,
  leader: Entity,
): IncumbentRecordAssessment {
  const economyStatus = assessVillageEconomy(state);
  const villageStatus = assessVillageHealth(state);
  const scandalCount = countLeaderScandalsDuringTerm(state, leader);

  const economyPoints =
    economyStatus === 'good'
      ? RECORD_ECONOMY_GOOD
      : economyStatus === 'poor'
        ? RECORD_ECONOMY_POOR
        : 0;

  const villageHealthPoints =
    villageStatus === 'good'
      ? RECORD_VILLAGE_GOOD
      : villageStatus === 'poor'
        ? RECORD_VILLAGE_POOR
        : 0;

  const scandalPoints =
    scandalCount === 0 ? RECORD_SCANDAL_CLEAN : scandalCount * RECORD_SCANDAL_EACH;

  const rawTotal = economyPoints + scandalPoints + villageHealthPoints;
  const totalPoints = rawTotal > 0
    ? Math.min(rawTotal, RECORD_POSITIVE_CAP)
    : Math.max(rawTotal, RECORD_NEGATIVE_CAP);

  return {
    economyPoints,
    scandalPoints,
    villageHealthPoints,
    totalPoints,
    scandalCount,
    economyStatus,
    villageStatus,
    scandalStatus: scandalCount === 0 ? 'clean' : 'tainted',
  };
}

function getIncumbentRecordPoints(state: WorldState, entity: Entity): number {
  if (state.villageLeaderId !== entity.id) return 0;
  const leader = state.entities.find((e) => e.id === entity.id);
  if (!leader?.alive || !isEligibleForLeadership(leader, state)) return 0;
  return getIncumbentRecordAssessment(state, leader).totalPoints;
}

export function isEligibleForLeadership(
  entity: Entity,
  state?: Pick<WorldState, 'year' | 'dayInYear' | 'tick'>,
): boolean {
  const ageYears = state ? leadershipAgeYears(entity, state) : entity.age;
  return (
    entity.alive &&
    entity.type === EntityType.Human &&
    isPlayerHuman(entity) &&
    !entity.isJuvenile &&
    ageYears >= HUMAN_ADULT_MIN_AGE &&
    !isImprisoned(entity)
  );
}

function familyPrestigeBySurname(state: WorldState): Map<string, number> {
  const prestige = new Map<string, number>();
  for (const family of computeDynasties(state)) {
    const points = Math.min(25, Math.max(0, family.generationsAlive - 1) * 8 + Math.min(9, Math.max(0, family.members - 1)));
    prestige.set(family.surname, points);
  }
  return prestige;
}

export function getLeadershipScoreBreakdown(
  state: WorldState,
  entity: Entity,
  familyPrestige?: ReadonlyMap<string, number>,
): LeadershipScoreBreakdown {
  const skills = ensureEntitySkills(entity);
  const skillSum = Object.values(skills).reduce((sum, value) => sum + (value ?? 0), 0);
  const skillPoints = Math.min(SKILL_MERIT_CAP, Math.round(skillSum * SKILL_MERIT_PER_POINT));
  const ageYears = leadershipAgeYears(entity, state);
  const experiencePoints = Math.round(
    Math.min(Math.max(0, ageYears - HUMAN_ADULT_MIN_AGE), 100) * EXPERIENCE_MERIT_PER_YEAR,
  );

  const communityPoints =
    Math.min(friendCount(entity), MAX_CLOSE_FRIENDS_PER_SETTLER) * COMMUNITY_MERIT_PER_FRIEND +
    (entity.relationshipStatus === 'married' ? COMMUNITY_MERIT_MARRIED : 0);
  const titlePoints = entity.title ? TITLE_MERIT_BONUS : 0;
  const recordPoints = getIncumbentRecordPoints(state, entity);
  const battlePoints = Math.min(100, Math.max(-100, entity.battleLeadershipMerit ?? 0));
  const familyPoints = (familyPrestige ?? familyPrestigeBySurname(state)).get(entity.surname?.trim() ?? '') ?? 0;
  const promisePoints = Math.max(-60, Math.min(60, entity.promiseLeadershipMerit ?? 0));
  const baseScore = skillPoints + experiencePoints + battlePoints + familyPoints + promisePoints + communityPoints + titlePoints;

  return {
    entityId: entity.id,
    name: formatSettlerName(entity),
    skillPoints,
    experiencePoints,
    battlePoints,
    familyPoints,
    promisePoints,
    communityPoints,
    recordPoints,
    titlePoints,
    totalScore: baseScore + recordPoints,
  };
}

/**
 * Shared candidate comparator: ranks by totalScore DESC, age DESC, entityId ASC.
 */
function sortCandidateBreakdowns(
  candidates: LeadershipScoreBreakdown[],
  ageById: Map<number, number>,
): void {
  candidates.sort((a, b) => {
    if (b.totalScore !== a.totalScore) return b.totalScore - a.totalScore;
    const ageA = ageById.get(a.entityId) ?? 0;
    const ageB = ageById.get(b.entityId) ?? 0;
    if (ageB !== ageA) return ageB - ageA;
    return a.entityId - b.entityId;
  });
}

export function rankLeadershipCandidates(state: WorldState): LeadershipScoreBreakdown[] {
  const ageById = new Map<number, number>();
  const familyPrestige = familyPrestigeBySurname(state);
  const candidates: LeadershipScoreBreakdown[] = [];

  for (let i = 0; i < state.entities.length; i++) {
    const entity = state.entities[i];
    if (!isEligibleForLeadership(entity, state)) continue;
    ageById.set(entity.id, leadershipAgeYears(entity, state));
    candidates.push(getLeadershipScoreBreakdown(state, entity, familyPrestige));
  }

  sortCandidateBreakdowns(candidates, ageById);
  return candidates;
}

export function getElectionRaceCandidates(
  state: WorldState,
  displayLimit = 4,
): LeadershipScoreBreakdown[] {
  const ranked = rankLeadershipCandidates(state);
  if (ranked.length === 0) return [];

  const leader = getVillageLeader(state);
  if (!leader) return ranked.slice(0, displayLimit);

  const leaderIdx = ranked.findIndex((b) => b.entityId === leader.id);
  const leaderBreakdown =
    leaderIdx >= 0 ? ranked[leaderIdx] : getLeadershipScoreBreakdown(state, leader);

  const top = ranked.slice(0, displayLimit);
  if (top.some((b) => b.entityId === leader.id)) return top;

  const challengers = ranked.filter((b) => b.entityId !== leader.id).slice(0, displayLimit - 1);
  const race = [...challengers, leaderBreakdown];
  const ageById = new Map(
    state.entities
      .filter((entity) => isEligibleForLeadership(entity, state))
      .map((entity) => [entity.id, leadershipAgeYears(entity, state)] as const),
  );

  sortCandidateBreakdowns(race, ageById);
  return race;
}

/** Determines if an entity currently holds the village head office (vacancy / UI). */
export function isActingVillageHead(
  entity: Entity | null | undefined,
  state?: Pick<WorldState, 'year' | 'dayInYear' | 'tick'>,
): boolean {
  // Imprisonment must not clear the office — scandal sentences keep villageLeaderId
  // and the leader occupation for the whole term. Elections still exclude
  // jailed candidates via isEligibleForLeadership.
  if (!entity || !entity.alive || entity.faction || entity.isJuvenile) {
    return false;
  }

  // Werewolf form check: cursed leader stays acting head while transformed (EJ-10)
  if (entity.type === EntityType.Werewolf && entity.moonHowlerCursed) {
    return true;
  }

  if (isImprisoned(entity)) {
    return entity.type === EntityType.Human && isPlayerHuman(entity);
  }

  // Standard human eligibility check
  return isEligibleForLeadership(entity, state);
}

export function getVillageLeader(state: WorldState): Entity | null {
  if (state.villageLeaderId == null) return null;
  const leader = state.entities.find((e) => e.id === state.villageLeaderId);
  if (!leader || !isActingVillageHead(leader, state)) return null;
  return leader;
}

export function isVillageLeader(state: WorldState, entityId: number): boolean {
  if (state.villageLeaderId !== entityId) return false;
  const leader = state.entities.find((e) => e.id === entityId);
  return leader != null && isActingVillageHead(leader, state);
}

export function getYearsUntilElection(state: WorldState): number {
  if (state.pendingElectionYear != null) {
    const currentFraction = state.year + (state.dayInYear ?? 0) / DAYS_PER_YEAR;
    return Math.max(0, state.pendingElectionYear - currentFraction);
  }
  return getYearsUntilElectionForYear(state.year, state.lastElectionYear);
}

function getYearsUntilElectionForYear(year: number, lastElectionYear: number): number {
  if (year <= 0) return ELECTION_INTERVAL_YEARS;
  const mod = year % ELECTION_INTERVAL_YEARS;
  if (mod === 0 && lastElectionYear === year) return ELECTION_INTERVAL_YEARS;
  return mod === 0 ? 0 : ELECTION_INTERVAL_YEARS - mod;
}

function scoreSummary(b: LeadershipScoreBreakdown): string {
  const parts = [`skills ${b.skillPoints}`, `experience ${b.experiencePoints}`];
  if (b.battlePoints > 0) parts.push(`defense & raids +${b.battlePoints}`);
  if (b.familyPoints > 0) parts.push(`family name +${b.familyPoints}`);
  if (b.promisePoints !== 0) parts.push(`promises ${b.promisePoints > 0 ? '+' : ''}${b.promisePoints}`);
  if (b.titlePoints > 0) parts.push(`title +${b.titlePoints}`);
  if (b.communityPoints > 0) parts.push(`family +${b.communityPoints}`);
  if (b.recordPoints > 0) parts.push(`record +${b.recordPoints}`);
  if (b.recordPoints < 0) parts.push(`record ${b.recordPoints}`);
  return `merit ${b.totalScore} (${parts.join(', ')})`;
}

export function getElectionGatherSite(state: WorldState): { x: number; y: number } {
  const square = state.buildings.find((building) =>
    building.type === 'square' && building.completed && building.faction !== 'rival'
  );
  if (square) return { x: square.x + square.width / 2, y: square.y + square.height / 2 };
  const hall = findPlayerTownHall(state.buildings);
  if (hall) {
    return { x: hall.x + hall.width / 2, y: hall.y + hall.height / 2 };
  }
  return { x: state.width / 2, y: state.height / 2 };
}

export function isElectionCeremonyActive(state: WorldState): boolean {
  return state.electionCeremony != null;
}

const GATHER_SLOTS_PER_RING = 12;

/**
 * How far out the gathering may reach, in rings — beyond this, extra attendees share the rim.
 *
 * Owner, 2026-09-30: *"and why not all are in the circle?"*. Because the ring radius grew **without
 * bound**: `ringRadius = 22 + ring × 14` with `ring = floor(slot / 12)`, so a village of 600 eligible
 * adults was sent to slots up to **708 px** from the hall. At the ceremony's own walk speed (base
 * `speed` × the 1.15 `humanTick` applies) that is roughly **300 ticks of walking**, and the ceremony
 * lasts **70 ticks** (`CEREMONY_*_HOURS` above) — so only the inner two or three rings could ever
 * arrive, and everyone else was still strung out across the village when it ended, which is exactly
 * what the owner was looking at. Capping the rings keeps the crowd beside the hall: reachable in a
 * fraction of the ceremony, and a gathering rather than a ring drawn round half the map.
 *
 * The ring maths is otherwise untouched, so `tests/medium-N5-electionGatherSlot.test.ts` still pins
 * it — that fixture's 15 attendees reach ring 1 and outer ring 2, both inside the cap.
 */
const MAX_GATHER_RING = 4;

/**
 * How many settlers a ceremony actually gathers: two rings' worth, the people the vote is about.
 *
 * Owner, 2026-09-30, after the radius cap above went in: *"they again in a circle"*. Capping the ring
 * radius without capping **who attends** made it worse, not better: the whole village still walked to
 * the hall, so a thousand settlers shared sixty slots and stood in a tight disc — a denser, more obvious
 * circle than the wide rings it replaced. The village population is not the ceremony; a couple of dozen
 * settlers at the hall is, and everyone else has a day's work to do (the hold in `humanTick` now applies
 * to attendees only, so the rest go about their business).
 */
export const CEREMONY_ATTENDEE_LIMIT = GATHER_SLOTS_PER_RING * 2;

/**
 * Whether this settler is one of the ceremony's attendees — the same id-sorted index
 * `getElectionGatherTarget` uses for slot assignment, so "who holds position" and "which slot" can never
 * disagree. One pass, early exit; during a ceremony this runs per settler per tick, which is affordable
 * because a ceremony is a single day (`CEREMONY_*_HOURS`) and elections are `ELECTION_INTERVAL_YEARS`
 * years apart.
 */
/** Live single pass used only without a per-tick seat index; the slot and crowd both saturate. */
function rankCeremonyAttendees(
  state: WorldState,
  entityId: number,
): CeremonyRank {
  let slot = 0;
  let attendeeCount = 0;
  let isAttendee = false;
  for (let i = 0; i < state.entities.length; i++) {
    const entity = state.entities[i];
    if (!isEligibleForLeadership(entity, state)) continue;
    if (attendeeCount < ATTENDEE_COUNT_CAP) attendeeCount++;
    if (entity.id === entityId) isAttendee = slot < CEREMONY_ATTENDEE_LIMIT;
    else if (entity.id < entityId && slot < CEREMONY_ATTENDEE_LIMIT) slot++;
    if (slot >= CEREMONY_ATTENDEE_LIMIT && attendeeCount >= ATTENDEE_COUNT_CAP) break;
  }
  return { slot, attendeeCount, isAttendee };
}

export function isCeremonyAttendee(
  state: WorldState,
  entityId: number,
  seats?: CeremonySeatIndex,
): boolean {
  if (!state.electionCeremony) return false;
  if (seats) return seats.finalistIds.has(entityId) || seats.slots.has(entityId);
  if (state.electionCeremony.finalistIds?.includes(entityId)) return true;
  return rankCeremonyAttendees(state, entityId).isAttendee;
}

/** Radius of the outermost ring, in px. Overflow attendees share it; non-attendees stand just outside. */
const MAX_GATHER_RADIUS_PX = 22 + MAX_GATHER_RING * 14;

/** The outer ring radius stops changing past this crowd size, so counting beyond it is wasted work. */
const ATTENDEE_COUNT_CAP = 32;

/** The id-sorted attendee ranks a ceremony needs, built once per tick instead of per settler. */
export interface CeremonySeatIndex {
  readonly slots: ReadonlyMap<number, number>;
  readonly finalistIds: ReadonlySet<number>;
  readonly attendeeCount: number;
}

/** Where one participant stands during a ceremony. */
export interface CeremonyGatherTarget {
  x: number;
  y: number;
}

interface CeremonyRank {
  slot: number;
  attendeeCount: number;
  isAttendee: boolean;
}

/** One pass over the live entities; `slots` holds the attendee rank below the ceremony limit. */
export function buildCeremonySeatIndex(state: WorldState): CeremonySeatIndex {
  const finalistIds = new Set(state.electionCeremony?.finalistIds ?? []);
  const eligibleIds: number[] = [];
  for (const entity of state.entities) {
    if (isEligibleForLeadership(entity, state)) eligibleIds.push(entity.id);
  }
  eligibleIds.sort((a, b) => a - b);
  const slots = new Map<number, number>();
  const slotCount = Math.min(eligibleIds.length, CEREMONY_ATTENDEE_LIMIT);
  for (let i = 0; i < slotCount; i++) slots.set(eligibleIds[i], i);
  return {
    slots,
    finalistIds,
    attendeeCount: Math.min(eligibleIds.length, ATTENDEE_COUNT_CAP),
  };
}

export function getElectionGatherTarget(
  state: WorldState,
  entityId: number,
  seats?: CeremonySeatIndex,
): CeremonyGatherTarget {
  const c = state.electionCeremony;
  if (!c) return getElectionGatherSite(state);
  const finalistPosition = c.finalistIds?.indexOf(entityId) ?? -1;
  if (finalistPosition >= 0) {
    // Finalists stand in a line at the square's centre, not in the audience rings.
    return { x: c.gatherX + (finalistPosition - 1) * 15, y: c.gatherY - 10 };
  }

  let slot = 0;
  let attendeeCount = 0;
  let isAttendee = false;
  if (seats) {
    slot = seats.slots.get(entityId) ?? 0;
    attendeeCount = seats.attendeeCount;
    isAttendee = seats.slots.has(entityId);
  } else {
    ({ slot, attendeeCount, isAttendee } = rankCeremonyAttendees(state, entityId));
  }

  if (!isAttendee) {
    // Non-attendees (children, the under-18s, prisoners, other factions) ring the outside, one step
    // beyond the crowd — also capped, for the same reason: the venue for this ceremony is the hall's
    // frontage, not a radius measured in map widths.
    const angle = ((entityId * 17) % 360) * (Math.PI / 180);
    const ringRadius = Math.min(22 + Math.ceil(attendeeCount / GATHER_SLOTS_PER_RING) * 14 + 28, MAX_GATHER_RADIUS_PX + 12);
    return {
      x: c.gatherX + Math.cos(angle) * ringRadius,
      y: c.gatherY + Math.sin(angle) * ringRadius,
    };
  }

  // Keep the audience out of the finalists' central platform.
  const ring = Math.floor(slot / GATHER_SLOTS_PER_RING);
  if (ring > MAX_GATHER_RING) {
    // Overflow shares the outermost ring, each on its own stable angle so nobody stacks on a neighbour
    // — the crowd grows denser instead of the circle growing wider.
    const angle = ((entityId * 17) % 360) * (Math.PI / 180);
    return {
      x: c.gatherX + Math.cos(angle) * MAX_GATHER_RADIUS_PX,
      y: c.gatherY + Math.sin(angle) * MAX_GATHER_RADIUS_PX,
    };
  }

  const angleSlot = slot % GATHER_SLOTS_PER_RING;
  const angle = (angleSlot / GATHER_SLOTS_PER_RING) * Math.PI * 2;
  const ringRadius = 22 + ring * 14;

  return {
    x: c.gatherX + Math.cos(angle) * ringRadius,
    y: c.gatherY + Math.sin(angle) * ringRadius,
  };
}

export function findFoundingColonyLeader(state: WorldState): Entity | null {
  const pioneers = state.entities
    .filter((e) => e.alive && isPlayerHuman(e) && !e.isJuvenile)
    .sort((a, b) => a.id - b.id);
  return pioneers.find((e) => e.gender === 'male') ?? pioneers[0] ?? null;
}

export function appointFoundingLeader(state: WorldState, entity: Entity): void {
  const prevLeaderId = state.villageLeaderId;
  state.villageLeaderId = entity.id;
  state.leaderSinceYear = state.year;
  state.lastElectionYear = 0;
  state.pendingElectionYear = null;
  applyLeaderOccupation(state, prevLeaderId);
  syncLeaderHouseResidency(state);

  const name = formatSettlerName(entity);
  logEvent(
    state,
    'election',
    `${name} leads the founding colony until the first merit election (Year ${displayYear(ELECTION_INTERVAL_YEARS)})`,
    name,
  );
}

export function getElectionCeremonyStatus(state: WorldState): string | null {
  // A pending date is a vacancy only while nobody is *acting* as head: a stale date left behind by
  // an election that already filled the office must never be announced as "No village head". The
  // gossip/buildup path already pairs the two this way.
  if (state.pendingElectionYear != null && !state.electionCeremony && !getVillageLeader(state)) {
    const currentFraction = state.year + (state.dayInYear ?? 0) / DAYS_PER_YEAR;
    const until = Math.max(0, state.pendingElectionYear - currentFraction);
    if (until > 0) {
      return `No village head — merit election in ${formatElectionDelay(until)} (Year ${displayYear(Math.floor(state.pendingElectionYear))}).`;
    }
    return 'Leadership election imminent — settlers will gather soon.';
  }

  if (state.electionCeremony) {
    const labels: Record<ElectionCeremonyPhase, string> = {
      gathering: 'The election season begins — settlers gather at the Town Hall.',
      gossip: 'The village debates who should lead, between their own work.',
      tension: 'Voting day — the crowd waits for the result…',
      reveal: 'Announcing the village head!',
    };
    return labels[state.electionCeremony.phase];
  }

  const until = getYearsUntilElection(state);
  if (until === 1) return 'Leadership election next year — settlers are already whispering.';
  if (until === 0) return 'Election this year — ceremony begins on the new year.';
  return null;
}

function pickTopCandidates(state: WorldState, count: number): LeadershipScoreBreakdown[] {
  return getElectionRaceCandidates(state, count);
}

/** Select exactly the former seeded gossip slot, now referencing JSON IDs instead of TS speech. */
function selectElectionGossip(
  state: WorldState,
  tone: 'buildup' | 'ceremony' | 'tension',
): { treeId: string; variables: Record<string, string> } {
  const race = pickTopCandidates(state, 4);
  const leader = getVillageLeader(state);
  const leaderName = leader ? formatSettlerName(leader) : 'our head';
  const challengers = leader ? race.filter((b) => b.entityId !== leader.id) : race;
  const candidateA = challengers[0]?.name ?? race[0]?.name ?? 'someone';
  const candidateB = challengers[1]?.name ?? race[1]?.name ?? 'another';
  const candidateC = challengers[2]?.name ?? race[2]?.name ?? 'a dark horse';
  const record = leader ? getIncumbentRecordAssessment(state, leader) : null;

  const recordIds: string[] = [];
  if (record && tone !== 'tension') {
    const prefix = tone + '_record_';
    if (record.economyStatus === 'good') recordIds.push(prefix + 'economy_good');
    else if (record.economyStatus === 'poor') recordIds.push(prefix + 'economy_poor');
    recordIds.push(prefix + (record.scandalStatus === 'clean' ? 'scandal_clean' : 'scandal_bad'));
    if (record.villageStatus === 'good') recordIds.push(prefix + 'village_good');
    else if (record.villageStatus === 'poor') recordIds.push(prefix + 'village_poor');
  }

  const pool = tone === 'tension'
    ? ['tension_quiet', 'tension_heart', 'tension_merit', 'tension_result']
    : tone === 'buildup'
      ? ['buildup_next_year', 'buildup_a_support', 'buildup_b_watching',
        leader ? 'buildup_buzz_leader' : 'buildup_buzz_no_leader',
        'buildup_after_leader', 'buildup_c_surprise', ...recordIds]
      : leader
        ? ['ceremony_leader_who', 'ceremony_leader_reputation', 'ceremony_leader_challenge',
          'ceremony_leader_hold', 'ceremony_leader_merit', 'ceremony_leader_change',
          'ceremony_leader_b_chance', ...recordIds]
        : ['ceremony_open_who', 'ceremony_open_merit', 'ceremony_open_hall',
          'ceremony_open_change', 'ceremony_open_vote', 'ceremony_open_b_chance'];
  const index = (state.tick * 17 + pool.length * 3) % pool.length;
  return {
    treeId: 'evt_election_' + pool[index],
    variables: { leader: leaderName, candidateA, candidateB, candidateC },
  };
}

export function tickElectionGossip(state: WorldState): void {
  const until = getYearsUntilElection(state);
  const inCeremony = state.electionCeremony != null;
  const vacancyPending = state.pendingElectionYear != null && !getVillageLeader(state);
  if (until > 1 && !inCeremony && !vacancyPending) return;
  if (!state.entities.some((entity) => isEligibleForLeadership(entity, state))) return;

  let chance = 0;
  let tone: 'buildup' | 'ceremony' | 'tension' = 'buildup';

  if (inCeremony) {
    if (state.electionCeremony!.phase === 'tension') {
      chance = 0.35;
      tone = 'tension';
    } else if (
      state.electionCeremony!.phase === 'gossip' ||
      state.electionCeremony!.phase === 'gathering'
    ) {
      chance = 0.28;
      tone = 'ceremony';
    } else {
      return;
    }
  } else if (until === 1) {
    chance = 0.12;
    tone = 'buildup';
  } else if (until === 0 || vacancyPending) {
    chance = vacancyPending ? 0.14 : 0.2;
    tone = 'buildup';
  }

  // Seeded per tick and tone: gossip is part of the chronicle, so the same seed gossips the
  // same way instead of depending on how many other rolls happened first.
  const gossipKey = `election-gossip:${state.tick}:${tone}`;
  if (seededRandomForRun(gossipKey) > chance) return;

  const eligible = state.entities.filter((entity) => isEligibleForLeadership(entity, state));
  const speaker = eligible[Math.floor(seededRandomForRun(`${gossipKey}:speaker`) * eligible.length)];
  if (!speaker) return;

  const gossip = selectElectionGossip(state, tone);
  requestDialogue({
    eventKey: `election.${tone}`, treeId: gossip.treeId, speaker,
    tick: state.tick, priority: 'scripted', variables: gossip.variables,
    durationHours: dialogueHoursFromNominalTicks(110),
  });
}

export function startElectionCeremony(
  state: WorldState,
  year: number,
  reason: LeadershipElectionReason,
): boolean {
  const ranked = rankLeadershipCandidates(state);
  maybeOfferValleyDebate(state, ranked.map((c) => c.name));

  if (ranked.length === 0) {
    logEvent(
      state,
      'election',
      `Leadership election postponed (Year ${displayYear(year)}) — no eligible candidates`,
    );
    return false;
  }

  const electionId = state.nextElectionId ?? 1;
  state.nextElectionId = electionId + 1;
  const nominated = ranked.slice(0, 12);
  const incumbentId = getVillageLeader(state)?.id;
  if (incumbentId != null && !nominated.some((candidate) => candidate.entityId === incumbentId)) {
    const incumbent = ranked.find((candidate) => candidate.entityId === incumbentId);
    if (incumbent) nominated[nominated.length - 1] = incumbent;
  }
  const vote = simulateElectionVotes(state, nominated, electionId);
  const winner = ranked.find((b) => b.entityId === vote.winnerId) ?? ranked[0];
  const site = getElectionGatherSite(state);

  state.electionCeremony = {
    electionId,
    ballotTally: Object.fromEntries(vote.tally),
    ballotTotal: vote.totalVotes,
    ballotWinnerVotes: vote.winnerVotes,
    ballotCast: true,
    phase: 'gathering',
    phaseTicksLeft: getPhaseTicks('gathering'),
    gatherX: site.x,
    gatherY: site.y,
    reason,
    pendingLeaderId: winner.entityId,
    pendingLeaderName: winner.name,
    pendingChanged: state.villageLeaderId !== winner.entityId,
    finalistIds: [...nominated].sort((a, b) => (vote.tally.get(b.entityId) ?? 0) - (vote.tally.get(a.entityId) ?? 0) || b.totalScore - a.totalScore).slice(0, 3).map((candidate) => candidate.entityId),
  };

  const place = state.buildings.some((building) => building.type === 'square' && building.completed && building.faction !== 'rival')
    ? 'the Village Square' : findPlayerTownHall(state.buildings) ? 'the Town Hall' : 'the village center';

  logEvent(
    state,
    'election',
    `Leadership election ceremony began at ${place} (Year ${displayYear(year)})`,
    winner.name,
  );

  /**
   * Tell the player, and let the message take them there.
   *
   * Owner, 2026-09-30: *"an i didnt get a mesage about a election ceremony"* — and they did not: the
   * start wrote a **Chronicle line only**, into the generic Events bucket, while the *buildup* a year
   * earlier did raise a notice. A ceremony that assembles the whole village for a day is exactly the
   * kind of thing this feed is for, and `addNotification`'s `focus` makes the entry clickable onto the
   * gathering site, the same door the priority alerts use.
   */
  addNotification(
    state,
    '🗳️ Election ceremony begins',
    `The village gathers at ${place} to choose its head — a ceremony with gathering, gossip and a vote reveal (Year ${displayYear(year)}).`,
    'event',
    { x: site.x, y: site.y },
  );
  return true;
}

export function tickElectionBuildup(
  state: WorldState,
  electionYear: number,
  yearRollover: boolean,
): ElectionBuildupNotice | null {
  if (!yearRollover || electionYear <= 0) return null;

  const until = getYearsUntilElectionForYear(electionYear, state.lastElectionYear);

  if (until === 1 && state.electionBuildupNotifiedYear !== electionYear) {
    state.electionBuildupNotifiedYear = electionYear;
    return {
      title: '🗳️ Election next year',
      message: `Year ${displayYear(electionYear)} — leadership election next year. Settlers are already whispering about who should lead ${state.villageName}.`,
    };
  }

  return null;
}

function refreshCeremonyPendingLeader(state: WorldState, ceremony: ElectionCeremonyState): void {
  const nominee = state.entities.find((candidate) => candidate.id === ceremony.pendingLeaderId);
  if (nominee && isEligibleForLeadership(nominee, state)) return;
  const eligible = (ceremony.finalistIds ?? []).map((id) => state.entities.find((candidate) => candidate.id === id))
    .filter((candidate): candidate is Entity => !!candidate && isEligibleForLeadership(candidate, state));
  eligible.sort((a, b) => (ceremony.ballotTally?.[String(b.id)] ?? 0) - (ceremony.ballotTally?.[String(a.id)] ?? 0));
  const successor = eligible[0];
  if (!successor) return;
  ceremony.pendingLeaderId = successor.id;
  ceremony.pendingLeaderName = formatSettlerName(successor);
  ceremony.pendingChanged = state.villageLeaderId !== successor.id;
}

function advanceCeremonyPhase(state: WorldState, ceremony: ElectionCeremonyState): void {
  if (ceremony.phase === 'gathering') {
    logEvent(state, 'election', 'Election gathering complete — candidates address the crowd and villagers begin discussing the vote.');
    ceremony.phase = 'gossip';
    ceremony.phaseTicksLeft = getPhaseTicks('gossip');
  } else if (ceremony.phase === 'gossip') {
    logEvent(state, 'election', 'Election discussions conclude — the village awaits the final decision.');
    ceremony.phase = 'tension';
    ceremony.phaseTicksLeft = getPhaseTicks('tension');
  } else if (ceremony.phase === 'tension') {
    logEvent(state, 'election', 'Election ceremony reaches the result announcement.');
    ceremony.phase = 'reveal';
    ceremony.phaseTicksLeft = 1;
  }
  refreshCeremonyPendingLeader(state, ceremony);
}

export function tickElectionCeremony(state: WorldState, year: number): ElectionAnnouncement | null {
  const ceremony = state.electionCeremony;
  if (!ceremony) return null;

  if (ceremony.phase === 'reveal') {
    try {
      refreshCeremonyPendingLeader(state, ceremony);
      const result = runVillageElection(state, year, ceremony.reason);
      const announcement = buildAnnouncement(result, ceremony.reason, year);
      const winner = state.entities.find((e) => e.id === result.leaderId);
      if (winner) {
        winner.flash = 14;
        requestDialogue({
          eventKey: 'election.winner', speaker: winner, tick: state.tick,
          priority: 'scripted',
          durationHours: dialogueHoursFromNominalTicks(140),
        });
      }

      if (announcement) {
        state.festival = {
          active: true,
          name: ELECTION_PARTY_NAME,
          daysLeft: ELECTION_PARTY_DAYS,
        };
        logEvent(
          state,
          'election',
          `Election revelry began — ${ELECTION_PARTY_DAYS} day${ELECTION_PARTY_DAYS === 1 ? '' : 's'} of celebration`,
          result.leaderName,
        );
        // The party is a real festival — production, courtship and immigration are boosted — and it is
        // short, so a Chronicle line alone lets its effects arrive with no word about them.
        addNotification(
          state,
          '🎉 Election revelry!',
          `${ELECTION_PARTY_DAYS === 1 ? 'A day' : `${ELECTION_PARTY_DAYS} days`} of celebration — production, courtship and immigration are boosted while it lasts.`,
          'success',
        );
      }

      // Record v0.6.3 E1 campaign promises now that the leader has officially taken office
      if (result.leaderId != null) {
        recordElectionPromises(state, year);
      }

      return announcement;
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      console.error('[villageLeadership] Election reveal failed:', err);
      logEvent(
        state,
        'election',
        `Leadership election failed (Year ${displayYear(year)}) — ${detail}`,
        ceremony.pendingLeaderName,
      );
      return null;
    } finally {
      state.electionCeremony = null;
    }
  }

  ceremony.phaseTicksLeft--;
  if (ceremony.phaseTicksLeft <= 0) {
    advanceCeremonyPhase(state, ceremony);
    // Tension lasts an hour: its gossip rolls once, on the phase change, not on a clock residue.
    if (ceremony.phase === 'tension') {
      tickElectionGossip(state);
    }
  }

  if (ceremony.phase === 'gossip' && state.tick % 18 === 0) {
    tickElectionGossip(state);
  }

  return null;
}

export function runVillageElection(
  state: WorldState,
  year: number,
  reason: LeadershipElectionReason,
): {
  leaderId: number | null;
  changed: boolean;
  leaderName: string;
  breakdown: LeadershipScoreBreakdown | null;
  votes: { won: number; total: number };
} {
  const ranked = rankLeadershipCandidates(state);
  if (ranked.length === 0) {
    const prevId = state.villageLeaderId;
    const changed = prevId != null;
    state.villageLeaderId = null;
    if (changed) {
      // The reveal deposed the incumbent — step the office down so the stale
      // "leader" label does not outlive the term.
      applyLeaderOccupation(state, prevId);
    }
    // A reveal with no eligible candidate must still schedule the successor
    // election: settlers who come of age or leave prison re-open the race, and
    // the colony must never be left with no path back to a village head.
    if (state.pendingElectionYear == null) {
      const electionYear =
        state.year + (state.dayInYear ?? 0) / DAYS_PER_YEAR + VACANCY_ELECTION_DELAY_YEARS;
      state.pendingElectionYear = electionYear;
      logEvent(
        state,
        'election',
        `Leadership election found no eligible candidate — merit election scheduled for Year ${displayYear(Math.floor(electionYear))}`,
      );
    }
    return {
      leaderId: null,
      changed,
      leaderName: '',
      breakdown: null,
      votes: { won: 0, total: 0 },
    };
  }

  const ceremony = state.electionCeremony;
  const vote = ceremony?.ballotCast && ceremony.ballotTally
    ? { winnerId: ceremony.pendingLeaderId, winnerVotes: ceremony.ballotTally[String(ceremony.pendingLeaderId)] ?? 0, totalVotes: ceremony.ballotTotal ?? 0, tally: new Map(Object.entries(ceremony.ballotTally).map(([id, count]) => [Number(id), count])) }
    : simulateElectionVotes(state, ranked, state.nextElectionId ?? 0);
  const winner = ranked.find((b) => b.entityId === vote.winnerId) ?? ranked[0];
  const prevId = state.villageLeaderId;
  const changed = prevId !== winner.entityId;

  state.lastElectionResult = {
    electionId: ceremony?.electionId ?? state.nextElectionId ?? 0,
    winnerId: winner.entityId,
    ballots: vote.totalVotes,
    tally: Object.fromEntries(vote.tally),
    eligibleVoters: state.entities.filter((person) => person.alive && isPlayerHuman(person) && !person.isJuvenile).length,
    turnout: vote.totalVotes,
  };
  state.villageLeaderId = winner.entityId;
  state.leaderSinceYear = year;
  applyLeaderOccupation(state, prevId);
  syncLeaderHouseResidency(state);

  // Electing a head settles whatever vacancy was pending, so the schedule is cleared here.
  // Without this, a leader who dies or is imprisoned while a ceremony is running leaves the
  // successor date that `tickLeaderVacancy` set for them: the running ceremony then fills the
  // office with that date still armed, `getElectionCeremonyStatus` announces a vacancy nobody has,
  // and `tryStartVacancyElectionCeremony` runs a *second* full ceremony for the filled seat. While
  // the stale date sits there `tickLeaderVacancy` also early-returns, so the next real vacancy would
  // never be scheduled either (docs/private/audits/2026-09-16/LIVE-FINDINGS-STATUS.md, H2).
  state.pendingElectionYear = null;

  if (reason === 'term' || reason === 'founding') {
    state.lastElectionYear = year;
  }

  // The wrong: the strongest settler who lost the race now resents the one who beat them.
  const runnerUp = ranked.find((candidate) => candidate.entityId !== winner.entityId);
  if (runnerUp) {
    const runnerUpEntity = state.entities.find((e) => e.id === runnerUp.entityId);
    const winnerEntity = state.entities.find((e) => e.id === winner.entityId);
    if (runnerUpEntity && winnerEntity) {
      startFeud(state, runnerUpEntity, winnerEntity, ELECTION_LOSS_FEUD_SCORE);
    }
  }

  const ballot = `${vote.winnerVotes} of ${vote.totalVotes} ballots`;
  if (reason === 'founding') {
    logEvent(
      state,
      'election',
      `${winner.name} elected founding village head — ${ballot} · ${scoreSummary(winner)}`,
      winner.name,
    );
  } else if (reason === 'term') {
    logEvent(
      state,
      'election',
      changed
        ? `${winner.name} elected village head (Year ${displayYear(year)}) — ${ballot} · ${scoreSummary(winner)}`
        : `${winner.name} re-elected village head (Year ${displayYear(year)}) — ${ballot} · ${scoreSummary(winner)}`,
      winner.name,
    );
  } else {
    logEvent(
      state,
      'election',
      `${winner.name} succeeded as village head — ${ballot} · ${scoreSummary(winner)}`,
      winner.name,
    );
  }

  return {
    leaderId: winner.entityId,
    changed,
    leaderName: winner.name,
    breakdown: winner,
    votes: { won: vote.winnerVotes, total: vote.totalVotes },
  };
}

function buildAnnouncement(
  result: ReturnType<typeof runVillageElection>,
  reason: LeadershipElectionReason,
  year: number,
): ElectionAnnouncement | null {
  if (!result.leaderName) return null;
  const title =
    reason === 'term'
      ? result.changed
        ? '🗳️ New village head'
        : '🗳️ Head re-elected'
      : '👑 New village head';
  const verb = reason === 'term' && !result.changed ? 're-elected' : 'is now village head';
  const merit = result.breakdown ? scoreSummary(result.breakdown) : '';
  const ballots =
    result.votes.total > 0 ? `${result.votes.won} of ${result.votes.total} ballots · ` : '';

  return {
    title,
    message: `${result.leaderName} ${verb} (Year ${displayYear(year)}). Elected by ballot — ${ballots}${merit}.`,
    leaderName: result.leaderName,
    changed: result.changed,
    reason,
  };
}

/**
 * The one formatter for an election countdown. `getYearsUntilElection` returns a
 * fractional year while a vacancy is pending (`pendingElectionYear` is
 * `currentFraction + VACANCY_ELECTION_DELAY_YEARS`), so no surface may interpolate the
 * raw number — it printed `0.08333333333333333 years`
 * (BUG_REPORTS/2026-09-17-election-countdown-prints-a-fraction.md).
 */
export function formatElectionDelay(years: number): string {
  if (years >= 1) {
    const y = Math.floor(years);
    return y === 1 ? '1 year' : `${y} years`;
  }
  const months = Math.max(1, Math.round(years * MONTHS_PER_YEAR));
  return months === 1 ? '1 month' : `${months} months`;
}

export function tickLeaderVacancy(state: WorldState): ElectionBuildupNotice | null {
  if (state.villageLeaderId != null) {
    const holder = state.entities.find((entity) => entity.id === state.villageLeaderId);
    if (!holder || !holder.alive) state.villageLeaderId = null;
  }
  if (state.pendingElectionYear != null) return null;

  const currentFraction = state.year + (state.dayInYear ?? 0) / DAYS_PER_YEAR;
  const electionYear = currentFraction + VACANCY_ELECTION_DELAY_YEARS;

  const leaderId = state.villageLeaderId;
  if (leaderId == null) {
    // A death handler or old save may already have cleared the office holder.
    // Do not schedule over an active ceremony; its winner will fill this vacancy.
    if (state.electionCeremony) return null;
    state.pendingElectionYear = electionYear;
    const delayText = formatElectionDelay(VACANCY_ELECTION_DELAY_YEARS);
    const message = `The village head seat is vacant. A succession election will take place in ${delayText}.`;
    logEvent(state, 'election', message, 'The village head');
    return { title: '👑 Leadership vacancy', message };
  }

  const leader = state.entities.find((e) => e.id === leaderId);
  if (leader && isActingVillageHead(leader, state)) return null;

  // A death and a non-fatal deposition use the same succession schedule.
  // Announce it even if no candidate is currently eligible; a candidate can emerge
  // during the two-month vacancy.
  // Snapshot the actual living manor residents at the moment the office becomes
  // vacant. Their entitlement must outlive the late leader's entity and relationship
  // cleanup, and survive save/load until a successor takes office.
  const manor = state.buildings.find((building) =>
    building.type === BuildingType.LeaderHouse && building.completed && building.faction !== 'rival');
  state.pendingLeaderHouseResidentIds = manor
    ? state.entities.filter((person) => person.alive && !person.faction
      && person.residenceBuildingId === manor.id).map((person) => person.id)
    : [];
  state.pendingElectionYear = electionYear;
  state.villageLeaderId = null;

  const name = leader ? formatSettlerName(leader) : 'The village head';
  const died = leader != null && !leader.alive;
  const delayText = formatElectionDelay(VACANCY_ELECTION_DELAY_YEARS);
  const message = died
    ? `Village leader ${name} has died. A succession election will take place in ${delayText}. The family may remain in the Leader's House until a successor is elected.`
    : `${name} can no longer lead. A succession election will take place in ${delayText}.`;
  logEvent(state, 'election', message, name);
  return {
    title: died ? '👑 Village leader has died' : '👑 Leadership vacancy',
    message,
  };
}

export function tryStartVacancyElectionCeremony(
  state: WorldState,
  year: number,
  dayInYear: number,
): boolean {
  if (state.pendingElectionYear == null || state.electionCeremony) {
    return false;
  }

  const currentFraction = year + dayInYear / DAYS_PER_YEAR;
  if (currentFraction < state.pendingElectionYear) {
    return false;
  }

  // This is the *vacancy* scheduler: it runs only because `pendingElectionYear` was armed by a death,
  // a deposition or a postponed term election, so its outcome is a succession even when it lands in a
  // term year (Year 2, 4, 6 …). Deriving the label from the year instead made such a handover announce
  // itself as "elected/re-elected village head" and stamp `lastElectionYear` — the year's term slot —
  // for a mid-term change of head (`LIVE-FINDINGS-STATUS.md`, L11).
  const started = startElectionCeremony(state, Math.floor(year), 'succession');
  if (started) {
    state.pendingElectionYear = null;
  } else {
    // `startElectionCeremony` returns false for exactly one reason — its zero-candidate guard — and a
    // past-due pending year is retried every single day the office stays empty, which repeats the
    // postponement notice daily until a settler comes of age. Re-arm the same delay the death path
    // uses, so the office is re-contested on the vacancy rhythm instead of retried once a day.
    state.pendingElectionYear = currentFraction + VACANCY_ELECTION_DELAY_YEARS;
  }
  return started;
}

/** Starts the scheduled end-of-term election when a term year (Year 2, 4, 6, …) begins. */
export function tryStartTermElectionCeremony(
  state: WorldState,
  year: number,
  dayInYear: number,
): boolean {
  if (
    dayInYear !== 0 ||
    year <= 0 ||
    year % ELECTION_INTERVAL_YEARS !== 0 ||
    state.lastElectionYear === year ||
    state.electionCeremony ||
    state.pendingElectionYear != null
  ) {
    return false;
  }
  const started = startElectionCeremony(state, year, 'term');
  if (!started) {
    // `startElectionCeremony` returns false for exactly one reason — its zero-candidate guard — and
    // this gate only opens on `dayInYear === 0`, so without a retry a colony whose adults are all
    // imprisoned or ineligible stays headless until the next term year, two years away. Arm the same
    // delay the death path uses; the retry is then run by `tryStartVacancyElectionCeremony`
    // (`LIVE-FINDINGS-STATUS.md`, L3). The eventual ceremony is labelled a succession, which is what a
    // merit election held to fill an office nobody could contest is.
    state.pendingElectionYear = year + dayInYear / DAYS_PER_YEAR + VACANCY_ELECTION_DELAY_YEARS;
  }
  return started;
}

function isValidElectionCeremony(value: unknown): value is ElectionCeremonyState {
  if (!value || typeof value !== 'object') return false;
  const ceremony = value as Partial<ElectionCeremonyState>;
  const pendingLeaderId: unknown = ceremony.pendingLeaderId;
  const phases: ElectionCeremonyPhase[] = ['gathering', 'gossip', 'tension', 'reveal'];
  return (
    typeof ceremony.phase === 'string' &&
    phases.includes(ceremony.phase as ElectionCeremonyPhase) &&
    typeof ceremony.phaseTicksLeft === 'number' &&
    Number.isFinite(ceremony.phaseTicksLeft) &&
    typeof ceremony.gatherX === 'number' &&
    Number.isFinite(ceremony.gatherX) &&
    typeof ceremony.gatherY === 'number' &&
    Number.isFinite(ceremony.gatherY) &&
    typeof ceremony.reason === 'string' &&
    (pendingLeaderId === null ||
      (typeof pendingLeaderId === 'number' && Number.isFinite(pendingLeaderId))) &&
    typeof ceremony.pendingLeaderName === 'string' &&
    typeof ceremony.pendingChanged === 'boolean'
  );
}

export function validateVillageLeaderOnLoad(state: WorldState): void {
  if (state.electionBuildupNotifiedYear === undefined) {
    state.electionBuildupNotifiedYear = null;
  }
  if (state.electionCeremony === undefined) {
    state.electionCeremony = null;
  } else if (state.electionCeremony != null && !isValidElectionCeremony(state.electionCeremony)) {
    console.warn('[villageLeadership] Corrupted electionCeremony in save — clearing ceremony state');
    state.electionCeremony = null;
  }
  if (state.pendingElectionYear === undefined) {
    state.pendingElectionYear = null;
  }

  // Saves from the 10-year era (and the 5-year era that followed) stored the
  // scheduled election under the name 'decennial'. Terms are ELECTION_INTERVAL_YEARS
  // (2) years and the token is now 'term'; rewrite the old value so ceremony text
  // and re-election wording stay correct for imported saves.
  if (state.electionCeremony != null && (state.electionCeremony.reason as string) === 'decennial') {
    state.electionCeremony.reason = 'term';
  }

  const leader = getVillageLeader(state);
  if (leader) {
    applyLeaderOccupation(state, null);
    syncLeaderHouseResidency(state);
    // Heal a save written while the seat was contested: with an acting head the pending date is
    // stale by definition, and leaving it would suppress both the vacancy notice and every future
    // `tickLeaderVacancy` schedule (LIVE-FINDINGS-STATUS.md, H2).
    state.pendingElectionYear = null;
    return;
  }

  // The office is vacant — the id points at a dead, deposed, or ineligible settler
  // (an imprisoned leader is still acting, so it never reaches this branch). Drop
  // the dangling id so no stale "village head" reference outlives its term; the
  // election scheduling below still runs.
  state.villageLeaderId = null;

  if (state.pendingElectionYear != null) return;

  // A negative year means no election has ever decided the office, so the founding appointment is
  // restored. Year 0 is a real stamp — the founding decision, or a by-election held that year — and
  // a death after either takes the two-month by-election below.
  if (state.lastElectionYear < 0) {
    const founder = findFoundingColonyLeader(state);
    if (founder) appointFoundingLeader(state, founder);
    else {
      const currentFraction = state.year + (state.dayInYear ?? 0) / DAYS_PER_YEAR;
      state.pendingElectionYear = currentFraction + VACANCY_ELECTION_DELAY_YEARS;
    }
  } else {
    const currentFraction = state.year + (state.dayInYear ?? 0) / DAYS_PER_YEAR;
    state.pendingElectionYear = currentFraction + VACANCY_ELECTION_DELAY_YEARS;
  }
}

/**
 * Backward-compatible hook: delegates to electionPromises.ts.
 */
export function setNewLeaderPromise(state: WorldState): void {
  recordElectionPromises(state, state.year);
}

/**
 * Advances evaluation for campaign promises from electionPromises.ts.
 */
export function tickLeaderPromise(state: WorldState): void {
  tickElectionPromises(state);
}
