import { personDayRoll } from './simRng';
import type { WorldState, Building, Entity } from './gameTypes';
import { BuildingType, JobType } from './gameTypes';
import { ticksForDays, TICKS_PER_DAY, getHourOfDay } from './dayCycle';
import { isWorkScheduleHour } from './workSchedule';
import { getWorkSchedule } from './workSchedule';
import { readSkill, rewardProductionSkills, gainSkill } from './skills';
import { addReputation } from './simHelpers';
import { spendFood } from './economyLedger';
import { addFloatingText, addNotification } from './simEffects';
import { logEvent } from './eventLog';
import { getVillageLeader } from './villageLeadership';
import { findPlayerTownHall } from './playerTownHall';
import { isDialogueBusy } from './humanChat';
import { requestDialogue, dialogueHoursFromNominalTicks } from './dialogueTrees';
import { isPlayerHuman } from './playerHuman';
import { HUMAN_NEEDS, creditHumanNutritionFromFood, adjustHumanStaminaFromEnergy } from './simulation/humanPhysiology';

export function getTownHallFestivalCooldownTicks(): number {
  return ticksForDays(50);
}
export const TOWN_HALL_FESTIVAL_COST = { food: 25, gold: 20 };
export const TOWN_HALL_FESTIVAL_DAYS = 14;

export function isTownHallStaffed(buildings: Building[]): boolean {
  const hall = findPlayerTownHall(buildings);
  return !!hall && hall.occupants.length > 0;
}

export function getTownHallOfficialSkillAvg(state: WorldState, hall: Building): number {
  if (hall.occupants.length === 0) return 0;
  let total = 0;
  let count = 0;
  for (const id of hall.occupants) {
    const official = state.entities.find((e) => e.id === id && e.alive);
    if (!official) continue;
    total += readSkill(official, JobType.Official);
    count++;
  }
  return count > 0 ? total / count : 0;
}

/** Active trade routes yield more when civic clerks keep ledgers. */
export function getTownHallTradeMultiplier(state: WorldState, buildings: Building[]): number {
  const hall = findPlayerTownHall(buildings);
  if (!hall || hall.occupants.length === 0) return 1;
  const skill = getTownHallOfficialSkillAvg(state, hall);
  return 1 + Math.min(0.3, hall.occupants.length * 0.06 + skill * 0.0015);
}

/** Immigration rolls are more likely with an open town hall. */
export function getTownHallImmigrationMultiplier(buildings: Building[]): number {
  return isTownHallStaffed(buildings) ? 1.35 : 1;
}

/** Village-wide production efficiency when officials govern. */
export function getTownHallGovernanceEfficiency(state: WorldState, buildings: Building[]): number {
  const hall = findPlayerTownHall(buildings);
  if (!hall || hall.occupants.length === 0) return 1;
  let mult = 1.05 + hall.occupants.length * 0.02;
  const leader = getVillageLeader(state);
  if (leader && hall.occupants.includes(leader.id)) {
    mult += 0.05;
  }
  return Math.min(1.18, mult);
}

/** Scandals hurt less when the village has functioning civic leadership. */
export function dampScandalReputationLoss(delta: number, buildings: Building[]): number {
  if (!isTownHallStaffed(buildings) || delta >= 0) return delta;
  return Math.round(delta * 0.65);
}

/** Extra refugees admitted on a full welcome when the town hall is staffed. */
export function getRefugeeWelcomeBonus(buildings: Building[]): number {
  return isTownHallStaffed(buildings) ? 1 : 0;
}

export function tickTownHallCivic(
  state: WorldState,
  building: Building,
  _playerHumans: Entity[],
): void {
  const officials = building.occupants.length;
  addReputation(state, 3 + Math.max(0, officials - 1));

  rewardProductionSkills(state, building, 0.25);
}

export function canHostTownFestival(
  state: WorldState,
  building: Building,
): { ok: boolean; reason?: string } {
  if (building.type !== BuildingType.TownHall || !building.completed) {
    return { ok: false, reason: 'Not a town hall' };
  }
  if (building.occupants.length === 0) {
    return { ok: false, reason: 'Assign an official first' };
  }
  if (state.festival?.active) {
    return { ok: false, reason: 'A festival is already running' };
  }
  if (state.tick < (state.townHallFestivalCooldownUntilTick ?? 0)) {
    return { ok: false, reason: 'Town festival on cooldown' };
  }
  if (state.resources.food < TOWN_HALL_FESTIVAL_COST.food) {
    return { ok: false, reason: `Need ${TOWN_HALL_FESTIVAL_COST.food} food` };
  }
  if (state.resources.gold < TOWN_HALL_FESTIVAL_COST.gold) {
    return { ok: false, reason: `Need ${TOWN_HALL_FESTIVAL_COST.gold} gold` };
  }
  return { ok: true };
}

export function hostTownFestival(originalState: WorldState, buildingId: number): WorldState {
  const state = structuredClone(originalState);
  const building = state.buildings.find((b) => b.id === buildingId);
  if (!building) return originalState;

  const check = canHostTownFestival(state, building);
  if (!check.ok) {
    addNotification(state, 'Cannot host festival', check.reason ?? 'Unavailable', 'warning');
    return state;
  }

  spendFood(state, 'festival', TOWN_HALL_FESTIVAL_COST.food);
  state.resources.gold -= TOWN_HALL_FESTIVAL_COST.gold;
  state.festival = { active: true, name: 'Town Hall Festival', daysLeft: TOWN_HALL_FESTIVAL_DAYS };
  addReputation(state, 6);
  state.townHallFestivalCooldownUntilTick = state.tick + getTownHallFestivalCooldownTicks();
  addNotification(
    state,
    'Town Festival',
    `Officials hosted ${TOWN_HALL_FESTIVAL_DAYS} days of revelry — production & immigration boosted`,
    'success',
  );
  logEvent(state, 'season', 'Town Hall hosted a village festival');
  return state;
}

export function describeTownHallPerks(building: Building): string {
  if (building.occupants.length === 0) {
    return 'Assign officials (Official job) to support trade, immigration, and festivals. Settlers petition the hall for aid & audiences.';
  }
  return 'Every 3 days: +rep · trade · immigration · efficiency · softer scandals · petitions & leader audiences · host festivals below';
}

export function isOfficialAtHall(
  entity: Entity,
  buildings: readonly Building[],
): Building | undefined {
  if (entity.job !== JobType.Official || entity.workerBuildingId == null) return undefined;
  const hall = buildings.find((b) => b.id === entity.workerBuildingId);
  if (!hall || hall.type !== BuildingType.TownHall || !hall.completed) return undefined;
  return hall;
}

/** Settler wants civic attention (dispute, aid, gossip, leader). */
export function wantsCivicAudience(entity: Entity, state: WorldState): boolean {
  if (!isPlayerHuman(entity) || entity.isJuvenile) return false;
  if (entity.job === JobType.Official) return false;
  if ((entity.griefUntilTick ?? 0) > state.tick) return true;
  if (state.resources.food < Math.max(40, state.humanPopulation * 2)
    && (entity.needs?.nutrition ?? 100) < HUMAN_NEEDS.EAT_ENTER_NUTRITION) {
    return true;
  }
  if ((entity.scandalCooldownUntilTick ?? 0) > state.tick) return true;
  return personDayRoll(entity.id, state.tick, 820) < 0.18;
}

export type CivicPetitionResult =
  | { kind: 'aid_food'; amount: number }
  | { kind: 'aid_gold'; amount: number }
  | { kind: 'heard'; }
  | { kind: 'leader_audience' }
  | { kind: 'none' };

/**
 * Settler petitions a staffed town hall — small aid, comfort, or leader audience.
 * Call when the settler is near the hall during free time or civic hours.
 */
export function resolveCivicPetition(
  state: WorldState,
  petitioner: Entity,
  hall: Building,
): CivicPetitionResult {
  if (!hall.completed || hall.occupants.length === 0) return { kind: 'none' };
  if (!isPlayerHuman(petitioner) || petitioner.isJuvenile) return { kind: 'none' };

  const hx = hall.x + hall.width / 2;
  const hy = hall.y + hall.height * 0.9;
  if (Math.hypot(petitioner.x - hx, petitioner.y - hy) > 52) return { kind: 'none' };

  const day = Math.floor(state.tick / TICKS_PER_DAY);
  if (personDayRoll(petitioner.id, state.tick, 821 + day) > 0.4) return { kind: 'none' };

  const leader = getVillageLeader(state);
  const leaderHere =
    leader
    && hall.occupants.includes(leader.id)
    && Math.hypot(leader.x - hx, leader.y - hy) < 50;

  const hour = getHourOfDay(state.tick);
  const openHours = isWorkScheduleHour(getWorkSchedule(state), hour) || (hour >= 16 && hour < 19);

  if (!openHours && !leaderHere) return { kind: 'none' };

  for (const id of hall.occupants) {
    gainSkill(state, id, JobType.Official, 0.06);
  }

  // Food hardship → small food relief
  if (
    state.resources.food >= 8
    && state.resources.food < state.humanPopulation * 3
    && (petitioner.needs?.nutrition ?? 100) < HUMAN_NEEDS.EAT_ENTER_NUTRITION
    && personDayRoll(petitioner.id, state.tick, 822) < 0.45
  ) {
    const amount = Math.min(4, Math.floor(state.resources.food * 0.02) + 1);
    const spent = spendFood(state, 'petition', amount);
    if (spent <= 0) return { kind: 'none' };
    creditHumanNutritionFromFood(petitioner, spent);
    addFloatingText(state, petitioner.x, petitioner.y - 14, `+${spent} food (aid)`, '#86efac', 'brief');
    requestDialogue({ eventKey: 'townHall.foodAid', speaker: petitioner, tick: state.tick, selectionRoll: personDayRoll(petitioner.id, state.tick, 831), durationHours: dialogueHoursFromNominalTicks(50), priority: 'scripted' });
    addReputation(state, 1);
    return { kind: 'aid_food', amount: spent };
  }

  // Scandal / grief → being heard
  if (
    ((petitioner.griefUntilTick ?? 0) > state.tick
      || (petitioner.scandalCooldownUntilTick ?? 0) > state.tick)
    && personDayRoll(petitioner.id, state.tick, 823) < 0.55
  ) {
    adjustHumanStaminaFromEnergy(petitioner, 6);
    requestDialogue({ eventKey: 'townHall.heard', speaker: petitioner, tick: state.tick, selectionRoll: personDayRoll(petitioner.id, state.tick, 832), durationHours: dialogueHoursFromNominalTicks(52), priority: 'scripted' });
    addFloatingText(state, hall.x + hall.width / 2, hall.y - 10, '📜 Petition heard', '#93c5fd', 'brief');
    addReputation(state, 1);
    return { kind: 'heard' };
  }

  // Leader audience. Both lines are gated on `isDialogueBusy`: the petitioner's line had no gate at
  // all (it could abandon any pair the petitioner was mid-way through), and the leader's used a raw
  // `chatTicks` counter that reads the idle half of a live session as free (2026-09-20 audit,
  // F-chat-2). Same rule as `hotelStay`/`hospitalCare`. The gates wrap the *lines* only — the
  // audience itself still happens and still grants its reputation.
  if (leaderHere && personDayRoll(petitioner.id, state.tick, 824) < 0.35) {
    if (!isDialogueBusy(petitioner)) {
      requestDialogue({ eventKey: 'townHall.audience.petitioner', speaker: petitioner, tick: state.tick, selectionRoll: personDayRoll(petitioner.id, state.tick, 833), durationHours: dialogueHoursFromNominalTicks(48) });
    }
    if (!isDialogueBusy(leader)) {
      requestDialogue({ eventKey: 'townHall.audience.leader', speaker: leader, tick: state.tick, selectionRoll: personDayRoll(leader.id, state.tick, 834), durationHours: dialogueHoursFromNominalTicks(48) });
    }
    addReputation(state, 1);
    return { kind: 'leader_audience' };
  }

  // Generic civic visit — small gold stipend for very poor days
  if (
    state.resources.gold >= 5
    && personDayRoll(petitioner.id, state.tick, 825) < 0.2
    && (petitioner.needs?.stamina ?? petitioner.energy / Math.max(1, petitioner.maxEnergy) * 100) < 60
  ) {
    const amount = 1;
    state.resources.gold -= amount;
    adjustHumanStaminaFromEnergy(petitioner, 5);
    addFloatingText(state, petitioner.x, petitioner.y - 12, '🪙 Stipend', '#fde047', 'brief');
    requestDialogue({ eventKey: 'townHall.goldAid', speaker: petitioner, tick: state.tick, durationHours: dialogueHoursFromNominalTicks(40), priority: 'scripted' });
    return { kind: 'aid_gold', amount };
  }

  if (personDayRoll(petitioner.id, state.tick, 826) < 0.25) {
    requestDialogue({ eventKey: 'townHall.generic', speaker: petitioner, tick: state.tick, selectionRoll: personDayRoll(petitioner.id, state.tick, 835), durationHours: dialogueHoursFromNominalTicks(40), priority: 'scripted' });
    return { kind: 'heard' };
  }

  return { kind: 'none' };
}

/**
 * Official on duty greets the nearest petitioner.
 */
export function officialHandlePetitioners(
  state: WorldState,
  official: Entity,
  hall: Building,
  villagers: readonly Entity[],
): boolean {
  const hx = hall.x + hall.width / 2;
  const hy = hall.y + hall.height * 0.9;
  if (Math.hypot(official.x - hx, official.y - hy) > 48) return false;

  const petitioners = villagers.filter(
    (v) =>
      v.id !== official.id
      && v.alive
      && isPlayerHuman(v)
      && !v.isJuvenile
      && Math.hypot(v.x - hx, v.y - hy) < 55
      && wantsCivicAudience(v, state),
  );
  if (petitioners.length === 0) return false;

  if (!isDialogueBusy(official) && personDayRoll(official.id, state.tick, 836) < 0.4) {
    requestDialogue({ eventKey: 'townHall.official', speaker: official, tick: state.tick, selectionRoll: personDayRoll(official.id, state.tick, 837), durationHours: dialogueHoursFromNominalTicks(44) });
  }
  return true;
}

/**
 * Daily civic pulse beyond taxes — clear a few petitions symbolically for villagers near hall.
 */
export function tickTownHallAudiences(
  state: WorldState,
  hall: Building,
  playerHumans: Entity[],
): void {
  if (!hall.completed || hall.occupants.length === 0) return;
  let handled = 0;
  const adults = playerHumans.filter((h) => h.alive && !h.isJuvenile);
  for (const h of adults) {
    if (handled >= 2) break;
    if (!wantsCivicAudience(h, state)) continue;
    const r = resolveCivicPetition(state, h, hall);
    if (r.kind !== 'none') handled++;
  }
  if (handled > 0 && personDayRoll(handled, state.tick, 838) < 0.5) {
    logEvent(state, 'event', `Town Hall heard ${handled} petition${handled > 1 ? 's' : ''}`);
  }
}