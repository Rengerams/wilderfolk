import { resolveWarPrisoner } from '../warPrisoners';
import { demolishBuildingInPlace, demolishStripBuildingsInPlace, toggleWallGate } from '../buildingMaintenanceActions';

import type { WorldState, ForgeOrderId } from '../gameTypes';
import { BuildingType } from '../gameTypes';
import type { HuntingSpotPrey } from '../gameTypes';
import { isValidHuntingSpotPrey } from '../huntingSpots';
import type { BuildingRotation } from '../buildingRotation';
import { MINE_ORES, type MineMode } from '../buildings';
import { MAX_STRIP_SEGMENTS, type StripSegment } from '../stripBuild';
import { VISITOR_TRADE_COSTS, type VisitorTradeAction, type RefugeeChoice, type VillageRequestChoiceId, resolveVillageRequest, talkToVisitorLeader, tradeWithVisitors, negotiateRefugees } from '../groupEvents';
import { sendRivalGift, establishRivalTradePact, showStrengthToRival, signPeaceTreaty, respondToDiplomacyEvent } from '../rivalDiplomacy';
import { setWorkSchedule, validateWorkSchedule } from '../workSchedule';
import { setVenueSchedule, validateVenueSchedule, type VenueScheduleKind } from '../venueSchedule';
import {
  isWorkforcePreset,
  setWorkforcePolicy,
  type WorkforcePreset,
} from '../workforcePolicy';
import { startBuilding, placeStripChain } from '../buildingPlacementActions';
import { assignIdleWorkerToBuilding, removeWorkerFromBuilding } from '../buildingActionRouting';
import { fillBuildingWorkers, autoStaffAllWorkers } from '../buildingStaffingActions';
import { repairBuilding, repairBuildings, upgradeBuilding } from '../buildingMaintenanceActions';
import { setWorkshopRecipe, setHuntingSpotPrey, setMineMode, setBuildingStaffingMode } from '../buildingConfigurationActions';
import { recruitSettler, tameEntity, spawnMoonHowlerDebug } from '../settlerInteractionActions';
import { FORGE_ORDERS, queueForgeOrder } from '../forge';
import { notifyBuildingLocked, startResearch } from '../research';
import { establishTradeRoute } from '../tradeCaravans';
import { addBigNews, addFloatingText } from '../simEffects';
import { deliverVisitorQuest } from '../visitorQuest';
import { respondToOutgoingRaidEvent, resolveRaidVictory, queueRaidDefense, launchRaidOnRival, provokeRival } from '../frontierCombat';
import { respondToStoryEvent } from '../storyEvents';
import { startGuidedCampaign } from '../guidedCampaign';
import { hostTownFestival } from '../townHall';
import { finishSpotlightLore, startSpotlightLoreDebug } from '../spotlightLore';
import {
  extractSimTickDelta,
  createFallbackSimTickDelta,
  type SimTickDelta,
} from '../simBuffers/simDelta';

export const WORKER_CMD_PROTO = 1;

/** Versioned main → worker command channel (Rule 6). */
export type WorkerCommand =
  | { proto: 1; op: 'startBuilding'; type: BuildingType; x: number; y: number; rotation?: BuildingRotation }
  | { proto: 1; op: 'placeStripChain'; type: BuildingType; segments: readonly StripSegment[]; rotation?: BuildingRotation }
  | { proto: 1; op: 'assignWorker'; buildingId: number; humanId?: number }
  | { proto: 1; op: 'autoStaffWorkers' }
  | { proto: 1; op: 'removeWorker'; buildingId: number; humanId: number }
  | { proto: 1; op: 'repairBuilding'; buildingId: number }
  | { proto: 1; op: 'repairBuildings'; buildingIds: number[] }
  | { proto: 1; op: 'upgradeBuilding'; buildingId: number }
  | { proto: 1; op: 'demolishBuilding'; buildingId: number }
  | { proto: 1; op: 'toggleWallGate'; buildingId: number }
  | { proto: 1; op: 'demolishStripBuildings'; buildingIds: number[] }
  | { proto: 1; op: 'setWorkshopRecipe'; buildingId: number; recipeId: string }
  | { proto: 1; op: 'setHuntingSpotPrey'; buildingId: number; prey: HuntingSpotPrey }
  | { proto: 1; op: 'setMineMode'; buildingId: number; mode: MineMode }
  | { proto: 1; op: 'setBuildingStaffingMode'; buildingId: number; mode: 'auto' | 'manual' }
  | { proto: 1; op: 'queueForgeOrder'; buildingId: number; orderId: ForgeOrderId }
  | { proto: 1; op: 'recruitSettler' }
  | { proto: 1; op: 'tameEntity'; entityId: number; humanId: number }
  | { proto: 1; op: 'notifyBuildingLocked'; type: BuildingType }
  | { proto: 1; op: 'resolveWarPrisoner'; entityId: number; choiceId: string }
  | { proto: 1; op: 'respondToRaidEvent'; eventId: string; choiceId: string }
  | { proto: 1; op: 'respondToOutgoingRaidEvent'; eventId: string; choiceId: string }
  | { proto: 1; op: 'resolveRaidVictory'; eventId: string; choiceId: string }
  | { proto: 1; op: 'respondToDiplomacyEvent'; eventId: string; choiceId: string }
  | { proto: 1; op: 'respondToStoryEvent'; eventId: string; choiceId: string }
  | { proto: 1; op: 'startGuidedCampaign' }
  | { proto: 1; op: 'talkToVisitorLeader'; groupId: string }
  | { proto: 1; op: 'tradeWithVisitors'; groupId: string; action: VisitorTradeAction }
  | { proto: 1; op: 'resolveVillageRequest'; requestId: string; choice: VillageRequestChoiceId }
  | { proto: 1; op: 'deliverVisitorQuest' }
  | { proto: 1; op: 'negotiateRefugees'; groupId: string; choice: RefugeeChoice }
  | { proto: 1; op: 'sendRivalGift'; rivalId: string }
  | { proto: 1; op: 'establishRivalTradePact'; rivalId: string }
  | { proto: 1; op: 'showStrengthToRival'; rivalId: string }
  | { proto: 1; op: 'signPeaceTreaty'; rivalId: string }
  | { proto: 1; op: 'launchRaidOnRival'; rivalId: string }
  | { proto: 1; op: 'provokeRival'; rivalId: string }
  | { proto: 1; op: 'startResearch'; researchId: string }
  | { proto: 1; op: 'establishTradeRoute'; routeId: string }
  | { proto: 1; op: 'finishSpotlightLore'; sceneId: string; reason: 'complete' | 'skipped' }
  | { proto: 1; op: 'startSpotlightLoreDebug' }
  | { proto: 1; op: 'hostTownFestival'; buildingId: number }
  | { proto: 1; op: 'spawnMoonHowlerDebug' }
  | { proto: 1; op: 'buildDebug'; type: string; x: number; y: number }
  | { proto: 1; op: 'setWorkSchedule'; startHour: number; endHour: number }
  | { proto: 1; op: 'setVenueSchedule'; venue: VenueScheduleKind; startHour: number; endHour: number }
  | { proto: 1; op: 'setWorkforcePolicy'; preset: WorkforcePreset };

const WORKER_COMMAND_OPS = [
  'startBuilding',
  'placeStripChain',
  'assignWorker',
  'autoStaffWorkers',
  'removeWorker',
  'repairBuilding',
  'repairBuildings',
  'upgradeBuilding',
  'demolishBuilding',
  'toggleWallGate',
  'demolishStripBuildings',
  'setWorkshopRecipe',
  'setHuntingSpotPrey',
  'setMineMode',
  'setBuildingStaffingMode',
  'queueForgeOrder',
  'recruitSettler',
  'tameEntity',
  'notifyBuildingLocked',
  'respondToRaidEvent', 'resolveWarPrisoner',
  'respondToOutgoingRaidEvent',
  'resolveRaidVictory',
  'respondToDiplomacyEvent',
  'respondToStoryEvent',
  'startGuidedCampaign',
  'talkToVisitorLeader',
  'tradeWithVisitors',
  'resolveVillageRequest',
  'deliverVisitorQuest',
  'negotiateRefugees',
  'sendRivalGift',
  'establishRivalTradePact',
  'showStrengthToRival',
  'signPeaceTreaty',
  'launchRaidOnRival',
  'provokeRival',
  'startResearch',
  'establishTradeRoute',
  'hostTownFestival',
  'finishSpotlightLore',
  'startSpotlightLoreDebug',
  'spawnMoonHowlerDebug',
  'buildDebug',
  'setWorkSchedule',
  'setVenueSchedule',
  'setWorkforcePolicy',
] as const satisfies readonly WorkerCommand['op'][];
const WORKER_COMMAND_OP_SET = new Set<WorkerCommand['op']>(WORKER_COMMAND_OPS);

type MissingOps = Exclude<WorkerCommand['op'], (typeof WORKER_COMMAND_OPS)[number]>;
const _EXHAUSTIVE_OPS_CHECK: MissingOps extends never ? true : false = true;
void _EXHAUSTIVE_OPS_CHECK;

// Lazy safe resolvers to prevent circular module evaluation crashes
let buildingTypeValuesSet: Set<string> | null = null;
function getBuildingTypeValues(): Set<string> {
  if (!buildingTypeValuesSet) {
    buildingTypeValuesSet = new Set<string>(
      BuildingType && typeof BuildingType === 'object' ? Object.values(BuildingType) : [],
    );
  }
  return buildingTypeValuesSet;
}

let forgeOrderIdsSet: Set<string> | null = null;
function getForgeOrderIds(): Set<string> {
  if (!forgeOrderIdsSet) {
    forgeOrderIdsSet = new Set<string>(
      Array.isArray(FORGE_ORDERS) ? FORGE_ORDERS.map((o) => o.id) : [],
    );
  }
  return forgeOrderIdsSet;
}

let visitorTradeActionsSet: Set<string> | null = null;
function getVisitorTradeActions(): Set<string> {
  if (!visitorTradeActionsSet) {
    visitorTradeActionsSet = new Set<string>(
      VISITOR_TRADE_COSTS && typeof VISITOR_TRADE_COSTS === 'object' ? Object.keys(VISITOR_TRADE_COSTS) : [],
    );
  }
  return visitorTradeActionsSet;
}

const REFUGEE_CHOICES = new Set<string>(['welcome', 'screen', 'turn_away']);
const VILLAGE_REQUEST_CHOICES = new Set<string>(['accept', 'decline']);

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0;
}

function isBuildingType(value: unknown): value is BuildingType {
  return typeof value === 'string' && getBuildingTypeValues().has(value);
}

function isBuildingRotation(value: unknown): value is BuildingRotation {
  return value === 0 || value === 90 || value === 180 || value === 270;
}

function isStripSegment(value: unknown): boolean {
  if (!value || typeof value !== 'object') return false;
  const seg = value as { x?: unknown; y?: unknown };
  return isFiniteNumber(seg.x) && isFiniteNumber(seg.y);
}

/** Validate main → worker command shape before dispatch. */
function validateWorkerCommandShape(cmd: { op: WorkerCommand['op'] } & Record<string, unknown>): boolean {
  switch (cmd.op) {
    case 'resolveWarPrisoner':
      return isFiniteNumber(cmd.entityId) && ['keep', 'release', 'recruit', 'execute_confirmed'].includes(String(cmd.choiceId));
    case 'startBuilding':
      return (
        isBuildingType(cmd.type) &&
        isFiniteNumber(cmd.x) &&
        isFiniteNumber(cmd.y) &&
        (cmd.rotation === undefined || isBuildingRotation(cmd.rotation))
      );
    case 'placeStripChain':
      return (
        isBuildingType(cmd.type) &&
        Array.isArray(cmd.segments) &&
        cmd.segments.length > 0 &&
        cmd.segments.every(isStripSegment) &&
        (cmd.rotation === undefined || isBuildingRotation(cmd.rotation))
      );
    case 'assignWorker':
      return isFiniteNumber(cmd.buildingId) && (cmd.humanId === undefined || isFiniteNumber(cmd.humanId));
    case 'removeWorker':
      return isFiniteNumber(cmd.buildingId) && isFiniteNumber(cmd.humanId);
    case 'repairBuildings':
      return Array.isArray(cmd.buildingIds)
        && cmd.buildingIds.length > 0
        && cmd.buildingIds.every((id: unknown) => Number.isSafeInteger(id) && (id as number) > 0)
        && new Set(cmd.buildingIds).size === cmd.buildingIds.length;
    case 'demolishStripBuildings':
      return Array.isArray(cmd.buildingIds)
        && cmd.buildingIds.length > 0
        && cmd.buildingIds.length <= MAX_STRIP_SEGMENTS
        && cmd.buildingIds.every((id: unknown) => Number.isSafeInteger(id) && (id as number) > 0)
        && new Set(cmd.buildingIds).size === cmd.buildingIds.length;
    case 'repairBuilding':
    case 'upgradeBuilding':
    case 'demolishBuilding':
    case 'hostTownFestival':
      return isFiniteNumber(cmd.buildingId);
    case 'toggleWallGate':
      return Number.isSafeInteger(cmd.buildingId) && (cmd.buildingId as number) > 0;
    case 'setWorkshopRecipe':
      return isFiniteNumber(cmd.buildingId) && isNonEmptyString(cmd.recipeId);
    case 'setHuntingSpotPrey':
      return isFiniteNumber(cmd.buildingId) && isValidHuntingSpotPrey(cmd.prey);
    case 'setMineMode':
      return (
        isFiniteNumber(cmd.buildingId) &&
        typeof cmd.mode === 'string' &&
        (MINE_ORES as readonly string[]).includes(cmd.mode)
      );
    case 'setBuildingStaffingMode':
      return isFiniteNumber(cmd.buildingId) && (cmd.mode === 'auto' || cmd.mode === 'manual');
    case 'queueForgeOrder':
      return isFiniteNumber(cmd.buildingId) && typeof cmd.orderId === 'string' && getForgeOrderIds().has(cmd.orderId);
    case 'recruitSettler':
    case 'autoStaffWorkers':
    case 'spawnMoonHowlerDebug':
      return true;
    case 'buildDebug':
      return isBuildingType(cmd.type) && isFiniteNumber(cmd.x) && isFiniteNumber(cmd.y);
    case 'setWorkSchedule':
      return validateWorkSchedule(cmd.startHour, cmd.endHour).ok;
    case 'setVenueSchedule':
      return (cmd.venue === 'tavern' || cmd.venue === 'hotel') && validateVenueSchedule(cmd.startHour, cmd.endHour).ok;
    case 'setWorkforcePolicy':
      return isWorkforcePreset(cmd.preset);
    case 'tameEntity':
      return isFiniteNumber(cmd.entityId) && isFiniteNumber(cmd.humanId);
    case 'notifyBuildingLocked':
      return isBuildingType(cmd.type);
    case 'respondToRaidEvent':
    case 'respondToOutgoingRaidEvent':
    case 'resolveRaidVictory':
    case 'respondToDiplomacyEvent':
    case 'respondToStoryEvent':
      return isNonEmptyString(cmd.eventId) && isNonEmptyString(cmd.choiceId);
    case 'finishSpotlightLore':
      return isNonEmptyString(cmd.sceneId) && (cmd.reason === 'complete' || cmd.reason === 'skipped');
    case 'startSpotlightLoreDebug':
      return true;
    case 'startGuidedCampaign':
      return true;
    case 'talkToVisitorLeader':
      return isNonEmptyString(cmd.groupId);
    case 'tradeWithVisitors':
      return isNonEmptyString(cmd.groupId) && typeof cmd.action === 'string' && getVisitorTradeActions().has(cmd.action);
    case 'resolveVillageRequest':
      return isNonEmptyString(cmd.requestId) && typeof cmd.choice === 'string' && VILLAGE_REQUEST_CHOICES.has(cmd.choice);
    case 'deliverVisitorQuest':
      return true;
    case 'negotiateRefugees':
      return isNonEmptyString(cmd.groupId) && typeof cmd.choice === 'string' && REFUGEE_CHOICES.has(cmd.choice);
    case 'sendRivalGift':
    case 'establishRivalTradePact':
    case 'showStrengthToRival':
    case 'signPeaceTreaty':
    case 'launchRaidOnRival':
    case 'provokeRival':
      return isNonEmptyString(cmd.rivalId);
    case 'startResearch':
      return isNonEmptyString(cmd.researchId);
    case 'establishTradeRoute':
      return isNonEmptyString(cmd.routeId);
    default:
      return false;
  }
}

/** Validate main → worker command shape before dispatch. */
export function isWorkerCommand(cmd: unknown): cmd is WorkerCommand {
  if (!cmd || typeof cmd !== 'object') return false;
  const c = cmd as { proto?: unknown; op?: unknown };
  if (c.proto !== WORKER_CMD_PROTO) return false;
  if (typeof c.op !== 'string' || !WORKER_COMMAND_OP_SET.has(c.op as WorkerCommand['op'])) {
    return false;
  }
  return validateWorkerCommandShape(c as { op: WorkerCommand['op'] } & Record<string, unknown>);
}

/** Apply a versioned command on the worker-authoritative world. */
export function applyWorkerCommand(world: WorldState, cmd: WorkerCommand, ownership: 'isolated' | 'owned' = 'isolated'): WorldState {
  if (world.raidRecovery?.status === 'destroyed') return world;
  if (!isWorkerCommand(cmd)) {
    console.warn('[WorkerCommand] Invalid command', (cmd as { op?: string })?.op ?? '?');
    return world;
  }

  switch (cmd.op) {
    case 'resolveWarPrisoner':
      return resolveWarPrisoner(world, cmd.entityId, cmd.choiceId);
    case 'startBuilding':
      return startBuilding(world, cmd.type, cmd.x, cmd.y, cmd.rotation ?? 0);
    case 'placeStripChain':
      return placeStripChain(world, cmd.type, cmd.segments, cmd.rotation ?? 0);
    case 'assignWorker':
      return cmd.humanId != null
        ? assignIdleWorkerToBuilding(world, cmd.buildingId, cmd.humanId, ownership)
        : fillBuildingWorkers(world, cmd.buildingId);
    case 'autoStaffWorkers':
      return autoStaffAllWorkers(world, ownership);
    case 'removeWorker':
      return removeWorkerFromBuilding(world, cmd.buildingId, cmd.humanId);
    case 'repairBuilding':
      return repairBuilding(world, cmd.buildingId);
    case 'repairBuildings':
      return repairBuildings(world, cmd.buildingIds);
    case 'upgradeBuilding':
      return upgradeBuilding(world, cmd.buildingId, ownership);
    case 'demolishBuilding':
      return demolishBuildingInPlace(world, cmd.buildingId);
    case 'toggleWallGate':
      return toggleWallGate(world, cmd.buildingId);
    case 'demolishStripBuildings':
      return demolishStripBuildingsInPlace(world, cmd.buildingIds);
    case 'setWorkshopRecipe':
      return setWorkshopRecipe(world, cmd.buildingId, cmd.recipeId);
    case 'setHuntingSpotPrey':
      return setHuntingSpotPrey(world, cmd.buildingId, cmd.prey);
    case 'setMineMode':
      return setMineMode(world, cmd.buildingId, cmd.mode);
    case 'setBuildingStaffingMode':
      return setBuildingStaffingMode(world, cmd.buildingId, cmd.mode);
    case 'queueForgeOrder':
      return queueForgeOrder(world, cmd.buildingId, cmd.orderId);
    case 'recruitSettler':
      return recruitSettler(world);
    case 'tameEntity':
      return tameEntity(world, cmd.entityId, cmd.humanId);
    case 'notifyBuildingLocked':
      return notifyBuildingLocked(world, cmd.type);
    case 'respondToRaidEvent':
      return queueRaidDefense(world, cmd.eventId, cmd.choiceId);
    case 'respondToOutgoingRaidEvent':
      return respondToOutgoingRaidEvent(world, cmd.eventId, cmd.choiceId);
    case 'resolveRaidVictory':
      return resolveRaidVictory(world, cmd.eventId, cmd.choiceId);
    case 'respondToStoryEvent':
      return respondToStoryEvent(world, cmd.eventId, cmd.choiceId);
    case 'startGuidedCampaign':
      startGuidedCampaign(world);
      return world;
    case 'respondToDiplomacyEvent':
      return respondToDiplomacyEvent(world, cmd.eventId, cmd.choiceId);
    case 'talkToVisitorLeader':
      return talkToVisitorLeader(world, cmd.groupId);
    case 'tradeWithVisitors':
      return tradeWithVisitors(world, cmd.groupId, cmd.action);
    case 'resolveVillageRequest':
      return resolveVillageRequest(world, cmd.requestId, cmd.choice);
    case 'deliverVisitorQuest': {
      const done = deliverVisitorQuest(world);
      if (done) {
        addBigNews(
          world,
          '⚒️ The smith is grateful',
          'The masterwork is finished — he pays handsomely and your reputation grows.',
          'positive',
        );
        addFloatingText(
          world,
          (world.width ?? 1200) / 2,
          (world.height ?? 900) / 2 - 40,
          'Quest complete! +30💰 +4⭐',
          '#fbbf24',
        );
      }
      return world;
    }
    case 'negotiateRefugees':
      return negotiateRefugees(world, cmd.groupId, cmd.choice);
    case 'sendRivalGift':
      return sendRivalGift(world, cmd.rivalId);
    case 'establishRivalTradePact':
      return establishRivalTradePact(world, cmd.rivalId);
    case 'showStrengthToRival':
      return showStrengthToRival(world, cmd.rivalId);
    case 'signPeaceTreaty':
      return signPeaceTreaty(world, cmd.rivalId);
    case 'launchRaidOnRival':
      return launchRaidOnRival(world, cmd.rivalId);
    case 'provokeRival':
      return provokeRival(world, cmd.rivalId);
    case 'startResearch':
      return startResearch(world, cmd.researchId);
    case 'establishTradeRoute':
      return establishTradeRoute(world, cmd.routeId);
    case 'finishSpotlightLore':
      finishSpotlightLore(world, cmd.sceneId, cmd.reason);
      return world;
    case 'startSpotlightLoreDebug':
      startSpotlightLoreDebug(world);
      return world;
    case 'hostTownFestival':
      return hostTownFestival(world, cmd.buildingId);
    case 'spawnMoonHowlerDebug':
      return spawnMoonHowlerDebug(world);
    case 'buildDebug':
      // Debug/testing only: raises any building for free, so a test run does not have to play 200
      // days to afford a Church. Placement validity is still enforced inside `startBuilding`.
      return startBuilding(world, cmd.type as BuildingType, cmd.x, cmd.y, 0, true);
    case 'setWorkSchedule':
      return setWorkSchedule(world, cmd.startHour, cmd.endHour);
    case 'setVenueSchedule':
      return setVenueSchedule(world, cmd.venue, cmd.startHour, cmd.endHour);
    case 'setWorkforcePolicy':
      return setWorkforcePolicy(world, cmd.preset);
    default: {
      const unknown = cmd as { op?: string };
      console.warn('[WorkerCommand] Unknown op', unknown.op ?? '?');
      return world;
    }
  }
}

/** Extract a SimTickDelta from the world diff for a command. */
export function extractCommandDelta(world: WorldState): SimTickDelta {
  const entities = world.entities ?? [];
  const aliveNow = entities.filter((e) => e.alive);
  return extractSimTickDelta(world, aliveNow, {
    cloneMode: 'transfer',
  });
}

/** Best-effort command delta — falls back cleanly to a baseline delta on error. */
export function safeExtractCommandDelta(world: WorldState): SimTickDelta {
  try {
    return extractCommandDelta(world);
  } catch (err) {
    console.warn('[WorkerCommand] Delta extract failed after command error', err);
    return createFallbackSimTickDelta(world);
  }
}