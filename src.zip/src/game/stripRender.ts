import { BuildingType } from './gameTypes';
import type { BuildingRotation, CornerRotation } from './buildingRotation';
import { normalizeCornerRotation } from './buildingRotation';
import { cornerArms } from './stripJunction';
import type { JunctionKind, StripJunctionInfo } from './stripJunction';
import { getSpriteFrame } from './spriteLoader';
import { seeded } from './renderer/shared';

const PAVEMENT_SPRITE = '/sprites/tile_pavement.png';
const ROAD_STRAIGHT_HORIZONTAL = '/sprites/roads/road_straight_1.png';
// CC0 original sprites by Drummyfish: https://opengameart.org/content/top-down-rpg-mockup-scene
const RPG_PAVEMENT_SPRITE = '/sprites/oga_drummyfish/tile_pavement.png';
const RPG_WALL_SPRITE = '/sprites/oga_drummyfish/wall.png';
const RPG_GATE_SPRITE = '/sprites/oga_drummyfish/gate.png';
const WALL_STRAIGHT_FALLBACK = '/sprites/walls/wall_straight.svg';
const WALL_GATE_FALLBACK = '/sprites/walls/wall_gate.svg';
const ROAD_STRAIGHT_VERTICAL = '/sprites/roads/road_straight_2.png';
const ROAD_CROSS = '/sprites/roads/road_cross.png';
const ROAD_TEE = ['/sprites/roads/road_tee_1.png', '/sprites/roads/road_tee_2.png'] as const;
const ROAD_CORNER = ['/sprites/roads/road_corner_1.png', '/sprites/roads/road_corner_2.png', '/sprites/roads/road_corner_3.png', '/sprites/roads/road_corner_4.png'] as const;

/**
 * Tile the seamless pavement texture across a strip rect (rotation already
 * applied by the caller's frame). Returns false when the tile isn't loaded,
 * so callers fall back to flat fills.
 */
function paintPavementPattern(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  rw: number,
  rh: number,
): boolean {
  const frame = getSpriteFrame(PAVEMENT_SPRITE);
  const img = frame?.image;
  if (!img) return false;
  const pat = ctx.createPattern(img as CanvasImageSource, 'repeat');
  if (!pat) return false;
  const tile = 25;
  const scale = Math.max(1, rh / tile); // tile roughly the road's height
  ctx.save();
  ctx.translate(x0, y0);
  ctx.scale(scale, scale);
  ctx.fillStyle = pat;
  ctx.fillRect(0, 0, rw / scale, rh / scale);
  ctx.restore();
  // Subtle depth overlay so the strip still reads as a built road.
  ctx.fillStyle = 'rgba(0,0,0,0.10)';
  ctx.fillRect(x0, y0, rw, rh);
  return true;
}

/** Seamless CC0 cobblestone, used for straight runs and every junction shape. */
function paintRpgPavementPattern(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  tileDepth = height,
  phaseX = 0,
  phaseY = 0,
): boolean {
  const sprite = getSpriteFrame(RPG_PAVEMENT_SPRITE);
  if (!sprite?.image || sprite.sh <= 0 || tileDepth <= 0) return false;
  const pattern = ctx.createPattern(sprite.image as CanvasImageSource, 'repeat');
  if (!pattern) return false;
  const scale = tileDepth / sprite.sh;
  const offsetX = (phaseX + x) / scale;
  const offsetY = (phaseY + y) / scale;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.fillStyle = pattern;
  ctx.translate(-offsetX, -offsetY);
  ctx.fillRect(offsetX, offsetY, width / scale, height / scale);
  ctx.restore();
  return true;
}

function beginRotatedStripFrame(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  rotation: BuildingRotation,
  alpha: number,
): { rw: number; rh: number; x0: number; y0: number } {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(sx, sy);
  if (rotation === 90) ctx.rotate(Math.PI / 2);
  const rw = Math.max(w, h);
  const rh = Math.min(w, h);
  return { rw, rh, x0: -rw / 2, y0: -rh / 2 };
}

function strokePalisadeRails(
  ctx: CanvasRenderingContext2D,
  ax: number,
  ay: number,
  aw: number,
  ah: number,
): void {
  ctx.strokeStyle = '#57534e';
  ctx.lineWidth = Math.max(2, ah * 0.12);
  ctx.beginPath();
  ctx.moveTo(ax, ay + ah * 0.35);
  ctx.lineTo(ax + aw, ay + ah * 0.35);
  ctx.moveTo(ax, ay + ah * 0.62);
  ctx.lineTo(ax + aw, ay + ah * 0.62);
  ctx.stroke();
}

function drawPalisadeArm(
  ctx: CanvasRenderingContext2D,
  ax: number,
  ay: number,
  aw: number,
  ah: number,
  shadow = false,
): void {
  if (shadow) {
    ctx.fillStyle = 'rgba(0,0,0,0.18)';
    ctx.fillRect(ax, ay + ah * 0.55, aw, ah * 0.45);
  }
  drawPalisadePosts(ctx, ax, ay, aw, ah, null);
  strokePalisadeRails(ctx, ax, ay, aw, ah);
}

/** Draw an authored road or wall asset, falling back when it has not loaded. */
function paintStripSprite(
  ctx: CanvasRenderingContext2D,
  spritePath: string,
  x: number,
  y: number,
  w: number,
  h: number,
  rotation: number,
): boolean {
  const frame = getSpriteFrame(spritePath);
  const img = frame?.image;
  if (!img) return false;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate((rotation * Math.PI) / 180);
  ctx.drawImage(img as CanvasImageSource, -w / 2, -h / 2, w, h);
  ctx.restore();
  return true;
}

/** Repeats upright stone facades along the construction axis without rotating the art. */
function paintRpgStoneStrip(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  rotation: BuildingRotation,
  isGate: boolean,
  alpha: number,
): boolean {
  const wall = getSpriteFrame(RPG_WALL_SPRITE);
  const gate = isGate ? getSpriteFrame(RPG_GATE_SPRITE) : null;
  if (!wall || (isGate && !gate)) return false;
  const run = Math.max(w, h);
  const depth = Math.max(1, Math.min(w, h));
  const count = Math.max(1, Math.ceil(run / (depth * 1.8)));
  const pitch = run / count;
  const wallHeight = depth * 3;
  const gateWidth = Math.min(run, depth * 2.8);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(sx, sy);
  for (let i = 0; i < count; i++) {
    const along = -run / 2 + (i + 0.5) * pitch;
    if (isGate && Math.abs(along) < gateWidth / 2) continue;
    const x = rotation === 90 ? 0 : along;
    const y = rotation === 90 ? along : 0;
    paintStripSprite(ctx, RPG_WALL_SPRITE, x, y - wallHeight / 2 + depth / 2,
      rotation === 90 ? depth * 2 : pitch + 1, wallHeight, 0);
  }
  if (isGate) {
    const gateHeight = gateWidth * (gate!.sh / gate!.sw);
    paintStripSprite(ctx, RPG_GATE_SPRITE, 0, depth / 2 - gateHeight / 2,
      gateWidth, gateHeight, 0);
  }
  ctx.restore();
  return true;
}

/** Top-down cobble road — uses the hand-made path pieces with procedural fallback. */
export function drawProceduralRoad(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  rotation: BuildingRotation,
  alpha = 1,
): void {
  const { rw, rh, x0, y0 } = beginRotatedStripFrame(ctx, sx, sy, w, h, rotation, alpha);

  const roadSprite = rotation === 0 ? ROAD_STRAIGHT_HORIZONTAL : ROAD_STRAIGHT_VERTICAL;
  const authoredRoad = paintRpgPavementPattern(ctx, x0, y0, rw, rh, rh,
    rotation === 90 ? sy : sx, rotation === 90 ? -sx : sy)
    || paintStripSprite(ctx, roadSprite, 0, 0, rw, rh, 0);
  if (!authoredRoad && !paintPavementPattern(ctx, x0, y0, rw, rh)) {
    // Fallback flat road (tile not loaded yet)
    ctx.fillStyle = '#3f3a33';
    ctx.fillRect(x0, y0, rw, rh);

    ctx.fillStyle = '#5c5346';
    ctx.fillRect(x0 + 2, y0 + 2, rw - 4, rh - 4);

    ctx.fillStyle = '#78716c';
    ctx.fillRect(x0 + rw * 0.2, y0 + rh * 0.28, rw * 0.6, rh * 0.44);

    const stones = Math.max(4, Math.floor(rw / 14));
    for (let i = 0; i < stones; i++) {
      const t = i / Math.max(1, stones - 1);
      const px = x0 + 4 + t * (rw - 8);
      const jitter = (seeded(i * 3.1) - 0.5) * rh * 0.25;
      ctx.fillStyle = seeded(i) > 0.5 ? '#6b6560' : '#4b453d';
      ctx.beginPath();
      ctx.ellipse(px, y0 + rh * 0.5 + jitter, 2.8, 2.2, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  if (!authoredRoad) {
    ctx.strokeStyle = 'rgba(0,0,0,0.25)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x0 + 0.5, y0 + 0.5, rw - 1, rh - 1);
  }
  ctx.restore();
}


/**
 * Palisade wall / gate segment, drawn along the strip's own axis.
 *
 * The wall used to draw `/sprites/wall_isometric.png` — a 45° isometric face — once per piece. The
 * world→screen transform is a plain scale+translate with no isometric skew (`viewState.worldToScreen`),
 * so a horizontal run is a horizontal screen line, and every piece drew that same diagonal face at the
 * same rotation, offset by exactly the strip pitch: a periodic sawtooth of offset slabs, never a wall.
 * Corner pieces do not exist — a corner is an H run and a V run overlapping — so the only thing a
 * segment has to do is lie along its own axis, which this path already did (`beginRotatedStripFrame`
 * rotates the frame, not the art). The isometric PNGs stay as the build-menu icons in
 * `BUILDING_CONFIGS`; only the map drawing changed.
 */
export function drawProceduralWall(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  rotation: BuildingRotation,
  isGate: boolean,
  alpha = 1,
): void {
  if (paintRpgStoneStrip(ctx, sx, sy, w, h, rotation, isGate, alpha)) return;
  const { rw, rh, x0, y0 } = beginRotatedStripFrame(ctx, sx, sy, w, h, rotation, alpha);
  if (paintStripSprite(ctx, isGate ? WALL_GATE_FALLBACK : WALL_STRAIGHT_FALLBACK, 0, 0, rw, rh, 0)) {
    ctx.restore();
    return;
  }

  ctx.fillStyle = 'rgba(0,0,0,0.18)';
  ctx.fillRect(x0, y0 + rh * 0.55, rw, rh * 0.35);

  const gapStart = isGate ? rw * 0.38 : -1;
  const gapEnd = isGate ? rw * 0.62 : -1;
  const skipRange = isGate ? [gapStart, gapEnd] as [number, number] : null;
  drawPalisadePosts(ctx, x0, y0, rw, rh, skipRange);
  strokePalisadeRails(ctx, x0, y0, rw, rh);

  if (isGate) {
    ctx.fillStyle = '#292524';
    ctx.fillRect(x0 + gapStart, y0 + rh * 0.2, gapEnd - gapStart, rh * 0.75);
    ctx.strokeStyle = '#a8a29e';
    ctx.lineWidth = 2;
    ctx.strokeRect(x0 + gapStart, y0 + rh * 0.15, gapEnd - gapStart, rh * 0.8);
  }

  ctx.restore();
}

/** Light wooden fence — thin posts + two rails, reads as a tidy boundary. */
export function drawProceduralFence(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  rotation: BuildingRotation,
  alpha = 1,
): void {
  const { rw, rh, x0, y0 } = beginRotatedStripFrame(ctx, sx, sy, w, h, rotation, alpha);

  const posts = Math.max(2, Math.floor(rw / 18));
  for (let i = 0; i < posts; i++) {
    const t = posts === 1 ? 0.5 : i / (posts - 1);
    const px = x0 + 4 + t * (rw - 8);
    ctx.fillStyle = '#92400e';
    ctx.fillRect(px - 1.5, y0, 3, rh);
    ctx.fillStyle = '#d6a35c';
    ctx.fillRect(px - 2.5, y0 - 1, 5, 2.5);
  }
  ctx.fillStyle = '#b45309';
  ctx.fillRect(x0, y0 + rh * 0.3, rw, 2.2);
  ctx.fillRect(x0, y0 + rh * 0.62, rw, 2.2);

  ctx.strokeStyle = 'rgba(0,0,0,0.22)';
  ctx.lineWidth = 1;
  ctx.strokeRect(x0 + 0.5, y0 + 0.5, rw - 1, rh - 1);
  ctx.restore();
}

function drawPalisadePosts(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  rw: number,
  rh: number,
  skipRange: [number, number] | null,
): void {
  const postW = Math.max(3, rh * 0.22);
  const postCount = Math.max(3, Math.floor(rw / 14));
  for (let i = 0; i < postCount; i++) {
    const t = postCount <= 1 ? 0.5 : i / (postCount - 1);
    const px = x0 + t * (rw - postW);
    if (skipRange && px + postW > skipRange[0] && px < skipRange[1]) continue;
    const lean = (seeded(i * 1.7) - 0.5) * 0.08;
    ctx.save();
    ctx.translate(px + postW / 2, y0 + rh);
    ctx.rotate(lean);
    const grad = ctx.createLinearGradient(0, -rh, 0, 0);
    grad.addColorStop(0, '#94a3b8');
    grad.addColorStop(0.45, '#64748b');
    grad.addColorStop(1, '#475569');
    ctx.fillStyle = grad;
    ctx.fillRect(-postW / 2, -rh * 0.92, postW, rh * 0.92);
    ctx.fillStyle = '#334155';
    ctx.fillRect(-postW / 2, -rh * 0.92, postW, 2);
    ctx.restore();
  }
}

/** L-shaped palisade corner — rotation picks which quadrant is open. */
export function drawProceduralWallCorner(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  rotation: CornerRotation,
  alpha = 1,
): void {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(sx, sy);
  const size = Math.max(w, h);
  const half = size / 2;
  const arm = size * 0.46;
  const thick = size * 0.34;
  const r = normalizeCornerRotation(rotation);

  const arms = cornerArms(r);
  if (arms.north) {
    drawPalisadeArm(ctx, half - thick, -half - arm, thick, arm + half, true);
  }
  if (arms.south) {
    drawPalisadeArm(ctx, half - thick, half, thick, arm + half, true);
  }
  if (arms.east) {
    drawPalisadeArm(ctx, half - arm, -half, arm + half, thick, true);
  }
  if (arms.west) {
    drawPalisadeArm(ctx, -half - arm, -half, arm + half, thick, true);
  }

  ctx.restore();
}

/** Wider cobble cap where road segments meet (tee / cross / elbow). */
export function drawProceduralRoadJunction(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  kind: JunctionKind,
  alpha = 1,
  rotation = 0,
): void {
  if (kind === 'end' || kind === 'straight') return;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(sx, sy);

  const size = Math.max(w, h);
  const cap = size * (kind === 'cross' ? 0.52 : 0.44);
  const spritePath = kind === 'cross'
    ? ROAD_CROSS
    : kind === 'tee'
      ? ROAD_TEE[0]
      : ROAD_CORNER[Math.abs(Math.round(rotation / 90)) % ROAD_CORNER.length];

  if (!paintRpgPavementPattern(ctx, -cap / 2, -cap / 2, cap, cap,
    Math.min(w, h), sx, sy)
    && !paintStripSprite(ctx, spritePath, 0, 0, cap, cap, kind === 'tee' ? rotation : 0)
    && !paintPavementPattern(ctx, -cap / 2, -cap / 2, cap, cap)) {
    ctx.fillStyle = '#3f3a33';
    ctx.fillRect(-cap / 2, -cap / 2, cap, cap);
    ctx.fillStyle = '#5c5346';
    ctx.fillRect(-cap / 2 + 2, -cap / 2 + 2, cap - 4, cap - 4);
    ctx.fillStyle = '#78716c';
    ctx.fillRect(-cap * 0.28, -cap * 0.28, cap * 0.56, cap * 0.56);
  }

  if (!getSpriteFrame(RPG_PAVEMENT_SPRITE)) {
    ctx.strokeStyle = 'rgba(0,0,0,0.3)';
    ctx.lineWidth = 1;
    ctx.strokeRect(-cap / 2 + 0.5, -cap / 2 + 0.5, cap - 1, cap - 1);
  }
  ctx.restore();
}

/** T or + palisade junction — used when a corner connects three or four arms. */
export function drawProceduralWallJunction(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  info: StripJunctionInfo,
  alpha = 1,
): void {
  if (info.kind !== 'elbow' && info.kind !== 'tee' && info.kind !== 'cross') return;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(sx, sy);

  // A single upright cap seals the joint without covering the connected arms.
  if (getSpriteFrame(RPG_WALL_SPRITE)) {
    const depth = Math.min(w, h);
    paintStripSprite(ctx, RPG_WALL_SPRITE, 0, -depth, depth * 2, depth * 3, 0);
    ctx.restore();
    return;
  }
  const size = Math.max(w, h);
  const half = size / 2;
  const thick = size * 0.34;
  const arm = size * 0.46;
  const { connections: c } = info;

  ctx.fillStyle = 'rgba(0,0,0,0.18)';
  ctx.fillRect(-half, half * 0.1, size, thick * 0.45);

  if (c.west) drawPalisadeArm(ctx, -half, -thick, arm + half, thick);
  if (c.east) drawPalisadeArm(ctx, half - arm, -thick, arm + half, thick);
  if (c.north) drawPalisadeArm(ctx, -thick, -half, thick, arm + half);
  if (c.south) drawPalisadeArm(ctx, -thick, half - arm, thick, arm + half);

  ctx.restore();
}

export function drawProceduralStripBuilding(
  ctx: CanvasRenderingContext2D,
  type: BuildingType,
  sx: number,
  sy: number,
  w: number,
  h: number,
  rotation: BuildingRotation | CornerRotation,
  alpha = 1,
): void {
  if (type === BuildingType.Road) {
    drawProceduralRoad(ctx, sx, sy, w, h, rotation as BuildingRotation, alpha);
    return;
  }
  if (type === BuildingType.Fence) {
    drawProceduralFence(ctx, sx, sy, w, h, rotation as BuildingRotation, alpha);
    return;
  }
  drawProceduralWall(ctx, sx, sy, w, h, rotation as BuildingRotation, type === BuildingType.WallGate, alpha);
}

export function drawStripJunctionOverlay(
  ctx: CanvasRenderingContext2D,
  type: BuildingType,
  sx: number,
  sy: number,
  w: number,
  h: number,
  info: StripJunctionInfo,
  alpha = 1,
): void {
  if (type === BuildingType.Road) {
    drawProceduralRoadJunction(ctx, sx, sy, w, h, info.kind, alpha, info.cornerRotation);
    return;
  }
  if (type === BuildingType.Wall) {
    drawProceduralWallJunction(ctx, sx, sy, w, h, info, alpha);
  }
}