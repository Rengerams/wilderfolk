import { MAX_ASSIGNABLE_COMMUTE_HOURS, WORK_COMMUTE_RUSH } from './commuteReach';
import type { WorldState, Entity, Building } from './gameTypes';
import { EntityType, BuildingType, JobType, Season } from './gameTypes';
import { isBarracksGuard } from './defenseStructures';
import { SPECIES_CONFIG } from './speciesConfig';
import { getSimRng, seededRandomForRun, personDayRoll } from './simRng';
import { faceVelocity, ROAD_SPEED_MULT, steerEntityToward } from './simulation/movementSteering';
import { OFFSCREEN_HUMAN_THROTTLE, isInFocus } from './simFocus';
import { addFloatingText } from './simEffects';
import { beautyAt, pickBeautySpot } from './beautyGrid';
import { getChurchStrength, findHumanWorkplace, buildConstructionCrewIndex } from './workforce';

import { isPlayerHuman } from './playerHuman';
import { getBuildingCenter } from './placementUtils';
import { isSettlerRelationshipEntity } from './moonHowlerForm';
import { buildCeremonySeatIndex, getElectionGatherTarget, isCeremonyAttendee } from './villageLeadership';
import { getSpotlightGatherTarget } from './spotlightLore';

import {
  allowSocialLifeFor,
  isAsleepAtHome,
  isFestivalGatherer,
  prefersHomeTonightFor,
  shouldBeAtHomeFor,
} from './humanSchedule';
import {
  getWorkSchedule,
  isOnWorkCommuteHours,
  isOnWorkScheduleShift,
  isWithinWorkCommuteLead,
  isWorkScheduleHour,
} from './workSchedule';
import { isWorkDay } from './dayCycleClock';
import { HUMAN_MAX_LIFESPAN_YEARS, tryGraduateHumanChild, syncHumanAgeFromCalendar, PER_TICK_RATE_SCALE, TICKS_PER_HOUR, isOnMoonHowlerNightShift, isWeekend, getAbsoluteCalendarDay, isNightHour, isNewCalendarDayTick, EVENING_START, isStartOfClockHour } from './dayCycle';
import { hasResidenceAssignment, isAdult, isNearResidence, isResidenceBuilding, shareResidence } from './housingModel';
import { WORK_ARRIVE_DISTANCE } from './workAbsence';
import {
  chatHintsFromWorld,
  endAmbientHumanChat,
  type HumanChatContext,
} from './humanChat';
import { maybeDialogueChat, tickDialogue, tryAmbientRandomDialogue } from './dialogueTrees';
import { advanceHumanWalkAnim } from './humanSprites';

import { isRenffrGossipActive } from './renffrStar';
import { getHumanFleeSpeedMultiplier } from './combat';
import { isActiveMoonHowler } from './moonHowler';

import {
  applyEducationGraduation,
  creditChildSchoolDay,
  findStaffedSchools,
  hasTeacherPresent,
  syncSchoolAssignments,
  recordChildSchoolTick,
  isSchoolTime,
  SCHOOL_START_HOUR,
} from './education';
import {
  getPlayerCampCenterFromBuildings,
  getPlayerSettlerCenter,
  isRaidMarchingForRival,
} from './frontierCombat';
import { buildPatrolRevealIndex, detectRaidersForPatrol, type PatrolRevealIndex } from './humanPatrolBehavior';
import { idleDestination, tickHumanChildLeisure, tickAdultLeisureMotive } from './humanLeisureBehavior';
import { tickHumanHunting } from './humanHuntingBehavior';
import {
  HUNTING_PURSUIT_SPEED_MULT,
  huntingKillReach,
  huntingPursuitPoint,
  huntingSpotChaseTarget,
  huntingSpotTarget,
  isHuntingSpotHunter,
} from './huntingSpot';
import { getCaravanMoveTarget, tryAdvanceCaravanLeg } from './tradeCaravans';
import { tickFactionCampWander } from './factionWander';
import {
  tryNeighborGreeting,
  tryWorkplaceBanter,
  type SocialBuildingPicker,
} from './socialLife';
import {
  tickHumanDoctorHospitalService,
  tickHumanHospitalPatientCare,
} from './humanHospitalBehavior';
import {
  tickHumanCivicVenueService,
  tickTavernService,
} from './humanVenueBehavior';
import {
  checkoutVisitor,
  createHotelLodgingIndex,
  isSettlerLodgingAtHotel,
  lodgingHotelFor,
  steerVisitorToHotel,
} from './hotelStay';
import { prisonGuardIds } from './prisonGuardDuty';
import { prisonShiftForGuard, shiftCoversHour } from './prisonShifts';
import { getReadOnlyPathGrid, isOnWalkableRoadAt, nearestWalkableWorldPoint, setCurrentPathMap, steerWithPath } from './pathfinding';
import { crowdGatherPosition, venueGatherPosition, homeStandPosition, enterHumanBuilding, applyHumanWalkStep, commuteDistanceFromResidence, commuteDistanceToBuilding, commuteHumanToBuilding, commuteLeadHoursFor, humanBuildingTarget, nearestActiveMoonHowler } from './simulation/humanMovement';
import { fract, tryEatColonyMeal, killFromStarvation } from './simulation/humanNeeds';
import { advanceHumanNeeds, adjustHumanStaminaFromEnergy, hasFatalStarvation, hasNearbyWell, resolveHumanNeedsIntent } from './simulation/humanPhysiology';
import { isRestingHospitalPatient } from './hospitalCare';
import { simAmbientChatNeighbors, simSettlerPairChat } from './simulation/humanSocial';
import { tickPregnancyAndBirth } from './simulation/humanLifecycle';

import { clampToMapBounds } from './mapBounds';
import { buildRoadAvoidanceIndex } from './spatialGrid';
import { buildResidenceOccupantIndex, findClosestEntityInRadius } from './simQueries';


import { evaluateTraitInfluence } from './personality/traitEvaluation';
import type { ExactTraitContext, TraitContext } from './personality/traitEffectCatalog';
import type { TickContext } from './simulation/simulationTypes';

/** The catalog context behind how fast a settler breaks off from a threat and runs. */
const ESCAPE_CONTEXT = { kind: 'danger', activity: 'escape' } as const satisfies TraitContext;

/** The catalog context behind how fast a courting pair makes progress. */
const COURTSHIP_PROGRESS_CONTEXT = { kind: 'social', activity: 'courtshipProgress' } as const satisfies ExactTraitContext;


import {
  findClosestAdaptiveInRadius,
  socialAdaptiveOptions,
  SOCIAL_STAGGER,
  SOCIAL_GREETING_RADIUS,
  SOCIAL_FRIENDSHIP_RADIUS,
  SOCIAL_COURTSHIP_RADIUS,
} from './adaptiveSpatialQuery';
import {
  AFFAIR_SPOUSE_BLOCK_RADIUS,
  bindCourtship,
  canPursueSecretAffair,
  courtshipRatePerHour,
  findCourtshipPartner,
  getAffairTrystBuilding,
  hasAffairPartner,
  isAtMaritalHome,
  isEligibleToCourt,
  isMaritalHomeOccupiedBySpouse,
  isSpouseNearby,
  isValidAffairTarget,
  isValidAffairTrystSite,
  affairEncounterHourOfDay,
  reconcileAffairPartner,
  shouldLeadAffairPair,
  tryCompleteCourtshipMarriage,
  tryDailyAffairEncounter,
  tryDailyAffairGossip,
  tryDailyAmicableDivorce,
  tryDailyConception,
  tryDailyHumanMortality,
  tryExposeCaughtAffairForPair,
  tryFormSchoolyardBond,
  trySchoolyardGossip,
} from './simulation/humanRelationships';
import { flushRelationshipDiagnostics } from './relationshipDiagnostics';
import { isVenueServiceHour, isVenueWorkerServiceHour } from './venueSchedule';
import { isHospitalDoctorOnShift, isHospitalDoctorCommuteTime } from './hospitalShifts';
import { recordPresentWorkTick, recordScheduleWorkTick } from './scheduleFatigue';

import { syncEntityGrids } from './simulation/simulationEntities';

/** Live on-screen intimate tryst distance. */
const AFFAIR_INTIMATE_RADIUS = 22;

function getAffairTrystTarget(
  cheater: Entity,
  paramour: Entity,
  entityById: Map<number, Entity>,
  buildingById: Map<number, Building>,
): { x: number; y: number } {
  const trystBuilding = getAffairTrystBuilding(cheater, paramour, entityById, buildingById);
  if (trystBuilding) return getBuildingCenter(trystBuilding);
  return { x: paramour.x, y: paramour.y };
}

/** Sole tick-level sleep observation; physiology alone owns rest and stamina recovery. */
function observeHumanSleep(entity: Entity, context: {
  hourOfDay: number;
  previousIndoorBuildingId: number | undefined;
  onDuty: boolean;
  recoveringSleep: boolean;
  buildings: Building[];
  buildingById: Map<number, Building>;
  entityById: Map<number, Entity>;
  tick: number;
}): { sleeping: boolean; hasHospital: boolean } {
  const { hourOfDay, previousIndoorBuildingId, onDuty, recoveringSleep, buildings, buildingById, entityById, tick } = context;
  if (entity.raidDeploymentId) return { sleeping: false, hasHospital: false };
  const night = isNightHour(hourOfDay);
  if (entity.prisonBuildingId != null) {
    const cell = buildingById.get(entity.prisonBuildingId);
    return {
      sleeping: Boolean(cell?.completed && night && Math.hypot(entity.x - cell.x, entity.y - cell.y) <= 18),
      hasHospital: false,
    };
  }
  if (onDuty) return { sleeping: false, hasHospital: false };

  const home = entity.residenceBuildingId == null ? undefined : buildingById.get(entity.residenceBuildingId);
  const atHome = !!home && home.faction !== 'rival' && isResidenceBuilding(home)
    && previousIndoorBuildingId === home.id;
  const atHotel = entity.hotelStayBuildingId != null
    && previousIndoorBuildingId === entity.hotelStayBuildingId
    && isSettlerLodgingAtHotel(entity, buildings, hourOfDay);
  const ward = previousIndoorBuildingId == null ? undefined : buildingById.get(previousIndoorBuildingId);
  const hasHospital = isRestingHospitalPatient(entity, ward, tick, previousIndoorBuildingId);

  const lover = entity.affairPartnerId == null ? undefined : entityById.get(entity.affairPartnerId);
  const site = lover?.alive && isSettlerRelationshipEntity(lover) && hasAffairPartner(entity, entityById)
    ? getAffairTrystBuilding(entity, lover, entityById, buildingById) : undefined;
  const atLover = !!site && !!lover && (night || recoveringSleep)
    && previousIndoorBuildingId === site.id && lover?.indoorBuildingId === site.id
    && isValidAffairTrystSite(entity, lover, entityById, buildingById, 55, hourOfDay);

  return {
    sleeping: (atHome && (night || recoveringSleep)) || atHotel || hasHospital || atLover,
    hasHospital,
  };
}

export function tickHumans(state: WorldState, ctx: TickContext): void {
  const {
    width,
    height,
    hourOfDay,
    season,
    canHeat,
    byType,
    newEntities,
    updatedBuildings,
    roadBuildings,
    playerHumans,
    focus,
    entityById,
    buildingById,
    mobileGrid,
    humanSocialGrid,
  } = ctx;

  setCurrentPathMap(state.worldMap, state.buildings);

  const config = SPECIES_CONFIG[EntityType.Human];
  const isWinter = season === Season.Winter;
  const anyActiveHowler = (byType[EntityType.Werewolf] ?? []).some(isActiveMoonHowler);

  const workSchedule = getWorkSchedule(state);
  const goWorkTime = isOnWorkScheduleShift(state, hourOfDay);
  const onWorkCommuteHours = isWorkDay(state.tick) && isOnWorkCommuteHours(workSchedule, hourOfDay);
  const weekend = isWeekend(state.tick);
  const isNewCalendarDay = isNewCalendarDayTick(state);
  const humanFleeMult = getHumanFleeSpeedMultiplier(state);
  const spotlightGather = state.spotlightLore ?? null;
  const spotlightActorIds = spotlightGather
    ? new Set([spotlightGather.heroineId, ...spotlightGather.performerIds])
    : null;
  const isTick8 = hourOfDay === 8 && isStartOfClockHour(state.tick);

  const constructionByWorkerId = buildConstructionCrewIndex(updatedBuildings);
  const workplaceOpts = { buildingById, constructionByWorkerId };
  const allHumans: Entity[] = [];
  const humanIds = new Set<number>();

  for (const h of byType[EntityType.Human]) {
    if (!h.alive) continue;
    allHumans.push(h);
    humanIds.add(h.id);
  }
  for (const born of newEntities) {
    if (born.alive && born.type === EntityType.Human && !humanIds.has(born.id)) {
      allHumans.push(born);
      humanIds.add(born.id);
    }
  }

  const workersByWorkplace = new Map<number, Entity[]>();
  const workerIndexById = new Map<number, number>();
  for (const h of allHumans) {
    if (!h.alive || !isPlayerHuman(h) || h.isJuvenile) continue;
    const siteId = h.workerBuildingId;
    if (siteId == null) continue;
    const bucket = workersByWorkplace.get(siteId);
    if (bucket) {
      workerIndexById.set(h.id, bucket.length);
      bucket.push(h);
    } else {
      workersByWorkplace.set(siteId, [h]);
      workerIndexById.set(h.id, 0);
    }
  }

  const livingHumanAt = (id: number | null | undefined): Entity | undefined => {
    if (id == null) return undefined;
    const h = entityById.get(id);
    return isSettlerRelationshipEntity(h) ? h : undefined;
  };

  const residenceOccupants = ctx.residenceOccupants ?? buildResidenceOccupantIndex(playerHumans);
  ctx.residenceOccupants = residenceOccupants;
  if (!ctx.roadAvoidance) {
    ctx.roadAvoidance = buildRoadAvoidanceIndex(width, height, roadBuildings);
  }
  const churchStrength = getChurchStrength(updatedBuildings, playerHumans);

  // Nearby completed player wells are cached once per tick, not scanned from every building per settler.
  const nearbyWells = updatedBuildings.filter((b) => b.type === BuildingType.Well
    && b.completed && b.faction !== 'rival');

  const staffedHospitals: Building[] = [];
  const staffedTownHalls: Building[] = [];
  /**
   * The village's leisure venues, gathered **once per tick** rather than once per idle settler.
   *
   * `idleDestination` used to scan `state.buildings` for each idle adult on every tick — a village of a
   * thousand settlers over a hundred buildings is a hundred thousand comparisons per tick, on a loop that
   * is already fighting to deliver 10× (`[SpeedDiag]`, `gameLoop`). The list is a tick-stable fact, so it
   * is computed where the other per-tick lists are and handed to the behaviour.
   */
  const idleVenues: Building[] = [];
  for (const b of updatedBuildings) {
    if (!b.completed || b.faction === 'rival') continue;
    if (
      b.type === BuildingType.Tavern ||
      b.type === BuildingType.Market ||
      b.type === BuildingType.TownHall ||
      b.type === BuildingType.Church
    ) {
      idleVenues.push(b);
    }
  }
  for (const b of updatedBuildings) {
    if (!b.completed || b.faction === 'rival' || b.occupants.length === 0) continue;
    if (b.type === BuildingType.Hospital) staffedHospitals.push(b);
    else if (b.type === BuildingType.TownHall) staffedTownHalls.push(b);
  }

  // Completed player residences, and the leisure-venue pools, are constant for this whole frame:
  // `building.completed` has exactly one writer in the repo (`dailyBuildingEconomy.tickBuildingProgress`,
  // daily layer only), `building.type` has none, and building `faction` has none — every
  // `.faction =` write is on an entity. Both were previously re-derived per entity: the residence
  // list was re-filtered for every courting pair (`updatedBuildings.filter(isResidenceBuilding)`)
  // and the venue pool re-filtered for every leisure choice (2.98 calls/tick measured). Both are
  // built on FIRST USE rather than unconditionally, so a tick that never reaches the courtship
  // branch or the leisure picker does no extra work — the probe showed an eager version of this
  // raised the `isResidenceBuilding` filter from 3 887 to 9 184 calls over 8 640 ticks. The pools are
  // keyed by the requested type list and produced by the same predicate over the same array, so
  // their contents and order are identical to the per-call filter.
  let playerResidences: Building[] | undefined;
  const playerResidencesFor = (): Building[] =>
    (playerResidences ??= updatedBuildings.filter(isResidenceBuilding));
  const completedPoolByKey = new Map<string, Building[]>();
  const completedPoolOf = (types: readonly BuildingType[]): Building[] => {
    const key = types.join(',');
    let pool = completedPoolByKey.get(key);
    if (pool === undefined) {
      pool = updatedBuildings.filter(
        (b) => b.completed && b.faction !== 'rival' && types.includes(b.type),
      );
      completedPoolByKey.set(key, pool);
    }
    return pool;
  };
  const pickSocialBuilding: SocialBuildingPicker = (types, salt) => {
    const pool = completedPoolOf(types);
    if (pool.length === 0) return undefined;
    const safeSalt = Number.isFinite(salt) ? Math.abs(Math.floor(salt)) : 0;
    return pool[safeSalt % pool.length];
  };

  const chatHints = chatHintsFromWorld({
    season,
    weather: state.weather,
    festivalActive: state.festival?.active,
    food: state.resources.food,
  });

  const resolveChatPartner = (id: number): Entity | null => {
    const partner = entityById.get(id);
    return isSettlerRelationshipEntity(partner) ? partner : null;
  };

  const settlerChat = (
    entity: Entity,
    context: HumanChatContext,
    chance: number,
    partner: Entity | null = null,
  ) => maybeDialogueChat(entity, partner, context, state.tick, chance, chatHints);

  const settlerPairChat = (
    entityA: Entity,
    entityB: Entity,
    context: HumanChatContext,
    chance: number,
  ) => simSettlerPairChat(entityA, entityB, context, chance, state.tick, chatHints);

  const ambientChatNeighbors = (self: Entity): Entity[] =>
    simAmbientChatNeighbors(self, state.tick, humanSocialGrid, allHumans, width, height);

  const schoolAssignments = syncSchoolAssignments(allHumans, updatedBuildings, isNewCalendarDay, config.speed);

  // A school day needs its teacher in the classroom too: sample that presence once for the tick.
  const schoolsWithTeacherPresent = new Set<number>();
  for (const school of findStaffedSchools(updatedBuildings)) {
    if (hasTeacherPresent(school, entityById)) schoolsWithTeacherPresent.add(school.id);
  }

  // Marching-raider groups for patrol reveal depend on the tick's raid state, not on the guard
  // looking, so the first barracks watch on shift builds the index and the rest reuse it.
  let patrolRevealIndex: PatrolRevealIndex | undefined;

  // The village anchor was re-derived for every visitor, rival and barracks guard in this loop.
  // Only the building half may be hoisted: nothing this loop reaches removes a building from
  // `updatedBuildings` or flips one's `completed`, `type`, `faction` or geometry, so the hall/house
  // answer is constant for the tick — while the settler half averages positions this very loop moves
  // and drops settlers from, so caching that would hand later entities a stale anchor. `undefined`
  // means "not resolved yet"; `null` means "no hall and no house, ask the entities every time".
  let buildingCampAnchor: { x: number; y: number } | null | undefined;
  const getCampAnchor = (): { x: number; y: number } => {
    if (buildingCampAnchor === undefined) {
      buildingCampAnchor = getPlayerCampCenterFromBuildings(updatedBuildings);
    }
    return buildingCampAnchor ?? getPlayerSettlerCenter(state);
  };

  const advancePregnancy = (entity: Entity, conceivedToday: boolean): void => {    if (
      entity.alive &&
      isPlayerHuman(entity) &&
      entity.gender === 'female' &&
      entity.pregnant &&
      !conceivedToday &&
      entity.pregnancyProgress !== undefined
    ) {
      tickPregnancyAndBirth(state, ctx, entity, { livingHumanAt });
    }
  };

  // Lodging runs for every settler each tick; build the hotel list and bed counts once so a
  // candidate hotel never rescans every entity for each settler.
  const hotelLodging = createHotelLodgingIndex(updatedBuildings, allHumans, buildingById, entityById);
  // Ceremony seats are the same id-sorted ranks for every settler; build them once per tick.
  const ceremonySeats = state.electionCeremony ? buildCeremonySeatIndex(state) : undefined;

  for (const entity of allHumans) {
    if (!entity.alive) continue;
    const previousIndoorBuildingId = entity.indoorBuildingId;
    entity.indoorBuildingId = undefined;
    reconcileAffairPartner(entity, entityById);

    // Common updates
    if (isNewCalendarDay) {
      if (entity.isJuvenile && isPlayerHuman(entity)) {
        creditChildSchoolDay(entity);
      }
      syncHumanAgeFromCalendar(entity, state);
    }

    entity.flash = Math.max(0, entity.flash - 1);
    if (entity.combatTicks && entity.combatTicks > 0) {
      entity.combatTicks--;
      if (entity.combatTicks <= 0) entity.combatTicks = 0;
    }
    // Children cannot pursue prey, including stale targets carried by old saves.
    if (entity.isJuvenile) {
      entity.huntTargetId = undefined;
    } else if (entity.huntTargetId) {
      const prey = entityById.get(entity.huntTargetId);
      if (!prey?.alive) entity.huntTargetId = undefined;
    }

    if (isNewCalendarDay && tryDailyHumanMortality(state, entity, updatedBuildings, entityById)) {
      syncEntityGrids(ctx, entity);
      continue;
    }

    const isPrisoner = entity.prisonBuildingId != null;

    entity.reproductionCooldown = Math.max(0, entity.reproductionCooldown - 1);
    if (entity.gender && entity.relationshipStatus === undefined) {
      entity.relationshipStatus = 'single';
    }

    let conceivedToday = false;
    if (isNewCalendarDay && !isPrisoner && isPlayerHuman(entity)) {
      conceivedToday = tryDailyConception(state, ctx, entity);
      tryDailyAmicableDivorce(state, entity, entityById, updatedBuildings, playerHumans);
    }

    // The affair encounter is the one daily affair decision that needs the settler *away from their
    // spouse*, so it is evaluated at a per-settler waking hour rather than for the whole settlement
    // at midnight — see `affairEncounterHourOfDay`. It stays once per settler per day, and at the
    // same chance: `personDayRoll` is keyed on the colony day, not the tick-of-day, so this is the
    // same single roll the midnight gate made, just sampled at an hour its own gates can pass.
    if (
      !isPrisoner &&
      isPlayerHuman(entity) &&
      // Compare like with like: the owner's stagger is an **hour** (06:00–19:00), and
      // `getTickOfDay` returns a tick-of-day (0–71), so the old test could only ever match clock
      // hours 02:00–06:20 — asleep at home, where the encounter's own gates refuse it. Most married
      // settlers therefore never reached the establishment owner at all.
      hourOfDay === affairEncounterHourOfDay(entity.id, state.tick) &&
      isStartOfClockHour(state.tick) &&
      !isAsleepAtHome(entity, buildingById, hourOfDay) &&
      !isSettlerLodgingAtHotel(entity, updatedBuildings, hourOfDay)
    ) {
      // Gossip is a daytime interaction, not an automatic midnight rumour.
      tryDailyAffairGossip(
        state,
        entity,
        entityById,
        updatedBuildings,
        buildingById,
        churchStrength,
        playerHumans,
      );
      tryDailyAffairEncounter(
        state,
        entity,
        entityById,
        updatedBuildings,
        buildingById,
        churchStrength,
        hourOfDay,
        humanSocialGrid,
        playerHumans,
        width,
        height,
      );
    }

    tryGraduateHumanChild(entity, config.size, config.speed, (e) => {
      if (isPlayerHuman(e)) applyEducationGraduation(state, e);
    });

    const schoolTarget = schoolAssignments.get(entity.id);

    if (schoolTarget) {
      // Schoolyard rumours and new bonds require an awake child at school hours.
      // Run once per day at noon, not at midnight while the children sleep.
      if (
        hourOfDay === 12 &&
        isStartOfClockHour(state.tick) &&
        !isAsleepAtHome(entity, buildingById, hourOfDay)
      ) {
        trySchoolyardGossip(state, entity, entityById, updatedBuildings, playerHumans);
        tryFormSchoolyardBond(state, entity);
      }
    }

    const workplace = findHumanWorkplace(entity, updatedBuildings, workplaceOpts);
    const isInnkeeper =
      entity.job === JobType.Innkeeper && workplace?.type === BuildingType.Tavern && workplace.completed;

    const ordinaryWorkplace =
      workplace != null &&
      workplace.type !== BuildingType.Church &&
      workplace.type !== BuildingType.TownHall &&
      workplace.type !== BuildingType.Prison &&
      workplace.type !== BuildingType.Hospital;
    const isHospitalDoctor = entity.job === JobType.Doctor
      && workplace?.type === BuildingType.Hospital && workplace.completed;
    const onHospitalShift = !!(isHospitalDoctor && isHospitalDoctorOnShift(workplace, state.tick, entity.id));
    const hospitalCommuteDue = !!(isHospitalDoctor && isHospitalDoctorCommuteTime(
      workplace,
      state.tick,
      entity.id,
      commuteLeadHoursFor(commuteDistanceToBuilding(entity, workplace, false), config.speed),
    ));
    const onSchoolShift = schoolTarget != null && isSchoolTime(state.tick, hourOfDay);
    const schoolResidence = entity.residenceBuildingId == null
      ? undefined : buildingById.get(entity.residenceBuildingId);
    const schoolLeadHours = schoolTarget
      ? Math.min(MAX_ASSIGNABLE_COMMUTE_HOURS, Math.ceil(commuteLeadHoursFor(
        commuteDistanceFromResidence(entity, schoolResidence, schoolTarget),
        config.speed,
      )))
      : 0;
    const schoolCommuteDue = schoolTarget != null && isWorkDay(state.tick)
      && hourOfDay >= SCHOOL_START_HOUR - schoolLeadHours && hourOfDay < SCHOOL_START_HOUR;
    const onDayJobShift =
      (goWorkTime &&
        !isInnkeeper &&
        (ordinaryWorkplace ||
          (entity.job === JobType.Soldier &&
            isBarracksGuard(entity.id, entity.workerBuildingId, updatedBuildings)))) ||
      onSchoolShift;
    const onOfficialShift =
      entity.job === JobType.Official &&
      workplace?.type === BuildingType.TownHall &&
      workplace.completed &&
      goWorkTime;

    const venueWorkerIndex = workplace ? workplace.occupants.indexOf(entity.id) : -1;
    const venueWorkerCount = workplace?.occupants.length ?? 0;
    const usesAutoVenueShifts = workplace?.staffingMode !== 'manual';
    // A festival keeps the Tavern open to visitors (`venueSchedule.isFestivalOverrideActive`) — and that
    // is venue availability, never the Innkeeper's duty: crediting it pays for all 24 hours of a
    // festival day and pins every innkeeper at maximum fatigue, which costs the tavern its output.
    const onTavernShift =
      isInnkeeper &&
      (venueWorkerIndex >= 0 && usesAutoVenueShifts
        ? isVenueWorkerServiceHour(state, 'tavern', hourOfDay, venueWorkerIndex, venueWorkerCount)
        : isVenueServiceHour(state, 'tavern', hourOfDay));

    const isHotelier =
      entity.job === JobType.Hotelier && workplace?.type === BuildingType.Hotel && workplace.completed;
    const onHotelShift =
      isHotelier && (venueWorkerIndex >= 0 && usesAutoVenueShifts
        ? isVenueWorkerServiceHour(state, 'hotel', hourOfDay, venueWorkerIndex, venueWorkerCount)
        : isVenueServiceHour(state, 'hotel', hourOfDay));

    const onMoonPriestShift =
      entity.job === JobType.Priest &&
      workplace?.type === BuildingType.Church &&
      workplace.completed &&
      isOnMoonHowlerNightShift(state.tick, hourOfDay);
    // Ordinary service: the church is a day-shift post too, so the priest works the colony's window
    // (`ordinaryWorkplace` excludes the church because this predicate, not the generic one, owns it).
    const onPriestShift =
      entity.job === JobType.Priest &&
      workplace?.type === BuildingType.Church &&
      workplace.completed &&
      (goWorkTime || onMoonPriestShift);

    const isPrisonGuardAtPost =
      entity.job === JobType.PrisonGuard && workplace?.type === BuildingType.Prison && workplace.completed;
    const prisonShift = isPrisonGuardAtPost
      ? prisonShiftForGuard(entity.id, prisonGuardIds(state, workplace.occupants ?? []), state.tick)
      : null;
    const onPrisonShift = prisonShift != null && shiftCoversHour(prisonShift, hourOfDay);
    const prisonShiftStartHour = prisonShift?.startHour ?? workSchedule.startHour;
    const prisonCommuteLeadHours = isPrisonGuardAtPost && prisonShift != null && workplace
      ? commuteLeadHoursFor(commuteDistanceToBuilding(entity, workplace, false), config.speed)
      : 0;
    // Prison watches run every day, including weekends. Start walking before the shift even when the
    // ordinary evening routine would otherwise keep a guard at home.
    const prisonCommuteDue = isPrisonGuardAtPost && prisonShift != null && (
      onPrisonShift || isWithinWorkCommuteLead(state.tick, prisonShiftStartHour, prisonCommuteLeadHours)
    );

    // Attendance is a schedule fact, not a viewport one: crediting it above the off-screen throttle
    // is what stops a workplace's output from tracking where the camera happens to be.
    const onJobShift =
      onDayJobShift || onTavernShift || onHotelShift || onHospitalShift || onMoonPriestShift || onPrisonShift;
    // Work wins over revelry: the festival gathering is the free-time case (see `isFestivalGatherer`).
    const festivalGathering = isFestivalGatherer(
      hourOfDay,
      state.festival?.active,
      onJobShift || onOfficialShift || hospitalCommuteDue || prisonCommuteDue || schoolCommuteDue,
      isInnkeeper,
    );
    const attendanceTarget = workplace ? humanBuildingTarget(workplace, entity.id, false) : null;
    const atPost = attendanceTarget != null
      && Math.hypot(entity.x - attendanceTarget.x, entity.y - attendanceTarget.y) <= WORK_ARRIVE_DISTANCE;
    const wasInsideWorkplace = workplace != null && previousIndoorBuildingId === workplace.id;
    // Hunters work away from the spot; every other scheduled trade must be at its post or inside it.
    const hunterInField = entity.job === JobType.Hunter && entity.huntTargetId != null;
    if (isPlayerHuman(entity) && (onJobShift || onOfficialShift || onPriestShift)) {
      recordScheduleWorkTick(entity);
      if (atPost || wasInsideWorkplace || hunterInField) recordPresentWorkTick(entity);
    }

    const recoveringSleep = (entity.needs?.sleepRecoveryUntilTick ?? 0) > state.tick;
    const inFocus = !focus || isInFocus(entity, focus);
    const active =
      !isPrisoner &&
      (spotlightActorIds?.has(entity.id) || inFocus ||
        (recoveringSleep && !onJobShift) ||
        (entity.needs?.breakUntilRecovered === true && !onJobShift) ||
        hospitalCommuteDue ||
        schoolCommuteDue || onSchoolShift ||
        prisonCommuteDue ||
        entity.pregnant ||
        hasAffairPartner(entity, entityById) ||
        (entity.affairProgress ?? 0) >= 20 ||
        (state.tick + entity.id) % OFFSCREEN_HUMAN_THROTTLE === 0);

    // A ceremony holds its **attendees**, not the whole village: the owner's *"they again in a circle"*
    // was a thousand settlers sharing sixty ring slots. Everyone else keeps their day.
    const inElectionCeremony =
      !prisonCommuteDue && state.electionCeremony != null && isPlayerHuman(entity) && isCeremonyAttendee(state, entity.id, ceremonySeats);
    // Only the selected actors receive exclusive gathering movement; everyone else
    // keeps the normal commute, social and work priority rules.
    const inSpotlightGathering = spotlightActorIds?.has(entity.id) === true;

    const onDutyForSleep = onJobShift || onOfficialShift || onPriestShift || schoolCommuteDue;
    const sleep = observeHumanSleep(entity, {
      hourOfDay, previousIndoorBuildingId, onDuty: onDutyForSleep, recoveringSleep,
      buildings: updatedBuildings, buildingById, entityById, tick: state.tick,
    });
    const sleepingForNeeds = sleep.sleeping;
    let ateMeal = false;
    if (isPlayerHuman(entity)) {
      advanceHumanNeeds(entity, {
        tick: state.tick, sleeping: sleepingForNeeds,
        working: (onJobShift || onOfficialShift || onPriestShift) && entity.workerBuildingId != null,
        nightDuty: (onJobShift || onOfficialShift || onPriestShift) && isNightHour(hourOfDay),
        moving: Math.hypot(entity.vx, entity.vy) > 0.1,
        hasWell: hasNearbyWell(entity, nearbyWells),
        hasHospital: sleep.hasHospital,
      });
      if (resolveHumanNeedsIntent(entity, state.tick, sleepingForNeeds && !sleep.hasHospital) === 'eat') {
        ateMeal = tryEatColonyMeal(entity, state, hourOfDay);
      }
      if (hasFatalStarvation(entity)) {
        killFromStarvation(entity, state, updatedBuildings, entityById);
        syncEntityGrids(ctx, entity);
        continue;
      }
    }

    // Imprisoned foreigners do not work or roam: no fictional metabolism/exhaustion.
    if (entity.warCaptive && !isPlayerHuman(entity)) {
      tryEatColonyMeal(entity, state, hourOfDay);
    }

    if (isPrisoner) {
      entity.vx = 0;
      entity.vy = 0;
      const prison = buildingById.get(entity.prisonBuildingId!);
      if (prison) {
        const dx = prison.x - entity.x;
        const dy = prison.y - entity.y;
        const dist = Math.hypot(dx, dy) || 1;
        if (dist <= 14) enterHumanBuilding(entity, prison);
        if (dist > 14) {
          entity.vx = (dx / dist) * Math.min(dist, 1.2);
          entity.vy = (dy / dist) * Math.min(dist, 1.2);
          applyHumanWalkStep(entity, 1);
        }
      }
      tickDialogue(entity, resolveChatPartner);
      advancePregnancy(entity, conceivedToday);
      syncEntityGrids(ctx, entity);
      continue;
    }

    if (entity.raidDeploymentId) {
      entity.vx = 0;
      entity.vy = 0;
      advancePregnancy(entity, conceivedToday);
      syncEntityGrids(ctx, entity);
      continue;
    }

    // Verified sleep suppresses ambient speech; scripted dialogue remains owned by the dialogue tree.
    tickDialogue(entity, resolveChatPartner);
    if (sleepingForNeeds) endAmbientHumanChat(entity);

    if (
      active &&
      !sleepingForNeeds &&
      isPlayerHuman(entity) &&
      !entity.faction &&
      (entity.chatTicks ?? 0) <= 0 &&
      (state.tick + entity.id) % SOCIAL_STAGGER === 0
    ) {
      const expectantSpouse = entity.partnerId == null ? null : resolveChatPartner(entity.partnerId);
      tryAmbientRandomDialogue(
        entity,
        ambientChatNeighbors(entity),
        state.tick,
        0.036 * PER_TICK_RATE_SCALE,
        chatHints,
        {
          pregnant: !!entity.pregnant,
          expectingPartner: Boolean(expectantSpouse?.pregnant && expectantSpouse.partnerId === entity.id),
          renffr: isRenffrGossipActive(state),
          workHour: goWorkTime,
          night: prefersHomeTonightFor(workSchedule, entity.id, state.tick, hourOfDay),
        },
      );
    }

    if (!active) {
      if (previousIndoorBuildingId != null && buildingById.get(previousIndoorBuildingId)?.completed) {
        entity.indoorBuildingId = previousIndoorBuildingId;
      }
      syncEntityGrids(ctx, entity);
      continue;
    }

    // Trade-route merchants
    if (entity.faction === 'trade_caravan') {
      const target = getCaravanMoveTarget(state, entity);
      if (target) {
        steerEntityToward(entity, target.x, target.y, config.speed, target.speedMult);
        applyHumanWalkStep(entity, 1);
        tryAdvanceCaravanLeg(state, entity);
      }
      syncEntityGrids(ctx, entity);
      continue;
    }
    // Visitors & rival settlers
    if (entity.faction === 'visitor' || entity.faction === 'rival') {
      const camp =
        entity.faction === 'visitor'
          ? state.visitorGroups.find((g) => g.id === entity.groupId)
          : state.rivalSettlements.find((r) => r.id === entity.groupId);

      if (camp) {
        const marching = entity.faction === 'rival' && entity.groupId && isRaidMarchingForRival(state, entity.groupId);
        if (entity.faction === 'rival') {
          entity.hiddenFromPlayer = Boolean(marching && !entity.detectedByPatrol);
        }
        const playerCenter = marching ? getCampAnchor() : null;
        const cx = marching && playerCenter ? playerCenter.x : 'campX' in camp ? camp.campX : 0;
        const cy = marching && playerCenter ? playerCenter.y : 'campY' in camp ? camp.campY : 0;

        let speedMult = entity.faction === 'visitor' ? 0.62 : 0.4;
        if (marching) {
          const raidEvt = state.pendingRaidEvents?.find((r) => r.rivalId === entity.groupId);
          const marchTiles = raidEvt?.marchDistanceTiles ?? 30;
          speedMult = Math.max(0.38, 0.92 - marchTiles / 130);
        }

        if (marching) {
          steerEntityToward(entity, cx, cy, config.speed, speedMult);
          applyHumanWalkStep(entity, 1);
        } else if (
          entity.faction === 'visitor' &&
          steerVisitorToHotel(entity, updatedBuildings, config.speed * speedMult)
        ) {
          // Hotel lodging owns its single walk step, including the road-speed multiplier.
        } else {
          tickFactionCampWander(state, entity, cx, cy, updatedBuildings, config.speed * speedMult);
        }

        const dist = Math.hypot(cx - entity.x, cy - entity.y);
        if (marching && dist < 90) entity.combatTicks = Math.max(entity.combatTicks ?? 0, 8);

        const village = getCampAnchor();
        const nearVillage = Math.hypot(entity.x - village.x, entity.y - village.y) < 110;
        const chatChance =
          (entity.faction === 'visitor' ? (nearVillage ? 0.055 : 0.03) : 0.025) * PER_TICK_RATE_SCALE;
        settlerChat(entity, entity.faction === 'visitor' ? 'visitor' : 'rival', chatChance);
      }
      syncEntityGrids(ctx, entity);
      continue;
    }

    if (isWinter && !canHeat && isTick8) entity.flash = 5;

    let suppressIdle = false;
    let onSchedule = false;


    // A crew larger than the three shifts takes days off in turn, and a resting guard is *free* — he is
    // not on the colony work day. Without this he still walked to the prison for `goWorkTime`, so an
    // off-duty guard stood on a post he was not rostered for and had no day off at all.
    const offDutyPrisonGuard = isPrisonGuardAtPost && prisonShift == null;

    // A resting settler takes an actual off-duty pause, not merely a status label.
    // On-duty and emergency movement remain owned by their existing systems.
    const takingNeedsBreak = isPlayerHuman(entity) && !onJobShift &&
      !onOfficialShift && !onPriestShift && !schoolCommuteDue &&
      resolveHumanNeedsIntent(entity, state.tick, sleepingForNeeds) === 'takeBreak';

    const commuteStartHour = isPrisonGuardAtPost ? prisonShiftStartHour : workSchedule.startHour;
    const commuteLeadHours = workplace
      ? commuteLeadHoursFor(commuteDistanceToBuilding(entity, workplace, false), config.speed)
      : 0;
    const workCommuteDue = workplace != null
      && (isPrisonGuardAtPost || isWorkDay(state.tick))
      && (goWorkTime || onWorkCommuteHours
        || isWithinWorkCommuteLead(state.tick, commuteStartHour, commuteLeadHours));

    const stayIn =
      !inSpotlightGathering &&
      !festivalGathering &&
      !onTavernShift &&
      !onMoonPriestShift &&
      !workCommuteDue &&
      (prefersHomeTonightFor(workSchedule, entity.id, state.tick, hourOfDay)
        || (recoveringSleep && !onJobShift));

    const allowFreeRoam = !inSpotlightGathering && !takingNeedsBreak && (festivalGathering || (!onJobShift && !hospitalCommuteDue && !prisonCommuteDue && !schoolCommuteDue && !stayIn));
    const socialBlockedByJob = isInnkeeper
      ? onTavernShift
      : ordinaryWorkplace && isWorkScheduleHour(workSchedule, hourOfDay) && goWorkTime;
    const socialTime =
      !inSpotlightGathering && !hospitalCommuteDue && !prisonCommuteDue && !schoolCommuteDue && (
        (!socialBlockedByJob && allowSocialLifeFor(workSchedule, hourOfDay, false, state.tick)) ||
        (allowFreeRoam && isPlayerHuman(entity))
      );

    const huntingWere = anyActiveHowler
      ? findClosestEntityInRadius(
          mobileGrid,
          entity.x,
          entity.y,
          110,
          isActiveMoonHowler,
          'human_hunt',
          byType[EntityType.Werewolf],
        )
      : undefined;

    // Cross-map lodging: a walk home too long for the hours left before the sleep hour takes a
    // reserved hotel bed instead, including the time spent walking there.
    const lodgingHotel =
      stayIn &&
      !onJobShift &&
      !huntingWere &&
      !inElectionCeremony &&
      !inSpotlightGathering &&
      !festivalGathering &&
      hasResidenceAssignment(entity)
        ? lodgingHotelFor(entity, updatedBuildings, allHumans, state.tick, hotelLodging)
        : undefined;

    if (!lodgingHotel && isPlayerHuman(entity) && entity.hotelStayBuildingId != null) {
      hotelLodging.release(entity.hotelStayBuildingId);
      checkoutVisitor(entity);
    }

    if (onMoonPriestShift) {
      suppressIdle = true;
      onSchedule = true;
      const scared = state.tick < (state.moonHowlerPriestsFleeUntil ?? -1);
      const targetWere = nearestActiveMoonHowler(entity, byType[EntityType.Werewolf]);
      if (targetWere) {
        const hdx = targetWere.x - entity.x;
        const hdy = targetWere.y - entity.y;
        const hdist = Math.hypot(hdx, hdy) || 1;
        const dir = scared ? -1 : 1;
        const mult = scared ? 1.35 : 1.1;
        entity.vx = (hdx / hdist) * config.speed * mult * dir;
        entity.vy = (hdy / hdist) * config.speed * mult * dir;
        faceVelocity(entity);
      } else if (workplace) {
        commuteHumanToBuilding(entity, workplace, config.speed, false, WORK_COMMUTE_RUSH);
      }
    } else if (huntingWere) {
      const fdx = entity.x - huntingWere.x;
      const fdy = entity.y - huntingWere.y;
      const fdist = Math.sqrt(fdx * fdx + fdy * fdy) || 1;
      const fleeMult = humanFleeMult * evaluateTraitInfluence(entity, ESCAPE_CONTEXT).factor;
      entity.vx = (fdx / fdist) * config.speed * 1.6 * fleeMult;
      entity.vy = (fdy / fdist) * config.speed * 1.6 * fleeMult;
      faceVelocity(entity);
      suppressIdle = true;
      onSchedule = true;
      settlerChat(entity, 'fear', 0.14 * PER_TICK_RATE_SCALE);
    } else if (spotlightGather && inSpotlightGathering) {
      const target = getSpotlightGatherTarget(spotlightGather, entity.id);
      if (target) {
        const dx = target.x - entity.x;
        const dy = target.y - entity.y;
        const dist = Math.hypot(dx, dy);
        if (dist > 9) {
          // Route steering writes velocity only; the normal human walk applies one collision-safe step.
          const route = steerWithPath(entity, target.x, target.y, config.speed * 1.2, `spotlight_${spotlightGather.id}_${entity.id}`);
          if (route === 'direct') {
            entity.vx = (dx / dist) * config.speed * 1.2;
            entity.vy = (dy / dist) * config.speed * 1.2;
            faceVelocity(entity);
          }
        } else {
          entity.vx = 0;
          entity.vy = 0;
        }
        suppressIdle = true;
        onSchedule = true;
      }
    } else if (inElectionCeremony && state.electionCeremony) {
      const target = getElectionGatherTarget(state, entity.id, ceremonySeats);
      const dx = target.x - entity.x;
      const dy = target.y - entity.y;
      const dist = Math.hypot(dx, dy) || 1;
      if (dist > 10) {
        entity.vx = (dx / dist) * config.speed * 1.15;
        entity.vy = (dy / dist) * config.speed * 1.15;
        faceVelocity(entity);
      } else {
        entity.vx = 0;
        entity.vy = 0;
      }
      suppressIdle = true;
      onSchedule = true;
    } else if (festivalGathering) {
      const performers = state.visitorGroups.find((group) => group.kind === 'performers' && group.daysLeft > 0);
      const hall = staffedTownHalls.length > 0 ? staffedTownHalls[entity.id % staffedTownHalls.length] : undefined;
      const square = state.buildings.find((building) =>
        building.type === BuildingType.Square && building.completed && building.faction !== 'rival'
      );
      const targetX = square ? square.x + square.width / 2 : (performers?.campX ?? (hall ? hall.x : width * 0.5));
      const targetY = square ? square.y + square.height / 2 : (performers?.campY ?? (hall ? hall.y : height * 0.5));
      // A real place per festival-goer: the old 35-slot lattice (`id % 7` × `floor(id / 7) % 5`) stacked a
      // whole village tens deep on those few points — the owner's *"they again in a circle"*.
      const stand = crowdGatherPosition(targetX, targetY, entity.id);
      const dx = stand.x - entity.x;
      const dy = stand.y - entity.y;
      const dist = Math.hypot(dx, dy) || 1;
      if (dist > 18) {
        entity.vx = (dx / dist) * config.speed * 0.72;
        entity.vy = (dy / dist) * config.speed * 0.72;
        faceVelocity(entity);
      } else {
        entity.vx = Math.sin(state.tick * 0.04 + entity.id) * config.speed * 0.12;
        entity.vy = Math.cos(state.tick * 0.035 + entity.id) * config.speed * 0.12;
        settlerChat(entity, 'social', 0.12 * PER_TICK_RATE_SCALE);
      }
      suppressIdle = true;
      onSchedule = true;
    }

    // Home commute — or, for a settler the walk home would strand, the hotel bed instead.
    if (!huntingWere && !inElectionCeremony && !inSpotlightGathering && !festivalGathering && !onJobShift && !hospitalCommuteDue && !prisonCommuteDue && !schoolCommuteDue && stayIn && hasResidenceAssignment(entity)) {
      const residence = buildingById.get(entity.residenceBuildingId!);
      if (lodgingHotel) {
        commuteHumanToBuilding(entity, lodgingHotel, config.speed, false, WORK_COMMUTE_RUSH);
        onSchedule = true;
        suppressIdle = true;
      } else if (residence?.completed) {
        commuteHumanToBuilding(entity, residence, config.speed, true, WORK_COMMUTE_RUSH);
        onSchedule = true;
        suppressIdle = true;
      }
    } else if (
      hospitalCommuteDue && workplace &&
      !huntingWere && !inElectionCeremony && !inSpotlightGathering && !festivalGathering
    ) {
      // Doctors travel for their own 00–08 / 08–16 / 16–24 shift,
      // including the evening before a midnight duty. Never pull
      // off-duty doctors to hospital merely because the village works.
      commuteHumanToBuilding(entity, workplace, config.speed, false, WORK_COMMUTE_RUSH);
      onSchedule = true;
      suppressIdle = true;
    } else if (
      !huntingWere &&
      !inElectionCeremony &&
      !inSpotlightGathering &&
      !festivalGathering &&
      goWorkTime &&
      workplace &&
      entity.job === JobType.Soldier &&
      isBarracksGuard(entity.id, entity.workerBuildingId, updatedBuildings)
    ) {
      const anchor = getCampAnchor();
      if (anchor) {
        patrolRevealIndex ??= buildPatrolRevealIndex(state, byType[EntityType.Human] ?? []);
        detectRaidersForPatrol(state, entity, patrolRevealIndex);
        const radius = 95 + (entity.id % 6) * 10;
        const angle = state.tick * 0.028 * PER_TICK_RATE_SCALE + entity.id * 2.1;
        const tx = anchor.x + Math.cos(angle) * radius;
        const ty = anchor.y + Math.sin(angle) * radius * 0.55;
        const pdx = tx - entity.x;
        const pdy = ty - entity.y;
        const pdist = Math.hypot(pdx, pdy) || 1;
        entity.vx = (pdx / pdist) * config.speed * 0.65;
        entity.vy = (pdy / pdist) * config.speed * 0.65;
        faceVelocity(entity);
        onSchedule = true;
        suppressIdle = true;
      } else if (workplace) {
        commuteHumanToBuilding(entity, workplace, config.speed, workplace.completed && isResidenceBuilding(workplace), WORK_COMMUTE_RUSH);
        onSchedule = true;
        suppressIdle = true;
      }
    } else if (!huntingWere && !inElectionCeremony && !inSpotlightGathering && !festivalGathering && (onSchoolShift || schoolCommuteDue) && !isInnkeeper && schoolTarget) {
      commuteHumanToBuilding(entity, schoolTarget, config.speed, false, WORK_COMMUTE_RUSH);
      onSchedule = true;
      suppressIdle = true;
      recordChildSchoolTick(
        entity,
        schoolTarget,
        hourOfDay,
        schoolsWithTeacherPresent.has(schoolTarget.id),
        state.tick,
      );
    } else if (
      tickTavernService({
        entity,
        workplace,
        onTavernShift,
        huntingWere: !!huntingWere,
        inElectionCeremony,
        speed: config.speed,
        tick: state.tick,
        onSchedule: () => {
          onSchedule = true;
        },
        onSuppressIdle: () => {
          suppressIdle = true;
        },
        onWorkChat: () => settlerChat(entity, 'work', 0.12),
      })
    ) {
      // Handled
    } else if (
      !huntingWere &&
      !inElectionCeremony &&
      !inSpotlightGathering &&
      !festivalGathering &&
      (goWorkTime || onWorkCommuteHours) &&
      workplace?.type === BuildingType.HuntingSpot &&
      !entity.isJuvenile &&
      isHuntingSpotHunter(workplace, entity, entityById)
    ) {
      /**
       * The move-to-prey order: the Hunting Spot sends its hunter **out to the animal**.
       *
       * Owner, 2026-09-30: *"why is it so difficult that hunter goes to the prey"*, then, on the reach,
       * *"120 px is way to far, its 1800's they dont have guns"*. Both halves are one order: with a
       * contact-distance reach (`huntingSpot.huntingKillReach`) a hunter who holds position takes
       * nothing, so the assigned hunter walks to the animal the spot is actually going to shoot —
       * `huntingSpotTarget`, the same commitment the shot reads — and holds beside it. A wolf does
       * exactly this every tick in `tickLayerSystems`; the free-roam hunter does it in
       * `humanHuntingBehavior`; this was the one hunter that did not.
       *
       * This sits in the *work-commute* branch rather than the shift branch above it because that is the
       * one a spot's worker actually runs in: measured with the game's own workforce assignment, a
       * hunter stood frozen at its post (`v=(0,0)`) through a whole working day while its committed deer
       * walked from 193 px to 209 px away. Suit the movement to the branch that runs, not the one that
       * looks right.
       */
      const spotPrey = huntingSpotTarget(workplace, entity, entityById, byType);
      const chase = spotPrey ? huntingSpotChaseTarget(workplace, entity, entityById, byType) : null;
      // Record who is after what. This is the field the map draws its dashed hunt line from
      // (`renderer/humans.ts`) and the one `buildHuntTargetByPreyIndex` indexes, which is how the prey's
      // own flee rule knows not to bolt from the settler hunting it (`tickLayerSystems`).
      entity.huntTargetId = spotPrey ? spotPrey.id : undefined;
      // Record the contact while it is happening: the spot's production pass samples an instant and would
      // otherwise never see the hunter beside the animal (measured — see `HUNTING_SPOT_STRIKE_GRACE_TICKS`).
      if (spotPrey && Math.hypot(spotPrey.x - entity.x, spotPrey.y - entity.y) <= huntingKillReach(entity, spotPrey)) {
        workplace.huntingSpotInReachTick = state.tick;
      }
      if (chase) {
        // Aim where the animal is going, not where it is (`huntingPursuitPoint`), at a pace that can
        // actually close: prey do not flee, but they wander faster than a damped working walk.
        const aim = huntingPursuitPoint(chase);
        steerEntityToward(entity, aim.x, aim.y, config.speed * HUNTING_PURSUIT_SPEED_MULT);
      } else if (spotPrey) {
        // Beside the animal, or waiting for the shot: hold, because walking back to the post would open
        // the gap the contact reach needs.
        entity.vx = 0;
        entity.vy = 0;
      } else {
        // Nothing in sight: wait at the post like every other worker.
        commuteHumanToBuilding(entity, workplace, config.speed, workplace.completed && isResidenceBuilding(workplace), WORK_COMMUTE_RUSH);
      }
      onSchedule = true;
      suppressIdle = true;
    } else if (
      !huntingWere &&
      !inElectionCeremony &&
      !inSpotlightGathering &&
      !festivalGathering &&
      !offDutyPrisonGuard &&
      (goWorkTime || onWorkCommuteHours || prisonShift != null) &&
      !isInnkeeper &&
      !isHospitalDoctor &&
      workplace
    ) {
      // Leave early enough to be *at* work when the shift starts. The lead is the same for every job
      // and grows with this settler's own distance; only the clock it counts back from differs, and
      // for a prison guard that is the roster shift's start rather than the colony window.
      const commuteLeadHours = commuteLeadHoursFor(
        commuteDistanceToBuilding(entity, workplace, false),
        config.speed,
      );
      const needsToLeaveForWork = isPrisonGuardAtPost
        ? prisonCommuteDue
        : isWorkDay(state.tick) && isWithinWorkCommuteLead(state.tick, prisonShiftStartHour, commuteLeadHours);
      // A prison guard works his roster shift and nothing else: the colony window is not his day, so
      // `goWorkTime` must not put a resting guard back on the post he is taking the day off from.
      const wantsToWork = isPrisonGuardAtPost
        ? prisonShift != null && (onPrisonShift || needsToLeaveForWork)
        : goWorkTime || onWorkCommuteHours || needsToLeaveForWork;
      if (wantsToWork) {
        commuteHumanToBuilding(entity, workplace, config.speed, workplace.completed && isResidenceBuilding(workplace), WORK_COMMUTE_RUSH);
        onSchedule = true;
        suppressIdle = true;
      }
    }

    if (!inSpotlightGathering && !allowFreeRoam && onSchedule && !huntingWere) {
      entity.vx *= 0.85;
      entity.vy *= 0.85;
    }

    const huntingSuppressIdle = inSpotlightGathering
      ? suppressIdle
      : tickHumanHunting(
      state,
      ctx,
      entity,
      config,
      allowFreeRoam,
      onSchedule,
      ateMeal,
      festivalGathering,
      byType,
      mobileGrid,
      entityById,
      suppressIdle,
    );
    suppressIdle = huntingSuppressIdle;

    advancePregnancy(entity, conceivedToday);

    const atHome = shouldBeAtHomeFor(workSchedule, hourOfDay) && isNearResidence(entity, buildingById);

    // Evening out
    if (
      socialTime &&
      allowFreeRoam &&
      isEligibleToCourt(entity) &&
      hourOfDay >= EVENING_START &&
      hourOfDay <= 22 &&
      !suppressIdle &&
      personDayRoll(entity.id, state.tick, 301) > 0.35
    ) {
      const nearbySingle =
        findClosestAdaptiveInRadius(
          humanSocialGrid,
          allHumans,
          entity.x,
          entity.y,
          SOCIAL_COURTSHIP_RADIUS,
          (h) => isEligibleToCourt(h) && h.id !== entity.id && !!h.gender && !!entity.gender && h.gender !== entity.gender,
          socialAdaptiveOptions('social', allHumans.length, width, height),
        ) != null;

      if (!nearbySingle) {
        // Somewhere real to be, instead of the old drift to the map centre that piled the village's idle
        // population into one chatting blob (`idleDestination` — home, a venue, or a pretty spot).
        const dest = idleDestination(state, entity, idleVenues, buildingById);
        const tx = dest.x;
        const ty = dest.y;
        const edx = tx - entity.x;
        const edy = ty - entity.y;
        const edist = Math.hypot(edx, edy) || 1;
        if (edist > 12) {
          entity.vx = (edx / edist) * config.speed * 0.45;
          entity.vy = (edy / edist) * config.speed * 0.45;
          faceVelocity(entity);
          suppressIdle = true;
        }
      }
    }

    // Courtship
    if (!onJobShift && socialTime && isEligibleToCourt(entity) && entity.gender && entity.energy > config.reproductionEnergyThreshold * 0.6) {
      const courtRange = atHome ? 120 : 80;
      const closest = findCourtshipPartner(
        entity,
        atHome,
        courtRange,
        humanSocialGrid,
        residenceOccupants,
        allHumans,
        width,
        height,
        state.tick,
      );

      if (closest) {
        const dx = closest.x - entity.x;
        const dy = closest.y - entity.y;
        const dist = Math.hypot(dx, dy) || 1;
        const livingTogether = atHome && shareResidence(entity, closest);
        const closeEnough = dist <= 10 || livingTogether;

        if (!closeEnough) {
          const chaseSpeed = atHome ? 0.35 : 0.45;
          entity.vx = (dx / dist) * config.speed * chaseSpeed;
          entity.vy = (dy / dist) * config.speed * chaseSpeed;
          faceVelocity(entity);
          suppressIdle = true;
        } else {
          entity.vx *= 0.6;
          entity.vy *= 0.6;
          suppressIdle = true;
          // The relationship owner decides how a pair is bound (new partner → progress starts at zero).
          bindCourtship(entity, closest);

          if (seededRandomForRun(`chat-court1:${entity.id}:${state.tick}`) < 0.4 * PER_TICK_RATE_SCALE) {
            settlerPairChat(entity, closest, 'courtship', 0.85);
          } else if (seededRandomForRun(`chat-court2:${entity.id}:${state.tick}`) < 0.5 * PER_TICK_RATE_SCALE) {
            settlerPairChat(entity, closest, 'courtship', 0.1);
          }

          if (entity.id < closest.id) {
            const hasPerformers = state.visitorGroups.some((g) => g.kind === 'performers' && g.daysLeft > 0);
            const courtshipFactors = evaluateTraitInfluence(entity, COURTSHIP_PROGRESS_CONTEXT).exact.orderedFactors;
            const courtRate =
              courtshipRatePerHour(socialTime) *
              (state.festival?.active ? 2 : 1) *
              (hasPerformers ? 1.35 : 1) *
              (livingTogether ? 1.5 : 1) *
              courtshipFactors[0] *
              courtshipFactors[1] *
              courtshipFactors[2] *
              PER_TICK_RATE_SCALE;

            entity.courtshipProgress = Math.min(100, (entity.courtshipProgress || 0) + courtRate);
            closest.courtshipProgress = Math.min(100, (closest.courtshipProgress || 0) + courtRate);
          }

          if (getSimRng('humanTick')() < 0.08 * PER_TICK_RATE_SCALE) {
            state.deathParticles.push({
              x: entity.x + (getSimRng('humanTick')() - 0.5) * 15,
              y: entity.y - 8,
              vx: (getSimRng('humanTick')() - 0.5) * 0.3,
              vy: -0.8 - getSimRng('humanTick')() * 0.5,
              life: 25,
              maxLife: 25,
              color: '#ff69b4',
              size: 2 + getSimRng('humanTick')() * 1.5,
              type: 'heart',
            });
          }

          tryCompleteCourtshipMarriage(
            state,
            entity,
            closest,
            playerResidencesFor(),
            playerHumans,
          );
        }
      }
    }

    // Married couples proximity — free time only: a settler on a shift keeps the post his work
    // commute gave him (a Prison is not an `ordinaryWorkplace`, so `socialTime` is true on a guard's shift).
    if (
      !onJobShift &&
      socialTime &&
      isPlayerHuman(entity) &&
      entity.gender === 'female' &&
      (entity.relationshipStatus === 'married' || entity.relationshipStatus === 'expecting') &&
      !entity.pregnant &&
      entity.partnerId &&
      entity.reproductionCooldown <= 0
    ) {
      const partner = livingHumanAt(entity.partnerId);
      if (partner?.alive) {
        const dx = partner.x - entity.x;
        const dy = partner.y - entity.y;
        const dist = Math.hypot(dx, dy) || 1;
        const together = dist < 22 || (atHome && shareResidence(entity, partner));
        if (!together && dist > 15) {
          entity.vx = (dx / dist) * config.speed * 0.3;
          entity.vy = (dy / dist) * config.speed * 0.3;
          faceVelocity(entity);
          suppressIdle = true;
        }
      }
    }

    // Secret affairs: pregnancy or expecting status no longer blocks encounters or catching
    const isMarriedOrExpecting =
      (entity.relationshipStatus === 'married' || entity.relationshipStatus === 'expecting') &&
      entity.partnerId != null;

    if (
      !inSpotlightGathering &&
      canPursueSecretAffair(entity, hourOfDay, workplace, updatedBuildings, entityById, state.tick, workSchedule) &&
      isPlayerHuman(entity) &&
      !entity.isJuvenile &&
      entity.gender &&
      isAdult(entity) &&
      entity.age < HUMAN_MAX_LIFESPAN_YEARS &&
      entity.energy > config.reproductionEnergyThreshold * 0.5 &&
      isMarriedOrExpecting &&
      // An empty marital home is a valid tryst site: only a spouse who is right there
      // blocks it (the same 22 px the affair gates use). The wider 55 px arrival window is
      // the walk-in that catches them, so the two radii must not be the same one.
      !isMaritalHomeOccupiedBySpouse(entity, entityById, buildingById, AFFAIR_SPOUSE_BLOCK_RADIUS)
    ) {
      const affairRange = 75;
      const paramour = findClosestAdaptiveInRadius(
        humanSocialGrid,
        playerHumans,
        entity.x,
        entity.y,
        affairRange,
        (h) => isValidAffairTarget(entity, h, state.tick) && !isSpouseNearby(h, entityById, AFFAIR_SPOUSE_BLOCK_RADIUS),
        socialAdaptiveOptions('social', playerHumans.length, width, height),
      );

      if (paramour) {
        const trystTarget = getAffairTrystTarget(entity, paramour, entityById, buildingById);
        const dx = trystTarget.x - entity.x;
        const dy = trystTarget.y - entity.y;
        const dist = Math.hypot(dx, dy) || 1;
        const intimate = isValidAffairTrystSite(entity, paramour, entityById, buildingById, AFFAIR_INTIMATE_RADIUS);

        if (!intimate) {
          entity.indoorBuildingId = undefined;
          entity.vx = (dx / dist) * config.speed * 0.38;
          entity.vy = (dy / dist) * config.speed * 0.38;
          faceVelocity(entity);
          suppressIdle = true;
        } else {
          entity.vx *= 0.55;
          entity.vy *= 0.55;
          suppressIdle = true;

          if (shouldLeadAffairPair(entity, paramour)) {
            settlerPairChat(entity, paramour, 'affair', 0.18);

            const churchPenalty = churchStrength > 0 ? 0.72 + (1 - churchStrength) * 0.28 : 1;
            const affairRate = (churchStrength > 0 ? 5 : 8) * (state.festival?.active ? 1.4 : 1) * churchPenalty * PER_TICK_RATE_SCALE;
            entity.affairProgress = Math.min(100, (entity.affairProgress || 0) + affairRate);
            paramour.affairProgress = Math.min(100, (paramour.affairProgress || 0) + affairRate);

            if (getSimRng('humanTick')() < 0.06 * PER_TICK_RATE_SCALE) {
              state.deathParticles.push({
                x: entity.x + (getSimRng('humanTick')() - 0.5) * 10,
                y: entity.y - 6,
                vx: (getSimRng('humanTick')() - 0.5) * 0.2,
                vy: -0.5,
                life: 18,
                maxLife: 18,
                color: '#f472b6',
                size: 2,
                type: 'heart',
              });
            }
          }

          if (
            (entity.affairProgress ?? 0) >= 45 &&
            (paramour.affairProgress ?? 0) >= 45 &&
            hasAffairPartner(entity, entityById) &&
            entity.affairPartnerId === paramour.id
          ) {
            tryExposeCaughtAffairForPair(
              state,
              entity,
              paramour,
              entityById,
              buildingById,
              updatedBuildings,
              playerHumans,
              churchStrength,
              true,
              true,
            );
          }
        }
      }
    }

    // Established affairs still happen in normal free time, but cannot steal
    // spotlight participants' movement after the gathering vector is assigned.
    if (
      !inSpotlightGathering &&
      canPursueSecretAffair(entity, hourOfDay, workplace, updatedBuildings, entityById, state.tick, workSchedule) &&
      isPlayerHuman(entity) &&
      !entity.isJuvenile &&
      hasAffairPartner(entity, entityById) &&
      !isMaritalHomeOccupiedBySpouse(entity, entityById, buildingById, AFFAIR_SPOUSE_BLOCK_RADIUS)
    ) {
      const lover = livingHumanAt(entity.affairPartnerId);
      if (lover?.alive) {
        const trystTarget = getAffairTrystTarget(entity, lover, entityById, buildingById);
        const dx = trystTarget.x - entity.x;
        const dy = trystTarget.y - entity.y;
        const dist = Math.hypot(dx, dy) || 1;
        const tryst = isValidAffairTrystSite(entity, lover, entityById, buildingById, AFFAIR_INTIMATE_RADIUS);
        if (!tryst && dist > 14) {
          entity.indoorBuildingId = undefined;
          entity.vx = (dx / dist) * config.speed * 0.32;
          entity.vy = (dy / dist) * config.speed * 0.32;
          faceVelocity(entity);
          suppressIdle = true;
        } else if (tryst) {
          // Genuine overnight tryst: enter the existing tryst building rather than
          // granting any indoor/sleep state for an outdoor romantic encounter.
          if (isNightHour(hourOfDay) && !onDutyForSleep) {
            const site = getAffairTrystBuilding(entity, lover, entityById, buildingById);
            if (site) enterHumanBuilding(entity, site);
          }
          tryExposeCaughtAffairForPair(
            state,
            entity,
            lover,
            entityById,
            buildingById,
            updatedBuildings,
            playerHumans,
            churchStrength,
            true,
            true,
          );
        }
      }
    }

    // Midday coworker banter
    if (onDayJobShift && workplace && isPlayerHuman(entity) && !entity.isJuvenile && entity.job !== JobType.Innkeeper) {
      const workplaceWorkers = workersByWorkplace.get(entity.workerBuildingId ?? -1) ?? [];
      tryWorkplaceBanter(entity, workplaceWorkers, state.tick, hourOfDay, true);
    }

    tickHumanDoctorHospitalService({
      state,
      entity,
      allHumans,
      updatedBuildings,
      onHospitalShift,
    });
    tickHumanCivicVenueService({
      state,
      entity,
      allHumans,
      updatedBuildings,
      buildingById,
      onDayJobShift: onDayJobShift || onOfficialShift,
      onHotelShift,
    });
    if (!huntingWere && !inElectionCeremony && !inSpotlightGathering && !festivalGathering) {
      tickHumanHospitalPatientCare({
        state,
        entity,
        staffedHospitals,
        onJobShift,
        speed: config.speed,
      });
    }

    if (entity.indoorBuildingId != null) suppressIdle = true;

    // Morning greetings
    if (allowFreeRoam && isPlayerHuman(entity) && !entity.isJuvenile && hourOfDay >= 6 && hourOfDay <= 9) {
      if ((state.tick + entity.id) % SOCIAL_STAGGER === 0) {
        const passer = findClosestAdaptiveInRadius(
          humanSocialGrid,
          allHumans,
          entity.x,
          entity.y,
          SOCIAL_GREETING_RADIUS,
          (h) => h.id !== entity.id && h.alive && isPlayerHuman(h) && !h.isJuvenile,
          socialAdaptiveOptions('social', allHumans.length, width, height),
        );
        tryNeighborGreeting(entity, passer, state.tick, hourOfDay);
      }
    }

    // Free time & leisure
    if (
      !inSpotlightGathering && tickHumanChildLeisure({
        state,
        entity,
        speed: config.speed,
        hourOfDay,
        onSchedule,
        allHumans,
        entityById,
        pickSocialBuilding,
        updatedBuildings,
        buildingById,
        humanSocialGrid,
        width,
        height,
        livingHumanAt,
        suppressIdleInitial: suppressIdle,
      })
    ) {
      suppressIdle = true;
    } else if (allowFreeRoam && !suppressIdle && isPlayerHuman(entity) && !entity.isJuvenile) {
      const tick = state.tick;
      const absDay = getAbsoluteCalendarDay(tick);
      const leisureSlotPeriod = 80 * TICKS_PER_HOUR;
      const leisureSlot = Math.floor(tick / leisureSlotPeriod + entity.id * 3);
      const daySpice = Math.floor(personDayRoll(entity.id, tick, 401 + leisureSlot) * 12);
      const quietBias = personDayRoll(entity.id, tick, 202) < 0.35;
      let leisureKind = (leisureSlot * 17 + entity.id * 31 + absDay * 13 + daySpice) % 12;
      if (quietBias && personDayRoll(entity.id, tick, 403 + leisureSlot) < 0.45) {
        leisureKind = leisureKind < 6 ? 10 + (leisureKind % 2) : leisureKind;
      }
      if (weekend && personDayRoll(entity.id, tick, 201) > 0.55 && leisureKind >= 8) {
        leisureKind = (entity.id + leisureSlot + absDay) % 7;
      }
      const phase = entity.id * 0x9e3779b9 + leisureSlot * 0x85ebca6b + absDay;
      let idleVx = 0;
      let idleVy = 0;

      const steerTo = (tx: number, ty: number, speedMult: number, arrive = 14, destination?: Building): boolean => {
        const dx = tx - entity.x;
        const dy = ty - entity.y;
        const dist = Math.hypot(dx, dy) || 1;
        if (dist <= arrive) {
          if (destination) enterHumanBuilding(entity, destination);
          idleVx = Math.sin(tick * 0.04 + entity.id) * config.speed * 0.08;
          idleVy = Math.cos(tick * 0.035 + entity.id) * config.speed * 0.08;
          return true;
        }
        idleVx = (dx / dist) * config.speed * speedMult;
        idleVy = (dy / dist) * config.speed * speedMult;
        return false;
      };

      const pickCompleted = (types: BuildingType[]): Building | undefined => {
        const pool = completedPoolOf(types);
        if (pool.length === 0) return undefined;
        return pool[(entity.id + leisureSlot) % pool.length];
      };

      const adultLeisure = tickAdultLeisureMotive({
        state,
        entity,
        speed: config.speed,
        allHumans,
        pickSocialBuilding,
        updatedBuildings,
        buildingById,
        humanSocialGrid,
        width,
        height,
        livingHumanAt,
        settlerChat,
        settlerPairChat,
        suppressIdleInitial: suppressIdle,
      });
      suppressIdle = adultLeisure.suppressIdle;
      const spouseEarly = adultLeisure.spouseEarly;

      if (!suppressIdle) {
        const spouse = spouseEarly ?? (entity.partnerId != null ? livingHumanAt(entity.partnerId) : undefined);
        const kids = (entity.childrenIds ?? [])
          .map((id) => livingHumanAt(id))
          .filter((k): k is Entity => !!k?.alive && !!k.isJuvenile);
        const workplaceWorkers =
          entity.workerBuildingId != null
            ? workersByWorkplace.get(entity.workerBuildingId) ?? []
            : [];
        const selfIndex = workerIndexById.get(entity.id);
        const coworkerCount = workplaceWorkers.length - (selfIndex == null ? 0 : 1);
        const targetPeerIndex = coworkerCount > 0
          ? (leisureSlot + entity.id) % coworkerCount
          : -1;
        const coworkerIndex =
          targetPeerIndex >= 0 && selfIndex != null && selfIndex <= targetPeerIndex
            ? targetPeerIndex + 1
            : targetPeerIndex;
        const coworker = coworkerIndex >= 0 ? workplaceWorkers[coworkerIndex] : undefined;

        const sneaking =
          hasAffairPartner(entity, entityById) &&
          canPursueSecretAffair(entity, hourOfDay, workplace, updatedBuildings, entityById, state.tick, workSchedule) &&
          !isAtMaritalHome(entity, entityById, buildingById);

        const bondRoll = personDayRoll(entity.id, tick, 510 + leisureSlot);
        let company: Entity | null = null;
        let companyKind: 'partner' | 'kid' | 'coworker' | null = null;
        if (!sneaking) {
          if (spouse?.alive && bondRoll < 0.4) {
            company = spouse;
            companyKind = 'partner';
          } else if (kids.length > 0 && bondRoll < 0.62) {
            company = kids[(entity.id + leisureSlot) % kids.length]!;
            companyKind = 'kid';
          } else if (coworker && bondRoll < 0.82) {
            company = coworker;
            companyKind = 'coworker';
          }
        }

        const hangWithCompany = company != null && personDayRoll(entity.id, tick, 520 + leisureSlot) < 0.78;
        if (hangWithCompany && company) {
          const sdx = company.x - entity.x;
          const sdy = company.y - entity.y;
          const sdist = Math.hypot(sdx, sdy) || 1;
          const arrive = companyKind === 'kid' ? 14 : 18;
          if (sdist > arrive) {
            idleVx = (sdx / sdist) * config.speed * 0.48;
            idleVy = (sdy / sdist) * config.speed * 0.48;
          } else if (sdist < 8) {
            idleVx = -(sdx / sdist) * config.speed * 0.1;
            idleVy = -(sdy / sdist) * config.speed * 0.1;
          } else {
            if (state.beautyGrid != null && getSimRng('humanTick')() < 0.35) {
              const pretty = pickBeautySpot(
                state.beautyGrid,
                (entity.x + company.x) / 2,
                (entity.y + company.y) / 2,
                5,
              );
              steerTo(pretty.x, pretty.y, 0.42, 14);
              if (beautyAt(state.beautyGrid, entity.x, entity.y) >= 3 && getSimRng('humanTick')() < 0.04 * PER_TICK_RATE_SCALE) {
                adjustHumanStaminaFromEnergy(entity, 0.4 * PER_TICK_RATE_SCALE);
                addFloatingText(state, entity.x, entity.y - 26, '💐', '#f9a8d4', 'brief');
              }
            } else {
              const steerToShop = (): void => {
                const shop = pickCompleted([BuildingType.Market, BuildingType.Store]);
                if (shop) {
                  const spot = venueGatherPosition(shop, entity.id);
                  steerTo(spot.x, spot.y, 0.42, 20, shop);
                } else idleVx = Math.sin(tick * 0.03 + entity.id) * config.speed * 0.1;
              };

              const shared = (Math.min(entity.id, company.id) * 31 + leisureSlot * 17 + absDay) % 6;
              if (shared <= 1) {
                const tavern = pickCompleted([BuildingType.Tavern]);
                if (tavern) {
                  const spot = venueGatherPosition(tavern, entity.id);
                  steerTo(spot.x, spot.y, 0.45, 20, tavern);
                } else {
                  steerToShop();
                }
              } else if (shared === 2) {
                steerToShop();
              } else if (shared === 3) {
                const well = pickCompleted([BuildingType.Well]);
                if (well) {
                  const spot = crowdGatherPosition(well.x + well.width / 2, well.y + well.height / 2, entity.id);
                  steerTo(spot.x, spot.y, 0.4, 12);
                }
              } else if (shared === 4) {
                const hall = pickCompleted([BuildingType.TownHall]);
                if (hall) {
                  const spot = venueGatherPosition(hall, entity.id);
                  steerTo(spot.x, spot.y, 0.42, 22, hall);
                }
              } else {
                idleVx = Math.sin(tick * 0.025 + entity.id) * config.speed * 0.12;
                idleVy = Math.cos(tick * 0.02 + company.id) * config.speed * 0.12;
              }
            }

            if (companyKind === 'partner') {
              settlerPairChat(entity, company, 'home', 0.08);
            } else if (companyKind === 'kid') {
              settlerChat(entity, 'child', 0.06, company);
            } else if (companyKind === 'coworker') {
              settlerPairChat(entity, company, 'social', 0.07);
            }
          }

          suppressIdle = true;
        } else if (leisureKind <= 2) {
          const tavern = pickCompleted([BuildingType.Tavern]);
          if (tavern) {
            const spot = venueGatherPosition(tavern, entity.id);
            const arrived = steerTo(spot.x, spot.y, 0.5, 18, tavern);
            if (arrived) {
              adjustHumanStaminaFromEnergy(entity, 0.45 * PER_TICK_RATE_SCALE);
              settlerChat(entity, 'social', 0.14 * PER_TICK_RATE_SCALE);
              if (getSimRng('humanTick')() < 0.04 * PER_TICK_RATE_SCALE) {
                addFloatingText(state, entity.x, entity.y - 14, '🍺', '#fbbf24');
              }
            }
          } else {
            const shop = pickCompleted([BuildingType.Market, BuildingType.Store]);
            if (shop) {
              const spot = venueGatherPosition(shop, entity.id);
              steerTo(spot.x, spot.y, 0.48, 16, shop);
            } else {
              steerTo(width * 0.5, height * 0.55, 0.4);
            }
          }
        } else if (leisureKind === 3) {
          const well = pickCompleted([BuildingType.Well]);
          if (well) {
            const spot = crowdGatherPosition(well.x + well.width / 2, well.y + well.height / 2, entity.id);
            const arrived = steerTo(spot.x, spot.y, 0.45, 12);
            if (arrived) {
              adjustHumanStaminaFromEnergy(entity, 0.35 * PER_TICK_RATE_SCALE);
            }
          } else {
            steerTo(
              fract(phase * 0.41) * width * 0.5 + width * 0.25,
              fract(phase * 0.73) * height * 0.5 + height * 0.25,
              0.4,
            );
          }
        } else if (leisureKind === 4) {
          const church = pickCompleted([BuildingType.Church]);
          if (church) {
            const spot = venueGatherPosition(church, entity.id);
            steerTo(spot.x, spot.y, 0.42, 18, church);
          } else {
            steerTo(width * 0.45, height * 0.45, 0.38);
          }
        } else if (leisureKind === 5) {
          const hall = pickCompleted([BuildingType.TownHall]);
          if (hall) {
            const spot = venueGatherPosition(hall, entity.id);
            steerTo(spot.x, spot.y, 0.44, 20, hall);
          } else {
            steerTo(width * 0.5, height * 0.5, 0.4);
          }
        } else if (leisureKind === 6) {
          let friend: Entity | null = spouse?.alive ? spouse : null;
          if (!friend && coworker && personDayRoll(entity.id, tick, 530) < 0.55) {
            friend = coworker;
          }
          if (!friend && (state.tick + entity.id) % SOCIAL_STAGGER === 0) {
            friend =
              findClosestAdaptiveInRadius(
                humanSocialGrid,
                allHumans,
                entity.x,
                entity.y,
                SOCIAL_FRIENDSHIP_RADIUS,
                (h) => h.id !== entity.id && h.alive && isPlayerHuman(h) && !h.isJuvenile && h.id !== entity.affairPartnerId,
                socialAdaptiveOptions('social', allHumans.length, width, height),
              ) ?? null;
          }
          if (friend) {
            const sdx = friend.x - entity.x;
            const sdy = friend.y - entity.y;
            const sdist = Math.hypot(sdx, sdy) || 1;
            if (sdist > 22) {
              idleVx = (sdx / sdist) * config.speed * 0.42;
              idleVy = (sdy / sdist) * config.speed * 0.42;
            } else if (sdist < 9) {
              idleVx = -(sdx / sdist) * config.speed * 0.12;
              idleVy = -(sdy / sdist) * config.speed * 0.12;
              if (friend.id === entity.partnerId) settlerPairChat(entity, friend, 'home', 0.1);
              else settlerPairChat(entity, friend, 'social', 0.08);
            } else {
              idleVx = Math.sin(tick * 0.03 + entity.id) * config.speed * 0.1;
              idleVy = Math.cos(tick * 0.025 + entity.id) * config.speed * 0.1;
            }
          } else {
            // As above: a destination, not the map centre.
            const idleDest = idleDestination(state, entity, idleVenues, buildingById);
            steerTo(idleDest.x, idleDest.y, 0.4);
          }
        } else if (leisureKind === 7) {
          let gx = width * 0.5;
          let gy = height * 0.5;
          if (state.festival?.active) {
            const hall = pickCompleted([BuildingType.TownHall]);
            if (hall) {
              gx = hall.x + hall.width / 2;
              gy = hall.y + hall.height + 20;
            }
          }
          const performers = state.visitorGroups.find((g) => g.kind === 'performers' && g.daysLeft > 0);
          if (performers) {
            gx = performers.campX;
            gy = performers.campY;
          }
          steerTo(gx + ((entity.id % 6) - 2.5) * 12, gy + ((entity.id % 5) - 2) * 10, 0.5, 22);
        } else if (leisureKind === 8) {
          const tree = findClosestEntityInRadius(
            ctx.treeGrid,
            entity.x,
            entity.y,
            120,
            (t) => t.type === EntityType.Tree && t.alive,
            'social',
            byType[EntityType.Tree],
          );
          if (tree) {
            steerTo(tree.x, tree.y + 8, 0.38, 16);
          } else {
            steerTo(fract(phase * 0.27) * width * 0.55 + width * 0.2, fract(phase * 0.53) * height * 0.55 + height * 0.2, 0.35);
          }
        } else if (leisureKind === 9) {
          const edge = (entity.id + leisureSlot) % 4;
          const tx = edge === 0 ? width * 0.12 : edge === 1 ? width * 0.88 : width * (0.3 + fract(phase) * 0.4);
          const ty = edge === 2 ? height * 0.12 : edge === 3 ? height * 0.88 : height * (0.3 + fract(phase * 1.3) * 0.4);
          steerTo(tx, ty, 0.4, 20);
        } else if (leisureKind === 10) {
          const a = fract(phase * 0.6180339887);
          const b = fract(phase * 0.3819660113);
          const targetX = a * width * 0.7 + width * 0.15;
          const targetY = b * height * 0.7 + height * 0.15;
          steerTo(targetX, targetY, 0.46, 18);
        } else {
          if (hasResidenceAssignment(entity)) {
            const home = buildingById.get(entity.residenceBuildingId!);
            if (home?.completed) {
              const porch = homeStandPosition(home, entity.id);
              steerTo(porch.x, porch.y, 0.4, 12, home);
            }
          } else {
            steerTo(width * 0.5, height * 0.5, 0.38);
          }
        }

        if (idleVx !== 0 || idleVy !== 0) {
          entity.vx = entity.vx * 0.5 + idleVx * 0.5;
          entity.vy = entity.vy * 0.5 + idleVy * 0.5;
          faceVelocity(entity);
          suppressIdle = true;
        }
      }
    }

    if (!suppressIdle) {
      entity.vx *= 0.9;
      entity.vy *= 0.9;
      if (Math.hypot(entity.vx, entity.vy) < 0.08) {
        entity.vx = 0;
        entity.vy = 0;
      }
    }

    // Idle stamina recovery requires an actual stationary break; keep danger,
    // scheduled duty and ceremonies free to override it.
    if (takingNeedsBreak && !onSchedule && !inSpotlightGathering && !huntingWere && !inElectionCeremony && !festivalGathering &&
      !hospitalCommuteDue && !prisonCommuteDue && !schoolCommuteDue && !entity.raidDeploymentId) {
      entity.vx = 0;
      entity.vy = 0;
    }

    // Use the same completed-road tiles the route planner prices, not proximity to a road.
    const roadMult = isOnWalkableRoadAt(entity.x, entity.y) ? ROAD_SPEED_MULT : 1.0;

    // The single integration for every walk, and the only place water and walls are enforced: the
    // steerers set a velocity without checking what it points into (see `applyHumanWalkStep`).
    if (entity.indoorBuildingId != null) {
      entity.vx = 0;
      entity.vy = 0;
    }
    applyHumanWalkStep(entity, roadMult);

    clampToMapBounds(entity, width, height);

    advanceHumanWalkAnim(entity);

    syncEntityGrids(ctx, entity);
  }

  // Ceremony/leisure/snap branches can assign a final position directly rather than going through
  // applyHumanWalkStep. Repair those positions after the full human pass so nobody can be left in
  // water, reserved decor, or a completed wall by a later route.
  if (state.worldMap) {
    const walkGrid = getReadOnlyPathGrid(state.worldMap, state.buildings);
    for (const entity of allHumans) {
      if (!entity.alive) continue;
      const tx = Math.floor(entity.x / 10);
      const ty = Math.floor(entity.y / 10);
      if (tx < 0 || ty < 0 || tx >= walkGrid.cols || ty >= walkGrid.rows) continue;
      if (walkGrid.blocked[ty * walkGrid.cols + tx] === 0) continue;
      const safe = nearestWalkableWorldPoint(state.worldMap, state.buildings, entity.x, entity.y);
      if (!safe) continue;
      entity.x = safe.x;
      entity.y = safe.y;
      entity.vx = 0;
      entity.vy = 0;
    }
  }

  if (isNewCalendarDay) {
    const activeHumans = state.entities.filter((e) => e.alive && isPlayerHuman(e));
    const activePregnancies = activeHumans.filter((e) => e.pregnant).length;
    const activeMarriages = activeHumans.filter(
      (e) =>
        (e.relationshipStatus === 'married' || e.relationshipStatus === 'expecting') &&
        e.partnerId != null &&
        e.id < e.partnerId,
    ).length;
 // A courtship is mutual by definition, so count a pair here only when both sides name
    // each other — a one-sided link left by a break must not be reported as an active courtship.
    const courtshipById = new Map(activeHumans.map((e) => [e.id, e]));
    const activeCourtships = activeHumans.filter(
      (e) =>
        e.courtshipPartnerId != null
        && e.id < e.courtshipPartnerId
        && courtshipById.get(e.courtshipPartnerId)?.courtshipPartnerId === e.id,
    ).length;
    const activeYouthLovePairs = activeHumans.filter(
      (e) => e.youthLovePartnerId != null && e.id < e.youthLovePartnerId,
    ).length;
    const activeAffairs = activeHumans.filter(
      (e) => e.affairPartnerId != null && e.id < e.affairPartnerId,
    ).length;

    flushRelationshipDiagnostics(state.tick, getAbsoluteCalendarDay(state.tick), activePregnancies, {
      activeMarriages,
      activeCourtships,
      activeYouthLovePairs,
      activeAffairs,
    });
  }
}
