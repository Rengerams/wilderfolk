import type { HuntingSpotPrey } from './huntingSpots';

export const BuildingType = {
  House: 'house',
  Farm: 'farm',
  Greenhouse: 'greenhouse',
  Barn: 'barn',
  Silo: 'silo',
  /** General materials storehouse; the persisted building id stays woodStorehouse for save compatibility. */
  WoodStorehouse: 'woodStorehouse',
  LumberMill: 'lumberMill',
  Quarry: 'quarry',
  Mine: 'mine',
  Mill: 'mill',
  Blacksmith: 'blacksmith',
  Workshop: 'workshop',
  Store: 'store',
  Market: 'market',
  School: 'school',
  Hospital: 'hospital',
  TownHall: 'townHall',
  /** Official residence of the elected village leader — unique, free, reserved housing. */
  LeaderHouse: 'leaderHouse',
  Church: 'church',
  Graveyard: 'graveyard',
  Square: 'square',
  Prison: 'prison',
  Well: 'well',
  Road: 'road',
  Mansion: 'mansion',
  Villa: 'villa',
  TamingPost: 'tamingPost',
  Wall: 'wall',
  WallGate: 'wallGate',
  Watchtower: 'watchtower',
  Barracks: 'barracks',
  /** Outdoor hunting post — staffed hunters harvest nearby wildlife. */
  HuntingSpot: 'huntingSpot',
  /** Riverside fishing post — staffed fishers harvest food from the water. */
  FishingSpot: 'fishingSpot',
  /** Fenced wild grove — restores ecosystem health, no workers. */
  WildlifePreserve: 'wildlifePreserve',
  /** Public house — free-time hangout: drink, chat, unwind. */
  Tavern: 'tavern',
  /** Guest lodging — visitors and stranded settlers sleep free; staffed by hoteliers. */
  Hotel: 'hotel',
  /** Cross rivers — place on river / bank tiles only. */
  Bridge: 'bridge',
  GroundReinforcement: 'groundReinforcement',
  // ── Decor (Phase 3.2 — beauty grid) ──
  /** Flower garden — neighborhood beauty + a spot settlers like to sit. */
  Garden: 'garden',
  /** Carved stone statue — the strongest beauty nudge in the village. */
  Statue: 'statue',
  /** Street lamp — constant beauty nudge (no day/night change). */
  Lamp: 'lamp',
  /** Light wooden fence — cheap strip that prettifies a boundary. */
  Fence: 'fence',
} as const;

export type BuildingType = (typeof BuildingType)[keyof typeof BuildingType];

/** Stable numeric identity per building type. Append-only: a new type takes the next free number, and a removed type's number is never reused. */
export const BUILDING_TYPE_CODES: Readonly<Record<BuildingType, number>> = {
  [BuildingType.House]: 1,
  [BuildingType.Farm]: 2,
  [BuildingType.Greenhouse]: 3,
  [BuildingType.Barn]: 4,
  [BuildingType.Silo]: 5,
  [BuildingType.WoodStorehouse]: 6,
  [BuildingType.LumberMill]: 7,
  [BuildingType.Quarry]: 8,
  [BuildingType.Mine]: 9,
  [BuildingType.Mill]: 10,
  [BuildingType.Blacksmith]: 11,
  [BuildingType.Workshop]: 12,
  [BuildingType.Store]: 13,
  [BuildingType.Market]: 14,
  [BuildingType.School]: 15,
  [BuildingType.Hospital]: 16,
  [BuildingType.TownHall]: 17,
  [BuildingType.LeaderHouse]: 18,
  [BuildingType.Church]: 19,
  [BuildingType.Graveyard]: 20,
  [BuildingType.Square]: 21,
  [BuildingType.Prison]: 22,
  [BuildingType.Well]: 23,
  [BuildingType.Road]: 24,
  [BuildingType.Mansion]: 25,
  [BuildingType.Villa]: 26,
  [BuildingType.TamingPost]: 27,
  [BuildingType.Wall]: 28,
  [BuildingType.WallGate]: 29,
  [BuildingType.Watchtower]: 30,
  [BuildingType.Barracks]: 31,
  [BuildingType.HuntingSpot]: 32,
  [BuildingType.FishingSpot]: 33,
  [BuildingType.WildlifePreserve]: 34,
  [BuildingType.Tavern]: 35,
  [BuildingType.Hotel]: 36,
  [BuildingType.Bridge]: 37,
  [BuildingType.GroundReinforcement]: 38,
  [BuildingType.Garden]: 39,
  [BuildingType.Statue]: 40,
  [BuildingType.Lamp]: 41,
  [BuildingType.Fence]: 42,
};

/** Player-controlled staffing policy for a completed workplace. */
export type StaffingMode = 'auto' | 'manual';

/**
 * What a Mine extracts, chosen per mine. Stone is the Quarry's job — a Mine
 * yields the ores only (see `mineOreForMode`).
 */
export const MINE_ORES = ['iron', 'gold'] as const;
export type MineMode = (typeof MINE_ORES)[number];

/**
 * The ore a Mine extracts right now. Gold only when the player chose it; iron
 * otherwise — which also covers a save written while the Mine still had a
 * `stone` mode (there was no gold mode to fall back from).
 */
export function mineOreForMode(mode: string | undefined): MineMode {
  return mode === 'gold' ? 'gold' : 'iron';
}

/** Legacy stored orientation; effective rendering uses the canonical 0|90 run axis. */
export type StoredBuildingRotation = 0 | 90 | 180 | 270;

export interface BuildingCost {
  wood: number;
  stone: number;
  gold: number;
  iron?: number;
}

export interface Building {
  id: number;
  type: BuildingType;
  /** Original tile type sampled before the building footprint was cleared. */
  siteTerrain?: string;
  x: number;
  y: number;
  width: number;
  height: number;
  occupants: number[];
  /** Optional for save compatibility; absent means the legacy default policy. */
  staffingMode?: StaffingMode;
  level: number;
  constructionProgress: number;
  completed: boolean;
  health: number;
  maxHealth: number;
  // Visual
  spriteScale: number;
  buildAnimTimer: number;
  /** Rival settlement structures — not player-owned */
  faction?: 'rival';
  groupId?: string;
  campLabel?: string;
  /** Workshop only — which goods this building crafts */
  workshopRecipeId?: string;
  /** Strip orientation — 0/90 straight; 0/90/180/270 for wall corners. */
  rotation?: StoredBuildingRotation;
  /** WallGate only — closed gates block walkers; absent means open in legacy saves. */
  gateClosed?: boolean;
  /** Hotel only — visitor entity ids currently lodging (max HOTEL_GUEST_CAPACITY). */
  hotelGuestIds?: number[];
  /** Hunting Spot only — which prey the staffed hunters target (see HUNTING_SPOT_PREY_OPTIONS). */
  huntingSpotPrey?: HuntingSpotPrey;
  /**
   * Hunting Spot only — the animal the spot is currently **committed** to, by entity id.
   *
   * A chase needs one animal to chase. Without a commitment the spot re-picked the nearest candidate
   * every tick, so a hunter standing among a herd swapped targets continuously and closed on none of
   * them (measured: parked at ~150 px while the pick cycled #357 → #431 → #452 across a single day).
   * Written by the spot's own pass (`dailyBuildingEconomy`), read by the hunter's movement
   * (`humanTick`) and by the shot, so all three chase the same animal. Cleared when the animal dies, is
   * tamed, or walks out of the spot's eyes.
   */
  huntingSpotTargetId?: number;
  /**
   * Hunting Spot only — the last tick the assigned hunter stood within killing distance of its target.
   *
   * The shot is resolved by the spot's production pass, which samples **one instant**; the hunter is
   * beside a wandering animal for many ticks and at its post for many others, and the two never lined up.
   * Measured: 162 "Too far to shoot" decisions across twelve colony days — every one of them at
   * 00:00–01:00 with the hunter back at its post (`huntTargetId=none`) — and no catch at all, even though
   * the hunter had closed to 10 px that same day. So the contact is recorded when it happens and the pass
   * accepts a *recent* one (`HUNTING_SPOT_STRIKE_GRACE_TICKS`).
   */
  huntingSpotInReachTick?: number;
  /** Prison only — clock hours of the current day that nobody stood on the post (see `prisonGuardDuty`). */
  uncoveredPrisonHours?: number[];
  /** Mine only — extracts stone (default) or iron. */
  mineMode?: MineMode;
}

/** A completed building the player owns — the shared boundary for venues and homes. */
export function isCompletedPlayerBuilding(building: Building): boolean {
  return building.completed && building.faction !== 'rival';
}

export interface BuildingConfig {
  width: number;
  height: number;
  cost: BuildingCost;
  /** Calendar days of on-site work normal workday for one builder to finish. */
  buildTime: number;
  /**
   * Slot cap for `building.occupants` — **overloaded by building role**:
   *
   * - **Housing** (House, Mansion, LeaderHouse): bed / resident capacity.
   * - **Staffed workplaces** (Farm, Church, Barracks, Hotel, …): max assigned **workers/staff**.
   * - **Prison**: guard + prisoner slots share this cap.
   * - **0**: no permanent staff and no residents (e.g. roads, walls, wells, barn, mill).
   */
  maxOccupants: number;
  emoji: string;
  label: string;
  description: string;
  /** Map sprite path; absent for procedural decor (`decor: true`), which has no art on disk. */
  sprite?: string;
  backgroundColor: string;
  padShape: 'round' | 'rect' | 'circle' | 'road';
  /** Extra multiplier so a sprite fills its intended map footprint. */
  spriteDisplayScale?: number;
  /** Visible-base anchor within the source sprite (0 = top, 1 = bottom). */
  spriteAnchorY?: number;
  unlockRequirement?: string;
  /** Decor only — neighborhood beauty contribution (see beautyGrid). */
  beauty?: number;
  /** Decor only — procedural draw + feeds the beauty grid; no sprite/staff. */
  decor?: boolean;
  /** One per village — placement is rejected while any building of this type exists. */
  unique?: boolean;
}

export const BUILDING_CONFIGS: Readonly<Record<BuildingType, BuildingConfig>> = {
  [BuildingType.House]: {
    width: 46,
    height: 40,
    // No gold: housing is survival, and a colony at 0 gold with homeless settlers must
    // still be able to build (this is the exact state that stalled a measured 30-day run
    // for ten days — see docs/plans/auto-play-missing-rules-plan.md).
    cost: { wood: 40, stone: 10, gold: 0 },
    buildTime: 2,
    maxOccupants: 6,
    emoji: '🏠',
    label: 'House',
    description: 'Family home (6 slots). Upgrade to fit up to 10.',
    sprite: '/sprites/house.png',
    backgroundColor: '#d97706',
    padShape: 'round',
  },
  [BuildingType.Farm]: {
    width: 53,
    height: 46,
    // No gold: feeding the colony must not depend on the one material a colony can be
    // completely out of (`dailyBuildingEconomy` pays farms in food, not gold).
    cost: { wood: 25, stone: 0, gold: 0 },
    buildTime: 3,
    maxOccupants: 2,
    emoji: '🌾',
    label: 'Farm',
    description: 'Produces food for your village.',
    sprite: '/sprites/farm.png',
    backgroundColor: '#16a34a',
    padShape: 'rect',
  },
  [BuildingType.Greenhouse]: {
    width: 50,
    height: 43,
    cost: { wood: 30, stone: 10, gold: 0 },
    buildTime: 4,
    maxOccupants: 2,
    emoji: '🏡',
    label: 'Greenhouse',
    description: 'Efficient food production all year.',
    sprite: '/sprites/greenhouse.png',
    backgroundColor: '#15803d',
    padShape: 'rect',
    unlockRequirement: 'agriculture_1',
  },
  [BuildingType.Barn]: {
    width: 56,
    height: 46,
    cost: { wood: 50, stone: 5, gold: 10 },
    buildTime: 4,
    maxOccupants: 0,
    emoji: '🚜',
    label: 'Barn',
    description: 'Boosts nearby Farms & Greenhouses +35% · extends wood storage +300 — no workers needed.',
    sprite: '/sprites/barn.png',
    backgroundColor: '#ca8a04',
    padShape: 'rect',
  },
  [BuildingType.Silo]: {
    width: 36,
    height: 50,
    cost: { wood: 30, stone: 20, gold: 10 },
    buildTime: 3,
    maxOccupants: 0,
    emoji: '🌽',
    label: 'Silo',
    description: 'Food storage: +2,000 at level 1, +2,500 at level 2, +3,000 at level 3. Reduces spoilage.',
    sprite: '/sprites/silo.png',
    backgroundColor: '#65a30d',
    padShape: 'rect',
  },
  [BuildingType.WoodStorehouse]: {
    width: 72,
    height: 48,
    cost: { wood: 40, stone: 20, gold: 15 },
    buildTime: 4,
    maxOccupants: 0,
    emoji: '🏚️',
    label: 'Storehouse',
    description: 'Materials storage for wood, stone, iron and gold: +800 each at level 1, +1,800 at level 2, +2,800 at level 3. No workers needed.',
    sprite: '/sprites/storehouse.png',
    backgroundColor: '#92400e',
    padShape: 'rect',
    // This art's painted base sits at 96.2 % of the PNG rather than the 100 % of the edge-to-edge
    // building sprites, so the default 0.92 anchor stood it ~4 % of sprite height proud of the
    // ground line. Anchor at `paintedBase − 0.08` to sink it by the same 8 % as the rest (the value
    // LeaderHouse already carries for the same reason).
    spriteAnchorY: 0.882,
  },
  [BuildingType.LumberMill]: {
    width: 56,
    height: 46,
    // No wood, and no gold: a colony at 0 wood must still be able to raise the building
    // that makes wood. Paid in stone, which the Quarry makes from wood alone.
    cost: { wood: 0, stone: 30, gold: 0 },
    buildTime: 4,
    maxOccupants: 3,
    emoji: '🪵',
    label: 'Lumber Mill',
    description: 'Produces wood.',
    sprite: '/sprites/lumbermill.png',
    backgroundColor: '#57534e',
    padShape: 'rect',
  },
  [BuildingType.Quarry]: {
    width: 53,
    height: 46,
    // No stone (it makes stone) and no gold: paid in wood, which the Lumber Mill makes
    // from stone alone — so the pair bootstraps from either material.
    cost: { wood: 30, stone: 0, gold: 0 },
    buildTime: 4,
    maxOccupants: 3,
    emoji: '🪨',
    label: 'Quarry',
    description: 'Produces stone.',
    sprite: '/sprites/quarry.png',
    backgroundColor: '#44403c',
    padShape: 'rect',
  },
  [BuildingType.Mine]: {
    width: 50,
    height: 46,
    // No gold: the Mine can dig the gold seam, so a colony at 0 gold must still be able
    // to build it. Paid in wood and stone.
    cost: { wood: 35, stone: 25, gold: 0 },
    buildTime: 6,
    maxOccupants: 4,
    emoji: '⛏️',
    label: 'Mine',
    description: 'Produces iron ore or gold — set the ore per mine. Stone comes from the Quarry.',
    sprite: '/sprites/mine.png',
    backgroundColor: '#292524',
    padShape: 'rect',
  },
  [BuildingType.Mill]: {
    width: 53,
    height: 46,
    cost: { wood: 45, stone: 25, gold: 30 },
    buildTime: 5,
    maxOccupants: 0, // Corrected: passive boost, requires no permanent workers
    emoji: '🌾',
    label: 'Mill',
    description: 'When complete, passively boosts food production (no permanent workers needed).',
    sprite: '/sprites/mill.png',
    backgroundColor: '#84cc16',
    padShape: 'rect',
    unlockRequirement: 'agriculture_2',
  },
  [BuildingType.Blacksmith]: {
    width: 53,
    height: 43,
    cost: { wood: 30, stone: 30, gold: 30 },
    buildTime: 5,
    maxOccupants: 2,
    emoji: '🔨',
    label: 'Blacksmith',
    description: 'Queue forge upgrades — iron gear, guard halberds, wall plates, pickaxes. Staffed smiths boost industry.',
    sprite: '/sprites/blacksmith.png',
    backgroundColor: '#c2410c',
    padShape: 'rect',
    unlockRequirement: 'forestry_1',
  },
  [BuildingType.Workshop]: {
    width: 50,
    height: 43,
    cost: { wood: 35, stone: 15, gold: 20 },
    buildTime: 4,
    maxOccupants: 2,
    emoji: '🔧',
    label: 'Workshop',
    description: 'Crafts frontier goods for gold — pick a recipe when built.',
    sprite: '/sprites/workshop.png',
    backgroundColor: '#ea580c',
    padShape: 'rect',
  },
  [BuildingType.Store]: {
    width: 46,
    height: 40,
    // "Generates gold." — so it must not cost gold, or a colony at 0 gold could never
    // build its way back. Paid in wood and stone.
    cost: { wood: 35, stone: 20, gold: 0 },
    buildTime: 3,
    maxOccupants: 1,
    emoji: '🏪',
    label: 'Store',
    description: 'Generates gold.',
    sprite: '/sprites/store.png',
    backgroundColor: '#f97316',
    padShape: 'rect',
  },
  [BuildingType.Market]: {
    width: 59,
    height: 50,
    cost: { wood: 50, stone: 20, gold: 40 },
    buildTime: 6,
    maxOccupants: 3,
    emoji: '🏛️',
    label: 'Market',
    description: 'Generates lots of gold.',
    sprite: '/sprites/market.png',
    backgroundColor: '#fb923c',
    padShape: 'rect',
    unlockRequirement: 'trade_1',
  },
  [BuildingType.School]: {
    width: 53,
    height: 46,
    cost: { wood: 50, stone: 30, gold: 25 },
    buildTime: 5,
    maxOccupants: 2,
    emoji: '🏫',
    label: 'School',
    description: 'Staff 1–2 teachers, 10 pupils each (20 per school) — children attend by day for faster growth & graduation perks.',
    sprite: '/sprites/school.png',
    backgroundColor: '#2563eb',
    padShape: 'round',
    unlockRequirement: 'education_1',
  },
  [BuildingType.Hospital]: {
    width: 53,
    height: 46,
    cost: { wood: 40, stone: 40, gold: 50 },
    buildTime: 6,
    maxOccupants: 5,
    emoji: '🏥',
    label: 'Hospital',
    description: 'Staff doctors — settlers visit when sick or pregnant. Staffed wards lower village energy drain.',
    sprite: '/sprites/hospital.png',
    backgroundColor: '#db2777',
    padShape: 'round',
    unlockRequirement: 'medicine_1',
  },
  [BuildingType.TownHall]: {
    width: 63,
    height: 53,
    cost: { wood: 100, stone: 80, gold: 100 },
    buildTime: 8,
    maxOccupants: 3,
    emoji: '🏰',
    label: 'Town Hall',
    description: 'Civic hub — taxes, trade, immigration, elections & festivals. Staffed officials hear petitions.',
    sprite: '/sprites/townhall.png',
    backgroundColor: '#1d4ed8',
    padShape: 'round',
    unlockRequirement: 'architecture_2',
    unique: true,
  },
  [BuildingType.Church]: {
    width: 50,
    height: 56,
    cost: { wood: 45, stone: 35, gold: 20 },
    buildTime: 4,
    maxOccupants: 4,
    emoji: '⛪',
    label: 'Church',
    description: 'Staffed church boosts courtship and morals. Priests perform Moon Howler curing rites.',
    sprite: '/sprites/church.png',
    backgroundColor: '#4f46e5',
    padShape: 'round',
    unique: true,
  },
  [BuildingType.Square]: {
    width: 80,
    height: 70,
    cost: { wood: 20, stone: 50, gold: 15 },
    buildTime: 4,
    maxOccupants: 0,
    emoji: '🏛️',
    label: 'Village Square',
    description: 'The village gathering place for festivals and election ceremonies. Only one per village.',
    sprite: '/sprites/square.png',
    backgroundColor: '#b8a48b',
    padShape: 'rect',
    unique: true,
  },
  [BuildingType.Graveyard]: {
    width: 56,
    height: 48,
    cost: { wood: 15, stone: 35, gold: 5 },
    buildTime: 3,
    maxOccupants: 1,
    emoji: '🪦',
    label: 'Graveyard',
    description: 'Memorial for up to 50 dead villagers and enemies. Families may visit to mourn.',
    sprite: '/sprites/graveyard.png',
    backgroundColor: '#64748b',
    padShape: 'rect',
  },
  [BuildingType.Well]: {
    width: 30,
    height: 30,
    cost: { wood: 15, stone: 10, gold: 5 },
    buildTime: 1,
    maxOccupants: 0,
    emoji: '🌊',
    label: 'Well',
    description: 'Reduces human energy consumption in the neighborhood.',
    sprite: '/sprites/well.png',
    backgroundColor: '#0891b2',
    padShape: 'circle',
  },
  [BuildingType.Villa]: {
    width: 68,
    height: 58,
    cost: { wood: 160, stone: 110, gold: 130 },
    buildTime: 8,
    maxOccupants: 14,
    emoji: '🏡',
    label: 'Villa',
    description: 'Spacious residence providing shelter for 14 villagers. Requires Better Housing research.',
    sprite: '/sprites/villa.png',
    backgroundColor: '#a16207',
    padShape: 'round',
    unlockRequirement: 'architecture_3',
  },
  [BuildingType.Mansion]: {
    width: 59,
    height: 50,
    cost: { wood: 120, stone: 80, gold: 100 },
    buildTime: 7,
    maxOccupants: 8,
    emoji: '🏯',
    label: 'Mansion',
    description: 'Large family home (base 8 beds; upgrades add capacity). Attracts more immigrants.',
    sprite: '/sprites/mansion.png',
    backgroundColor: '#b45309',
    padShape: 'round',
    unlockRequirement: 'architecture_1',
  },
  [BuildingType.LeaderHouse]: {
    width: 63,
    height: 53,
    cost: { wood: 0, stone: 0, gold: 0 },
    buildTime: 2,
    maxOccupants: 20,
    emoji: '👑',
    label: "Leader's House",
    description: 'Official residence of the elected village leader.',
    sprite: '/sprites/house_leader.png',
    backgroundColor: '#7c2d12',
    padShape: 'round',
    spriteDisplayScale: 1.32,
    spriteAnchorY: 0.836,
    unique: true,
  },
  [BuildingType.Prison]: {
    width: 50,
    height: 46,
    cost: { wood: 60, stone: 40, gold: 30 },
    buildTime: 5,
    // Four guard posts — three on watch, one resting — beside four cells (see `prisonShifts`).
    maxOccupants: 8,
    emoji: '⛓️',
    label: 'Prison',
    description: 'Holds scandalous settlers for a short sentence. Three guards cover a full day.',
    sprite: '/sprites/prison.png',
    backgroundColor: '#475569',
    padShape: 'rect',
    unlockRequirement: 'architecture_1',
  },
  [BuildingType.TamingPost]: {
    width: 43,
    height: 43,
    cost: { wood: 35, stone: 15, gold: 20 },
    buildTime: 3,
    maxOccupants: 2,
    emoji: '🦴',
    label: 'Taming Post',
    description: 'Lets settlers tame nearby wildlife. Builders only during construction.',
    sprite: '/sprites/taming_post.png',
    backgroundColor: '#7c3aed',
    padShape: 'circle',
  },
  [BuildingType.Road]: {
    width: 66,
    height: 26,
    cost: { wood: 5, stone: 5, gold: 0 },
    buildTime: 1,
    maxOccupants: 0,
    emoji: '🛤️',
    label: 'Road',
    description: 'Speeds up travel, fragments wildlife habitat.',
    sprite: '/sprites/road.png',
    backgroundColor: '#4b5563',
    padShape: 'road',
  },
  [BuildingType.Wall]: {
    width: 60,
    height: 40,
    cost: { wood: 8, stone: 14, gold: 0 },
    buildTime: 1,
    maxOccupants: 0,
    emoji: '🧱',
    label: 'Wall',
    description: 'Stone palisade segment — adds barricade strength; wall plates raise the cap.',
    sprite: '/sprites/wall_isometric.png',
    backgroundColor: '#64748b',
    padShape: 'rect',
    unlockRequirement: 'defense_1',
  },
  [BuildingType.WallGate]: {
    width: 60,
    height: 48,
    cost: { wood: 18, stone: 28, gold: 8 },
    buildTime: 2,
    maxOccupants: 0,
    emoji: '🚪',
    label: 'Wall Gate',
    description: 'Gated entrance — strong wall segment with drawbridge flair.',
    sprite: '/sprites/gate_isometric.png',
    backgroundColor: '#64748b',
    padShape: 'rect',
    unlockRequirement: 'defense_1',
  },
  [BuildingType.Watchtower]: {
    width: 44,
    height: 52,
    cost: { wood: 28, stone: 42, gold: 12 },
    buildTime: 4,
    maxOccupants: 0,
    emoji: '🗼',
    label: 'Watchtower',
    description: 'Overwatch post — adds barricade strength and early raid warning.',
    sprite: '/sprites/watchtower_isometric.png',
    backgroundColor: '#475569',
    padShape: 'rect',
    unlockRequirement: 'defense_1',
  },
  [BuildingType.Barracks]: {
    width: 56,
    height: 50,
    cost: { wood: 85, stone: 65, gold: 35 },
    buildTime: 6,
    maxOccupants: 4,
    emoji: '⚔️',
    label: 'Barracks',
    // The per-guard strength is `MILITIA_BALANCE.guardBonusPerGuard` (defenseStructures, the owner).
    // Importing it here would close a cycle — `defenseStructures` reads `gameTypes`, which reads this
    // file — so the catalogue copy carries no number, the same remedy as the wall/watchtower
    // descriptions above (`tests/copyAndDayIndex.owners.test.ts`, L2).
    description: 'Staff Soldiers to patrol the village — each guard adds militia strength.',
    sprite: '/sprites/barracks.png',
    backgroundColor: '#57534e',
    padShape: 'rect',
    unlockRequirement: 'defense_2',
  },
  [BuildingType.HuntingSpot]: {
    width: 44,
    height: 40,
    cost: { wood: 30, stone: 10, gold: 0 },
    buildTime: 3,
    maxOccupants: 2,
    emoji: '🏹',
    label: 'Hunting Spot',
    description: 'Staff hunters to harvest nearby wildlife for food. Wolves may fight back.',
    sprite: '/sprites/huntingspot.png',
    backgroundColor: '#854d0e',
    padShape: 'circle',
    // Painted base at 92.7 % of the PNG — see the Wood Storehouse note above.
    spriteAnchorY: 0.847,
  },
  [BuildingType.FishingSpot]: {
    width: 52,
    height: 40,
    cost: { wood: 20, stone: 15, gold: 0 },
    buildTime: 3,
    maxOccupants: 2,
    emoji: '🎣',
    label: 'Fishing Spot',
    description: 'Riverside post — staffed fishers harvest food from the water.',
    sprite: '/sprites/fishingspot.png',
    backgroundColor: '#0369a1',
    padShape: 'rect',
  },
  [BuildingType.WildlifePreserve]: {
    width: 64,
    height: 64,
    cost: { wood: 50, stone: 40, gold: 30 },
    buildTime: 5,
    maxOccupants: 0,
    emoji: '🌳',
    label: 'Wildlife Preserve',
    // As with the Barracks above: the amount is `PRESERVE_HEALTH_BONUS` (dailyEcology), reachable
    // only through `gameTypes`, so the catalogue states the rule without a number.
    description: 'Fenced wild grove — restores ecosystem health and helps wildlife recover. No workers.',
    sprite: '/sprites/wildlife_preserve.png',
    backgroundColor: '#166534',
    padShape: 'rect',
  },
  [BuildingType.Tavern]: {
    width: 56,
    height: 48,
    cost: { wood: 55, stone: 25, gold: 30 },
    buildTime: 4,
    maxOccupants: 2,
    emoji: '🍺',
    label: 'Tavern',
    description: 'Village pub — guests visit after work. Staff an Innkeeper who works evenings & festivals.',
    sprite: '/sprites/tavern.png',
    backgroundColor: '#b45309',
    padShape: 'round',
  },
  [BuildingType.Hotel]: {
    width: 60,
    height: 52,
    cost: { wood: 70, stone: 40, gold: 55 },
    buildTime: 5,
    maxOccupants: 2,
    emoji: '🏨',
    label: 'Hotel',
    // No guest count here: `HOTEL_GUEST_CAPACITY` is the owner, and this catalogue is deliberately
    // import-free (one type-only import), so a restated number would drift exactly as the Barracks
    // "+14" and the preserve "+4" did.
    description: 'Visitor lodging — staff Hoteliers (day shift). Guests sleep overnight for free.',
    sprite: '/sprites/hotel.png',
    backgroundColor: '#0e7490',
    padShape: 'round',
    unlockRequirement: 'trade_1',
  },
  [BuildingType.Bridge]: {
    width: 64,
    height: 22,
    cost: { wood: 45, stone: 35, gold: 15 },
    buildTime: 3,
    maxOccupants: 0,
    emoji: '🌉',
    label: 'Bridge',
    description: 'Spans a river — place on river/bank. 1.5× walk speed like roads.',
    sprite: '/sprites/bridge.png',
    backgroundColor: '#6b7280',
    padShape: 'road',
    unlockRequirement: 'architecture_1',
    spriteDisplayScale: 1.05,
  },
  [BuildingType.GroundReinforcement]: {
    width: 30,
    height: 30,
    cost: { wood: 0, stone: 30, gold: 8 },
    buildTime: 1,
    maxOccupants: 0,
    emoji: '🪨',
    label: 'Ground Reinforcement',
    decor: true,
    description: 'Prepare a 3×3-tile patch of unstable ground for construction. Uses stone and gold; no permanent structure. Cannot fill deep water or active rivers.',
    backgroundColor: '#78716c',
    padShape: 'rect',
  },
  [BuildingType.Garden]: {
    width: 42,
    height: 38,
    cost: { wood: 12, stone: 4, gold: 2 },
    buildTime: 1,
    maxOccupants: 0,
    emoji: '🌷',
    label: 'Garden',
    description: 'A flower bed — neighborhood beauty where settlers drift in free time.',
    backgroundColor: '#84cc16',
    padShape: 'rect',
    beauty: 3,
    decor: true,
  },
  [BuildingType.Statue]: {
    width: 30,
    height: 32,
    cost: { wood: 0, stone: 25, gold: 15 },
    buildTime: 2,
    maxOccupants: 0,
    emoji: '🗿',
    label: 'Statue',
    description: 'Carved stone — the strongest beauty nudge in the village.',
    backgroundColor: '#a8a29e',
    padShape: 'circle',
    beauty: 5,
    decor: true,
  },
  [BuildingType.Lamp]: {
    width: 22,
    height: 26,
    cost: { wood: 10, stone: 6, gold: 3 },
    buildTime: 1,
    maxOccupants: 0,
    emoji: '🏮',
    label: 'Lamp',
    description: 'Street lamp — a constant warm landmark on the square.',
    backgroundColor: '#eab308',
    padShape: 'circle',
    beauty: 2,
    decor: true,
  },
  [BuildingType.Fence]: {
    width: 44,
    height: 12,
    cost: { wood: 6, stone: 2, gold: 0 },
    buildTime: 1,
    maxOccupants: 0,
    emoji: '🚧',
    label: 'Fence',
    description: 'A light wooden fence — cheap beauty that prettifies a boundary.',
    backgroundColor: '#a16207',
    padShape: 'road',
    beauty: 1,
    decor: true,
  },
};
