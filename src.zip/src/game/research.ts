import type { ResearchNode, WorldState } from './gameTypes';
import { BuildingType, BUILDING_CONFIGS, ResearchType } from './gameTypes';
import { logEvent } from './eventLog';
import { addNotification, impulseScreenShake } from './simEffects';
import { addReputation, getMultiplier } from './simHelpers';
import { getEducationResearchMultiplier } from './education';
import { isPlayerHuman } from './playerHuman';
import { PER_TICK_RATE_SCALE } from './dayCycle';
import { WILDLIFE_LAYER_INTERVAL } from './simFocus';

const RESEARCH_TAB_LABELS: Record<ResearchType, string> = {
  [ResearchType.Agriculture]: 'Agriculture',
  [ResearchType.Forestry]: 'Forestry',
  [ResearchType.Mining]: 'Mining',
  [ResearchType.Architecture]: 'Architecture',
  [ResearchType.Medicine]: 'Medicine',
  [ResearchType.Trade]: 'Trade',
  [ResearchType.Education]: 'Education',
  [ResearchType.Defense]: 'Defense',
};

function researchTabLabel(type: ResearchType | undefined): string {
  return type ? RESEARCH_TAB_LABELS[type] : 'Tech';
}

function unlockTechId(state: WorldState, nodeId: string): void {
  if (!state.unlockedTechs.includes(nodeId)) {
    state.unlockedTechs.push(nodeId);
  }
}

function notifyForgeUnlock(state: WorldState, node: ResearchNode): void {
  const hasSmith = state.buildings.some((b) => b.completed && b.type === BuildingType.Blacksmith);
  addNotification(
    state,
    hasSmith ? 'Iron gear researched — queue forge' : 'Iron gear researched — build Blacksmith',
    hasSmith
      ? `Open your Blacksmith on the map → Village forge → queue ${node.name} (~6 days staffed).`
      : 'Build & complete a Blacksmith (Industry), then queue the forge order.',
    'warning',
  );
}

function notifyResearchCompletion(state: WorldState, node: ResearchNode): void {
  if (node.completionNotify) {
    addNotification(
      state,
      node.completionNotify.title,
      node.completionNotify.message,
      node.completionNotify.level ?? 'success',
    );
  }
  if (node.forgeUnlockNotify) {
    notifyForgeUnlock(state, node);
  }
}

/** Keep researched techs, unlocked flags, and build unlocks in sync (fixes older saves). */
export function syncResearchUnlocks(state: WorldState): void {
  state.unlockedTechs = [...new Set(state.unlockedTechs)];
  for (const node of state.researchNodes) {
    if (node.researched) {
      node.unlocked = true;
      unlockTechId(state, node.id);
    }
  }
  for (const node of state.researchNodes) {
    if (!node.unlocked && node.prerequisites.every((p) => state.unlockedTechs.includes(p))) {
      node.unlocked = true;
    }
  }
}

/** Mutates `state` in place (same pattern as `updateResearch`) so callers need not reassign. */
export function notifyBuildingLocked(state: WorldState, type: BuildingType): WorldState {
  syncResearchUnlocks(state);
  const config = BUILDING_CONFIGS[type];
  if (!config.unlockRequirement || state.unlockedTechs.includes(config.unlockRequirement)) return state;

  const lockTech = state.researchNodes.find((n) => n.id === config.unlockRequirement);
  const missingPrereq = lockTech?.prerequisites.find((p) => !state.unlockedTechs.includes(p));
  const prereqTech = missingPrereq
    ? state.researchNodes.find((n) => n.id === missingPrereq)
    : undefined;
  const tab = researchTabLabel(lockTech?.type);
  const chain = prereqTech
    ? `Research ${prereqTech.name} first, then ${lockTech?.name ?? 'the required tech'} (Research tab → ${tab}).`
    : `Research ${lockTech?.name ?? config.unlockRequirement} in the Research tab (→ ${tab}).`;

  addNotification(state, `${config.label} locked`, chain, 'warning');
  return state;
}

/**
 * The research owner's refusal wording, or `null` when `startResearch` would accept the node.
 * Same shape as the forge owner's gate, so a disabled choice prints a reason.
 */
export function getResearchBlockReason(state: WorldState, researchId: string): string | null {
  const node = state.researchNodes.find(n => n.id === researchId);
  if (!node) return 'No such research';

  const missingPrereqs = node.prerequisites.filter(p => !state.unlockedTechs.includes(p));
  if (missingPrereqs.length > 0) {
    const names = missingPrereqs.map(p => state.researchNodes.find(n => n.id === p)?.name ?? p);
    return `Needs ${names.join(' + ')} first`;
  }
  if (!node.unlocked) return 'Locked — an earlier tier comes first';
  if (node.researched) return 'Already researched';
  if (state.activeResearch) {
    if (state.activeResearch === researchId) return 'In progress — wait for it to finish';
    const active = state.researchNodes.find(n => n.id === state.activeResearch);
    return `${active?.name ?? 'Another subject'} is already being researched`;
  }

  const { wood, stone, gold } = node.cost;
  const shortfalls: string[] = [];
  if (wood > state.resources.wood) shortfalls.push(`${wood - state.resources.wood} more wood`);
  if (stone > state.resources.stone) shortfalls.push(`${stone - state.resources.stone} more stone`);
  if (gold > state.resources.gold) shortfalls.push(`${gold - state.resources.gold} more gold`);
  if (shortfalls.length > 0) return `Need ${shortfalls.join(', ')}`;

  return null;
}

/**
 * Whether `startResearch` would accept this node — one shared gate, so a caller that must not
 * issue a doomed command reads the rule the command itself enforces.
 */
export function canStartResearch(state: WorldState, researchId: string): boolean {
  return getResearchBlockReason(state, researchId) === null;
}

/** Mutates `state` in place (same pattern as `updateResearch`) so callers need not reassign. */
export function startResearch(state: WorldState, researchId: string): WorldState {
  const node = state.researchNodes.find(n => n.id === researchId);
  if (!node || !canStartResearch(state, researchId)) return state;

  state.resources.wood -= node.cost.wood;
  state.resources.stone -= node.cost.stone;
  state.resources.gold -= node.cost.gold;
  state.activeResearch = researchId;
  state.researchProgress = 0;
  addNotification(state, 'Research Started', `Started researching: ${node.name}`, 'info');
  return state;
}

/** The completion branch: mark the active subject researched, unlock it, reset progress, announce. */
function completeActiveResearch(state: WorldState): void {
  const node = state.researchNodes.find(n => n.id === state.activeResearch);
  if (!node) return;

  node.researched = true;
  node.unlocked = true;
  unlockTechId(state, node.id);
  state.activeResearch = null;
  state.researchProgress = 0;

  syncResearchUnlocks(state);

  addNotification(state, 'Research Complete!', `${node.name} has been researched!`, 'success');
  addReputation(state, 3);
  notifyResearchCompletion(state, node);
  logEvent(state, 'research', `${node.name} researched`);
  impulseScreenShake(state, 3);
}

/**
 * Adds progress to the active subject and resolves completion — the clamp's and the completion
 * branch's one home, so a gift that grants progress cannot skip the finish.
 */
export function grantResearchProgress(state: WorldState, amount: number): void {
  if (!state.activeResearch) return;
  state.researchProgress = Math.min(100, state.researchProgress + amount);
  if (state.researchProgress >= 100) completeActiveResearch(state);
}

/** Advances active research in place — called from `gameTick`, which mutates `WorldState` directly. */
export function updateResearch(state: WorldState) {
  if (!state.activeResearch) return;
  const node = state.researchNodes.find(n => n.id === state.activeResearch);
  if (!node) { state.activeResearch = null; return; }

  const educatedMult = getEducationResearchMultiplier(
    state.entities.filter((e) => e.alive && isPlayerHuman(e)),
  );
  const speedMult = getMultiplier(state, 'research_speed') * educatedMult;
  // Systems layer pulses every WILDLIFE_LAYER_INTERVAL ticks (LAYER_SYSTEMS_INTERVAL derives from it),
  // so the per-tick rate is scaled by that step — the same step `tickWildlife` applies to its rates.
  grantResearchProgress(state, speedMult * PER_TICK_RATE_SCALE * WILDLIFE_LAYER_INTERVAL);
}