
/**
 * Painted terrain atlas — "grass biome" 16×16 tileset (2.5D Painted Relief).
 *
 * Source art: TilesetGrass/overworld_tileset_grass.ase (Aseprite) +
 * grass_biome.tsx (Tiled). Runtime copy: /sprites/tileset_grass.png.
 * The tileset encodes Tiled corner terrains (TL,TR,BL,BR): 0=grass, 1=water,
 * 2=forest, 3=swampgrass, 4=swamp — we consume the grass↔water corner set
 * (16 combos) and complete the 6 missing pieces with mirror flips of the
 * authored tiles (the art is symmetric pixel work, flips are invisible).
 *
 * Also carries the elevation→raise curve used by the relief bake and by the
 * renderer so entities/buildings/props ride the terrain.
 */
import { TerrainType, PATH_CELL, type TerrainTile, type WorldMap } from './gameTypes';
import { DEFAULT_SEA_LEVEL, TERRAIN_CELL, sampleElev, tileAt, worldToTile } from './terrain/terrainGrid';
import { getSprite } from './spriteLoader';

export const TERRAIN_ATLAS_PATH = '/sprites/tileset_grass.png';
/** Transparent 4×4 sand-bank/water boundary masks stamped over a sand base tile. */
export const SAND_WATER_OVERLAY_PATH = '/sprites/terrain/sand_water_overlay.png';
/** Atlas tile edge (px) in the source PNG. */
export const ATLAS_TILE_SIZE = 16;
const ATLAS_COLUMNS = 12;
const SAND_WATER_OVERLAY_COLUMNS = 4;

/**
 * Bump only when the overlay sheet's mask ordering or material meaning changes.
 * It is a render-cache contract, not simulation or save state.
 */
export const TERRAIN_MATERIAL_ATLAS_REVISION = 1;

/** Canonical terrain colours — the single owner of the ground's base palette. Numbers (`0xRRGGBB`),
 *  not CSS (`terrainPaletteHex` for those); `PRESET_TERRAIN_COLORS` shifts the bake, not the minimap. */
export const TERRAIN_PALETTE: Record<TerrainType, number> = {
  [TerrainType.DeepWater]: 0x1c3a6e,
  [TerrainType.ShallowWater]: 0x2a588c,
  [TerrainType.River]: 0x3264a0,
  [TerrainType.RiverBank]: 0x52733e,
  [TerrainType.Beach]: 0xc2b280,
  [TerrainType.Desert]: 0xd6bd74,
  [TerrainType.Grassland]: 0x5e7a3a,
  [TerrainType.Forest]: 0x3a5c2a,
  [TerrainType.DarkForest]: 0x223a1c,
  [TerrainType.Hills]: 0x76663e,
  [TerrainType.Mountains]: 0x524e48,
  [TerrainType.Rocky]: 0x625c52,
  [TerrainType.Snow]: 0xd2dae1,
};

/** {@link TERRAIN_PALETTE} as a CSS `#rrggbb` string, for consumers that draw with fillStyle. */
export function terrainPaletteHex(type: TerrainType): string {
  return `#${TERRAIN_PALETTE[type].toString(16).padStart(6, '0')}`;
}

/** Atlas terrain families we can paint. */
export type AtlasFamily = 0 | 1; // 0 = grass, 1 = water
const GRASS: AtlasFamily = 0;
const WATER: AtlasFamily = 1;

/**
 * Map a game terrain type to an atlas family, or null when the atlas has no
 * art. Forest/DarkForest count as grass — their cells render painted grass
 * (the forest look comes from the dark tint + tree entities on top), so
 * grass↔forest and forest↔water boundaries stay painted too.
 */
export function atlasFamily(type: TerrainType): AtlasFamily | null {
  switch (type) {
    case TerrainType.Grassland:
    case TerrainType.Forest:
    case TerrainType.DarkForest:
    case TerrainType.RiverBank:
    // Desert has no authored atlas art either, and it is dry *land*: counting it as grass keeps an
    // arid cell's neighbours paintable. Returning null here would have made `pickAtlasTile` refuse
    // every tile touching a desert — the whole shoreline of an Arabian map would stop being painted.
    case TerrainType.Desert:
      return GRASS;
    case TerrainType.ShallowWater:
    case TerrainType.River:
    case TerrainType.DeepWater:
      return WATER;
    default:
      return null;
  }
}

export interface AtlasPick {
  /** Atlas tile id (0-based, row-major 12-column grid). */
  id: number;
  flipH: boolean;
  flipV: boolean;
}

/** One transparent overlay tile from the row-major 4×4 sand-water mask sheet. */
export interface SandWaterOverlayPick {
  /** Corner-mask id: 8=TL, 4=TR, 2=BL, 1=BR. */
  id: number;
}

interface AtlasTileRef {
  id: number;
  flipH?: boolean;
  flipV?: boolean;
}

/**
 * Corner combos → authored tile. Bits: 8=TL, 4=TR, 2=BL, 1=BR (1 = water).
 * Derived from grass_biome.tsx terrain tags. The two diagonal checkerboards
 * (0110, 1001) have no authored tile — substitute the nearest straight edge.
 */
const ATLAS_TILES: Partial<Record<number, AtlasTileRef>> = {
  [0b0001]: { id: 72, flipV: true }, // single water corner, BR
  [0b0010]: { id: 74, flipV: true }, // single water corner, BL
  [0b0011]: { id: 73, flipV: true }, // water along the bottom
  [0b0100]: { id: 72 },              // single water corner, TR
  [0b0101]: { id: 60 },              // vertical edge — grass left, water right
  [0b0110]: { id: 60 },              // diagonal — nearest straight edge
  [0b0111]: { id: 97 },              // water everywhere but TL
  [0b1000]: { id: 74 },              // single water corner, TL
  [0b1001]: { id: 62 },              // diagonal — nearest straight edge
  [0b1010]: { id: 62 },              // vertical edge — water left, grass right
  [0b1011]: { id: 96 },              // water everywhere but TR
  [0b1100]: { id: 73 },              // water along the top
  [0b1101]: { id: 85 },              // water everywhere but BL
  [0b1110]: { id: 84 },              // water everywhere but BR
  [0b1111]: { id: 61 },              // all water
};

/** Grass base variants (all-grass corners, tsx ids) — picked by hash. */
const GRASS_BASE_IDS = [0, 1, 2, 3, 4, 13, 14, 25, 26, 37, 38];

function hash01(x: number, y: number, seed: number): number {
  const n = Math.sin(x * 12.9898 + y * 78.233 + seed * 43758.5453) * 43758.5453;
  return n - Math.floor(n);
}

function isOpaqueFamily(f: AtlasFamily | null): f is AtlasFamily {
  return f === GRASS || f === WATER;
}

/**
 * Corner family at (dx,dy) ∈ {−1,0}² from the tile centre — the union rule:
 * a corner is water when ANY of the four tiles touching that point is water.
 * Out-of-map neighbours count as grass (island rims read as coastline).
 * Returns null when a touching tile is out-of-family (e.g. mountains).
 */
function cornerFamily(map: WorldMap, tx: number, ty: number, dx: number, dy: number): AtlasFamily | null {
  let water = false;
  for (let cy = 0; cy <= 1; cy++) {
    for (let cx = 0; cx <= 1; cx++) {
      const n = tileAt(map, tx + dx + cx, ty + dy + cy);
      if (!n) continue; // out-of-map → grass
      const f = atlasFamily(n.type);
      if (f === null) return null;
      if (f === WATER) water = true;
    }
  }
  return water ? WATER : GRASS;
}

/**
 * Pick the painted tile for a cell, or null when the atlas can't paint it.
 *
 * `selfTile` lets a caller that already holds the projected tile skip the
 * per-tile field sampling — the terrain bake reads each tile once and then asks
 * the atlas four neighbour questions about it.
 */
export function pickAtlasTile(map: WorldMap, tx: number, ty: number, selfTile?: TerrainTile): AtlasPick | null {
  const self = selfTile ?? tileAt(map, tx, ty);
  if (!self) return null;
  if (!isOpaqueFamily(atlasFamily(self.type))) return null;

  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dy === 0) continue;
      const n = tileAt(map, tx + dx, ty + dy);
      if (n && !isOpaqueFamily(atlasFamily(n.type))) return null;
    }
  }

  const tl = cornerFamily(map, tx, ty, -1, -1);
  const tr = cornerFamily(map, tx, ty, 0, -1);
  const bl = cornerFamily(map, tx, ty, -1, 0);
  const br = cornerFamily(map, tx, ty, 0, 0);
  if (tl === null || tr === null || bl === null || br === null) return null;

  const bits = (tl === WATER ? 8 : 0) | (tr === WATER ? 4 : 0) | (bl === WATER ? 2 : 0) | (br === WATER ? 1 : 0);
  if (bits === 0) {
    const seed = typeof map.seed === 'number' ? map.seed : 1;
    const v = Math.floor(hash01(tx * 31 + ty * 17, tx * 7 + ty * 41, seed) * GRASS_BASE_IDS.length);
    return { id: GRASS_BASE_IDS[v % GRASS_BASE_IDS.length], flipH: false, flipV: false };
  }
  const ref = ATLAS_TILES[bits];
  if (!ref) return null;
  return { id: ref.id, flipH: ref.flipH ?? false, flipV: ref.flipV ?? false };
}

/**
 * Pick exactly one sand-water overlay for a beach or river-bank base cell.
 */
export function pickSandWaterOverlay(map: WorldMap, tx: number, ty: number, selfTile?: TerrainTile): SandWaterOverlayPick | null {
  const self = selfTile ?? tileAt(map, tx, ty);
  if (!self || (self.type !== TerrainType.Beach && self.type !== TerrainType.RiverBank)) {
    return null;
  }

  const hasWaterAtCorner = (dx: number, dy: number): boolean => {
    for (let cy = 0; cy <= 1; cy++) {
      for (let cx = 0; cx <= 1; cx++) {
        const neighbour = tileAt(map, tx + dx + cx, ty + dy + cy);
        if (neighbour && atlasFamily(neighbour.type) === WATER) return true;
      }
    }
    return false;
  };

  const id = (hasWaterAtCorner(-1, -1) ? 8 : 0)
    | (hasWaterAtCorner(0, -1) ? 4 : 0)
    | (hasWaterAtCorner(-1, 0) ? 2 : 0)
    | (hasWaterAtCorner(0, 0) ? 1 : 0);
  return id === 0 ? null : { id };
}

/** True once the painted grass/water atlas PNG is in the sprite cache. */
export function terrainAtlasReady(): boolean {
  return getSprite(TERRAIN_ATLAS_PATH) != null;
}

/** True once the optional transparent sand-water overlay sheet is ready to bake. */
export function sandWaterOverlayReady(): boolean {
  return getSprite(SAND_WATER_OVERLAY_PATH) != null;
}

/**
 * Elevation → raise fraction of a tile.
 */
export function reliefY(type: TerrainType, elevation: number): number {
  switch (type) {
    case TerrainType.DeepWater:
    case TerrainType.ShallowWater:
    case TerrainType.River:
      return 0;
    default:
      break;
  }
  const e = Math.max(0, Math.min(100, elevation)) / 100;
  if (e <= 0.5) return 0;
  return Math.min(0.35, (e - 0.5) * 0.7);
}

/** Elevation at a world position (10px tile grid), 0–100. */
export function elevationAt(map: WorldMap | null, x: number, y: number): number {
  if (!map) return 0;
  const { tx, ty } = worldToTile(x, y);
  return tileAt(map, tx, ty)?.elevation ?? 0;
}

/**
 * Fixed 32-world-pixel height-mesh lattice. The existing 16px altitude field supplies its vertices,
 * and the same two triangles interpolate the height of **every** object/selection point. This keeps
 * feet on the textured terrain, with no second, drifting definition of "ground level".
 *
 * A 28px maximum rise across a 32px mesh edge also makes the y projection monotone: the
 * interactive screen-to-world inverse can converge instead of facing folded-over mountain faces.
 * These values are rendering-only, not world generation settings or simulation physics.
 */
export const TERRAIN_HEIGHT_MESH_STEP = 32;
export const TERRAIN_HEIGHT_MESH_MAX_RISE = 28;

export function supportsTerrainHeightMesh(map: WorldMap | null): boolean {
  return !!map && (map.generationVersion ?? 0) >= 3
    && !!map.elevation && !!map.cols && !!map.rows;
}

function meshVertexRise(map: WorldMap, x: number, y: number): number {
  const elevation = map.elevation!;
  const e = sampleElev(elevation, map.cols!, map.rows!, x / TERRAIN_CELL, y / TERRAIN_CELL);
  const sea = map.seaLevel ?? DEFAULT_SEA_LEVEL;
  const hn = Math.max(0, (e - sea) / Math.max(0.01, 1 - sea));
  // Water, beaches and low floodplains stay near zero; hilltops take the full rise.
  const uplift = Math.max(0, Math.min(1, (hn - 0.12) / 0.74));
  return uplift * TERRAIN_HEIGHT_MESH_MAX_RISE;
}

/** Shared triangulated mesh height — continuous across chunk edges and independent of zoom. */
export function terrainRiseAt(map: WorldMap | null, x: number, y: number): number {
  if (!map) return 0;
  if (supportsTerrainHeightMesh(map)) {
    const s = TERRAIN_HEIGHT_MESH_STEP;
    const x0 = Math.floor(x / s) * s, y0 = Math.floor(y / s) * s;
    const fx = (x - x0) / s, fy = (y - y0) / s;
    const z00 = meshVertexRise(map, x0, y0);
    const z10 = meshVertexRise(map, x0 + s, y0);
    const z01 = meshVertexRise(map, x0, y0 + s);
    if (fx + fy <= 1) {
      return z00 * (1 - fx - fy) + z10 * fx + z01 * fy;
    }
    const z11 = meshVertexRise(map, x0 + s, y0 + s);
    return z11 * (fx + fy - 1) + z10 * (1 - fy) + z01 * (1 - fx);
  }
  // Keep the original small relief curve on legacy worlds, whose historical surface is flat.
  const { tx, ty } = worldToTile(x, y);
  const tile = tileAt(map, tx, ty);
  if (!tile) return 0;
  return reliefY(tile.type, tile.elevation) * PATH_CELL;
}

/** Source rect for an atlas tile id (0-based, 12-column grid). */
export function atlasSourceRect(id: number): { sx: number; sy: number } {
  return { sx: (id % ATLAS_COLUMNS) * ATLAS_TILE_SIZE, sy: Math.floor(id / ATLAS_COLUMNS) * ATLAS_TILE_SIZE };
}

/** Source rect for a row-major transparent sand-water overlay mask. */
export function sandWaterOverlaySourceRect(id: number): { sx: number; sy: number } {
  return {
    sx: (id % SAND_WATER_OVERLAY_COLUMNS) * ATLAS_TILE_SIZE,
    sy: Math.floor(id / SAND_WATER_OVERLAY_COLUMNS) * ATLAS_TILE_SIZE,
  };
}

/** Runtime scale — atlas tile px → baked tile px. */
export function atlasScale(tileSize: number): number {
  return tileSize / ATLAS_TILE_SIZE;
}