import { BuildingType } from './gameTypes';

export interface BuildingCategoryDef {
  id: string;
  label: string;
  icon: string;
  color: string;
  hint?: string;
  types: BuildingType[];
}

/** Canonical build catalog — one section per building category. */
export const BUILDING_CATEGORIES: BuildingCategoryDef[] = [
  {
    id: 'housing',
    label: 'Housing',
    icon: '🏠',
    color: 'bg-amber-500',
    types: [BuildingType.House, BuildingType.Mansion, BuildingType.Villa, BuildingType.LeaderHouse],
  },
  {
    id: 'food',
    label: 'Food',
    icon: '🌾',
    color: 'bg-green-500',
    types: [BuildingType.Farm, BuildingType.Greenhouse, BuildingType.Barn, BuildingType.Silo, BuildingType.Mill, BuildingType.HuntingSpot, BuildingType.FishingSpot],
  },

  {
    id: 'resources',
    label: 'Resources',
    icon: '🪵',
    color: 'bg-stone-500',
    types: [BuildingType.LumberMill, BuildingType.Quarry, BuildingType.Mine, BuildingType.WoodStorehouse, BuildingType.GroundReinforcement],
  },
  {
    id: 'industry',
    label: 'Industry',
    icon: '🔨',
    color: 'bg-orange-500',
    types: [BuildingType.Blacksmith, BuildingType.Workshop, BuildingType.Store, BuildingType.Market],
  },
  {
    id: 'community',
    label: 'Community',
    icon: '🏛️',
    color: 'bg-amber-600',
    types: [
      BuildingType.TownHall,
      BuildingType.Church,
      BuildingType.Graveyard,
      BuildingType.Square,
      BuildingType.Tavern,
      BuildingType.Hotel,
      BuildingType.School,
      BuildingType.Hospital,
      BuildingType.Prison,
      BuildingType.Well,
      BuildingType.TamingPost,
      BuildingType.WildlifePreserve,
    ],
  },
  {
    id: 'defense',
    label: 'Defense',
    icon: '🛡️',
    color: 'bg-slate-500',
    hint: 'Walls boost barricade · R rotates walls & gates · Barracks adds militia',
    types: [
      BuildingType.Wall,
      BuildingType.WallGate,
      BuildingType.Watchtower,
      BuildingType.Barracks,
    ],
  },
  {
    id: 'infra',
    label: 'Infra',
    icon: '🛤️',
    color: 'bg-gray-500',
    hint: 'Roads 1.5× walk · Bridges on rivers · R rotates',
    types: [BuildingType.Road, BuildingType.Bridge],
  },
  {
    id: 'decor',
    label: 'Decor',
    icon: '🌷',
    color: 'bg-pink-600',
    hint: 'Beauty lifts the neighborhood — settlers drift toward pretty spots',
    types: [BuildingType.Garden, BuildingType.Statue, BuildingType.Lamp, BuildingType.Fence],
  },
];

const CATEGORY_BY_TYPE = new Map<BuildingType, string>();
for (const category of BUILDING_CATEGORIES) {
  for (const type of category.types) CATEGORY_BY_TYPE.set(type, category.id);
}

export function categoryForBuildingType(type: BuildingType): string {
  return CATEGORY_BY_TYPE.get(type) ?? BUILDING_CATEGORIES[0].id;
}

const PRODUCTION_CATEGORY_IDS = new Set(['food', 'resources', 'industry']);

/** Food, resource, and industry buildings get terrain/adjacency placement bonuses. */
export function isProductionBuildingType(type: BuildingType): boolean {
  return PRODUCTION_CATEGORY_IDS.has(categoryForBuildingType(type));
}

/** Canvas pad border dash per build-catalog category id. */
export function categoryBorderDashForType(type: BuildingType): number[] {
  switch (categoryForBuildingType(type)) {
    case 'housing':
      return [];
    case 'food':
      return [4, 3];
    case 'resources':
      return [2, 2];
    case 'industry':
      return [6, 2, 2, 2];
    case 'community':
      return [3, 3];
    case 'infra':
      return [1, 2];
    case 'defense':
      return [5, 3];
    default:
      return [];
  }
}