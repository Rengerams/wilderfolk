import type { Building, Resources, VillageForgeState, WorldState, ForgeOrderId, ForgeOrder } from './gameTypes';
import { BuildingType } from './gameTypes';
import { formatResourceCost } from './resourceCost';
import { isProductionTick, PRODUCTION_INTERVAL } from './dayCycle';
import { COMBAT_TECH } from './combatTech';
import { logEvent } from './eventLog';
import { addNotification } from './simEffects';

export function hasCompletedBlacksmith(state: { buildings: Building[] }): boolean {
  return state.buildings.some((b) => b.completed && b.type === BuildingType.Blacksmith);
}

export const FORGE_BONUSES = {
  guardHalberdPerGuard: 6,
  wallPlatePerSegment: 4,
  wallPlateCap: 96,
  quarryYieldMult: 1.15,
  /** Extra militia strength per completed watchtower when ballistae forged. */
  towerBallistaPerTower: 12,
  /** Base watchtower bonus stays 15; ballistae replace that with this total per tower. */
  towerBallistaTotalPerTower: 27,
} as const;

/** Forge progress is applied once per workshop production tick, and that tick is two days. */
export const FORGE_PACE_INTERVAL_TICKS = PRODUCTION_INTERVAL.workshop;

/** Progress points a smith delivers per forge tick — read at the two-day cadence above, not per tick. */
export const FORGE_PROGRESS_PER_TWO_DAY_TICK: Readonly<Record<ForgeOrderId, number>> = Object.freeze({
  iron_spears: 34,
  iron_shields: 34,
  iron_pickaxes: 32,
  guard_halberds: 30,
  wall_plates: 30,
  iron_swords: 28,
  scale_mail: 28,
  tower_ballistae: 26,
});

/** Display + forge priority: basic iron → utility → drill/walls → tier-5 war gear. */
export const FORGE_ORDERS: ForgeOrder[] = [
  {
    id: 'iron_spears',
    label: 'Iron Spears',
    emoji: '⚔️',
    description: 'Village-wide iron spears — longer hunts, fight back vs wolves, unlock militia raids.',
    techId: COMBAT_TECH.ironSpears,
    inputs: { wood: 25, stone: 20, gold: 15, iron: 15 },
    progressPerTick: FORGE_PROGRESS_PER_TWO_DAY_TICK.iron_spears,
  },
  {
    id: 'iron_shields',
    label: 'Iron Shields',
    emoji: '🛡️',
    description: 'Heavy shields for all settlers — strong predator blocks and raid armor baseline.',
    techId: COMBAT_TECH.ironShields,
    inputs: { wood: 30, stone: 25, gold: 15, iron: 15 },
    progressPerTick: FORGE_PROGRESS_PER_TWO_DAY_TICK.iron_shields,
  },
  {
    id: 'iron_pickaxes',
    label: 'Iron Pickaxes',
    emoji: '⛏️',
    description: `Quarries produce ${Math.round((FORGE_BONUSES.quarryYieldMult - 1) * 100)}% more stone while staffed.`,
    techId: 'mining_2',
    inputs: { wood: 25, stone: 30, gold: 15, iron: 10 },
    progressPerTick: FORGE_PROGRESS_PER_TWO_DAY_TICK.iron_pickaxes,
  },
  {
    id: 'guard_halberds',
    label: 'Guard Halberds',
    emoji: '🪖',
    description: `+${FORGE_BONUSES.guardHalberdPerGuard} militia per staffed barracks guard (stacks with base guard bonus).`,
    techId: COMBAT_TECH.militiaDrill,
    requiresForge: ['iron_spears'],
    inputs: { wood: 30, stone: 25, gold: 15, iron: 25 },
    progressPerTick: FORGE_PROGRESS_PER_TWO_DAY_TICK.guard_halberds,
  },
  {
    id: 'wall_plates',
    label: 'Reinforced Wall Plates',
    emoji: '🧱',
    description: `+${FORGE_BONUSES.wallPlatePerSegment} barricade per wall segment (max +${FORGE_BONUSES.wallPlateCap}).`,
    techId: COMBAT_TECH.reinforcedMasonry,
    requiresForge: ['iron_shields'],
    inputs: { wood: 30, stone: 40, gold: 15, iron: 20 },
    progressPerTick: FORGE_PROGRESS_PER_TWO_DAY_TICK.wall_plates,
  },
  {
    id: 'iron_swords',
    label: 'Iron Swords',
    emoji: '🗡️',
    description: 'Strongest militia weapons — replace iron spears for raids; better counter-attacks.',
    techId: COMBAT_TECH.ironSwords,
    requiresForge: ['iron_spears'],
    inputs: { wood: 30, stone: 25, gold: 15, iron: 30 },
    progressPerTick: FORGE_PROGRESS_PER_TWO_DAY_TICK.iron_swords,
  },
  {
    id: 'scale_mail',
    label: 'Scale Mail',
    emoji: '🦺',
    description: 'Heavy armor for the militia — replaces iron shields for raids and predator blocks.',
    techId: COMBAT_TECH.scaleMail,
    requiresForge: ['iron_shields'],
    inputs: { wood: 20, stone: 35, gold: 15, iron: 30 },
    progressPerTick: FORGE_PROGRESS_PER_TWO_DAY_TICK.scale_mail,
  },
  {
    id: 'tower_ballistae',
    label: 'Tower Ballistae',
    emoji: '🏰',
    description: `Watchtowers grant ${FORGE_BONUSES.towerBallistaTotalPerTower} barricade each (up from 15).`,
    techId: COMBAT_TECH.bastionTowers,
    requiresForge: ['wall_plates'],
    inputs: { wood: 35, stone: 45, gold: 20, iron: 40 },
    progressPerTick: FORGE_PROGRESS_PER_TWO_DAY_TICK.tower_ballistae,
  },
];

const FORGE_PRIORITY: ForgeOrderId[] = FORGE_ORDERS.map((o) => o.id);

export function createInitialForgeState(): VillageForgeState {
  return {
    activeOrder: null,
    progress: 0,
    completed: {},
  };
}

export function normalizeForgeState(
  forge: VillageForgeState | (VillageForgeState & { spearsReady?: boolean; shieldsReady?: boolean }) | null | undefined,
): VillageForgeState {
  if (!forge) return createInitialForgeState();
  const legacy = forge as VillageForgeState & { spearsReady?: boolean; shieldsReady?: boolean };
  const completed = { ...(forge.completed ?? {}) };
  if (legacy.spearsReady) completed.iron_spears = true;
  if (legacy.shieldsReady) completed.iron_shields = true;
  return {
    activeOrder: forge.activeOrder ?? null,
    progress: forge.progress ?? 0,
    completed,
  };
}

export function getForgeOrder(orderId?: ForgeOrderId | null): ForgeOrder | undefined {
  return FORGE_ORDERS.find((o) => o.id === orderId);
}

export function isForgeOrderComplete(
  forge: VillageForgeState | (VillageForgeState & { spearsReady?: boolean; shieldsReady?: boolean }) | null | undefined,
  orderId: ForgeOrderId,
): boolean {
  const normalized = normalizeForgeState(forge);
  return !!normalized.completed[orderId];
}

export function hasAnyForgeUpgrade(
  forge: VillageForgeState | (VillageForgeState & { spearsReady?: boolean; shieldsReady?: boolean }) | null | undefined,
): boolean {
  const normalized = normalizeForgeState(forge);
  return FORGE_ORDERS.some((order) => normalized.completed[order.id]);
}

export function getForgeQuarryMultiplier(state: WorldState): number {
  if (!state?.villageForge) return 1;
  return isForgeOrderComplete(state.villageForge, 'iron_pickaxes')
    ? FORGE_BONUSES.quarryYieldMult
    : 1;
}

export function findCompletedBlacksmith(
  state: WorldState,
  buildings: Building[] = state?.buildings ?? [],
): Building | undefined {
  return buildings.find((b) => b.completed && b.type === BuildingType.Blacksmith);
}

export function isBlacksmithStaffed(
  state: WorldState,
  buildings: Building[] = state?.buildings ?? [],
): boolean {
  return buildings.some(
    (b) => b.completed && b.type === BuildingType.Blacksmith && (b.occupants?.length ?? 0) > 0,
  );
}

/** Iron tech researched but not yet forged — and no order currently running. */
export function getOutstandingForgeOrder(state: WorldState): ForgeOrderId | null {
  if (!state?.villageForge || !state.unlockedTechs) return null;
  const forge = normalizeForgeState(state.villageForge);
  if (forge.activeOrder) return null;
  for (const orderId of FORGE_PRIORITY) {
    const order = getForgeOrder(orderId);
    if (!order) continue;
    if (!state.unlockedTechs.includes(order.techId)) continue;
    if (order.requiresForge?.some((req) => !isForgeOrderComplete(forge, req))) continue;
    if (!isForgeOrderComplete(forge, orderId)) return orderId;
  }
  return null;
}

export function formatForgeInputs(inputs: Partial<Resources>): string {
  return formatResourceCost({
    wood: inputs.wood,
    stone: inputs.stone,
    gold: inputs.gold,
    iron: inputs.iron,
  }) || '—';
}

function canAffordForgeInputs(resources: Resources | null | undefined, inputs: Partial<Resources>): boolean {
  if (!resources) return false;
  return (inputs.wood ?? 0) <= (resources.wood ?? 0)
    && (inputs.stone ?? 0) <= (resources.stone ?? 0)
    && (inputs.gold ?? 0) <= (resources.gold ?? 0)
    && (inputs.iron ?? 0) <= (resources.iron ?? 0);
}

function consumeForgeInputs(state: WorldState, inputs: Partial<Resources>): void {
  if (!state.resources || !canAffordForgeInputs(state.resources, inputs)) return;
  state.resources.wood = (state.resources.wood ?? 0) - (inputs.wood ?? 0);
  state.resources.stone = (state.resources.stone ?? 0) - (inputs.stone ?? 0);
  state.resources.gold = (state.resources.gold ?? 0) - (inputs.gold ?? 0);
  state.resources.iron = (state.resources.iron ?? 0) - (inputs.iron ?? 0);
}

export function getForgeBlockReason(state: WorldState, orderId: ForgeOrderId): string | null {
  const order = getForgeOrder(orderId);
  if (!order) return 'Unknown order';
  const forge = normalizeForgeState(state?.villageForge);
  if (!state?.unlockedTechs?.includes(order.techId)) {
    const techName = state?.researchNodes?.find((n) => n.id === order.techId)?.name ?? order.label;
    return `Research ${techName} first (Research tab)`;
  }
  if (!hasCompletedBlacksmith(state)) return 'Complete a Blacksmith first';
  if (isForgeOrderComplete(forge, orderId)) return `${order.label} already forged`;
  if (forge.activeOrder === orderId) return null;
  if (forge.activeOrder) {
    const active = getForgeOrder(forge.activeOrder);
    return `Smith is forging ${active?.label ?? 'another order'}`;
  }
  if (order.requiresForge) {
    for (const req of order.requiresForge) {
      if (!isForgeOrderComplete(forge, req)) {
        const reqOrder = getForgeOrder(req);
        return `Forge ${reqOrder?.label ?? req} first`;
      }
    }
  }
  const staffed = state?.buildings?.some(
    (b) => b.completed && b.type === BuildingType.Blacksmith && (b.occupants?.length ?? 0) > 0,
  );
  if (!staffed) return 'Staff the Blacksmith to forge';
  if (!canAffordForgeInputs(state?.resources, order.inputs)) {
    return `Need ${formatForgeInputs(order.inputs)}`;
  }
  return null;
}

export function queueForgeOrder(
  originalState: WorldState,
  buildingId: number,
  orderId: ForgeOrderId,
): WorldState {
  const block = getForgeBlockReason(originalState, orderId);
  if (block) {
    const blocked = structuredClone(originalState);
    if (!blocked.floatingTexts) blocked.floatingTexts = [];
    addNotification(blocked, 'Forge blocked', block, 'warning');
    return blocked;
  }
  const building = originalState.buildings?.find((b) => b.id === buildingId);
  if (!building || building.type !== BuildingType.Blacksmith || !building.completed) {
    return originalState;
  }
  const order = getForgeOrder(orderId);
  if (!order) return originalState;
  const state = structuredClone(originalState);
  if (!state.resources) state.resources = { food: 0, wood: 0, stone: 0, gold: 0, iron: 0 };
  state.resources = { ...state.resources };
  state.villageForge = normalizeForgeState(state.villageForge);
  if (state.villageForge.activeOrder === orderId) return originalState;
  consumeForgeInputs(state, order.inputs);
  state.villageForge.activeOrder = orderId;
  state.villageForge.progress = 0;
  // Same toast channel as completion / block (layout notifications only).
  addNotification(
    state,
    `${order.emoji} Forging ${order.label}`,
    'Staff the Blacksmith — progress shows on the forge panel until finished.',
    'info',
  );
  logEvent(state, 'event', `Blacksmith began forging ${order.label}`, building.campLabel ?? 'Blacksmith');
  return state;
}

/** Migrate saves that had iron gear via research-only rules or legacy forge booleans. */
export function migrateVillageForgeOnLoad(state: WorldState): void {
  if (!state) return;
  if (!state.villageForge) {
    const hasSmith = hasCompletedBlacksmith(state);
    const hadSpears = state.unlockedTechs?.includes(COMBAT_TECH.ironSpears) && hasSmith;
    const hadShields = state.unlockedTechs?.includes(COMBAT_TECH.ironShields) && hasSmith;
    state.villageForge = {
      activeOrder: null,
      progress: 0,
      completed: {
        ...(hadSpears ? { iron_spears: true } : {}),
        ...(hadShields ? { iron_shields: true } : {}),
      },
    };
    return;
  }
  state.villageForge = normalizeForgeState(state.villageForge);
}

export function tickVillageForge(state: WorldState, buildings: Building[]): void {
  if (!state?.villageForge) return;
  state.villageForge = normalizeForgeState(state.villageForge);
  const forge = state.villageForge;
  if (!forge.activeOrder) return;
  const order = getForgeOrder(forge.activeOrder);
  if (!order) {
    forge.activeOrder = null;
    forge.progress = 0;
    return;
  }

  const smith = buildings?.find(
    (b) => b.completed && b.type === BuildingType.Blacksmith && (b.occupants?.length ?? 0) > 0,
  );
  if (!smith) return;

  if (!isProductionTick(state.tick, FORGE_PACE_INTERVAL_TICKS)) return;

  // Extra staffed smiths speed the run (soft cap so 2–3 workers feel better than 1).
  const crew = Math.max(1, Math.min(3, smith.occupants?.length ?? 1));
  const pace = order.progressPerTick * (1 + (crew - 1) * 0.35);
  forge.progress = Math.min(100, forge.progress + pace);

  // Progress only on Blacksmith panel / Village Armament — one toast type on finish.
  if (forge.progress < 100) return;

  forge.completed[order.id] = true;
  forge.activeOrder = null;
  forge.progress = 0;

  addNotification(
    state,
    `${order.emoji} ${order.label} forged`,
    order.description,
    'success',
  );
  logEvent(state, 'event', `Blacksmith finished forging ${order.label}`, order.label);
}