export const GAME_VERSION = '0.6.5.1';
export const GAME_PHASE = 'Beta';
export const GAME_TITLE = 'Wilderfolk';
export const GAME_SUBTITLE = 'Where Beasts and Kin Unite';
/** Intro / splash line for the v0.6.5.1 release beat. */
export const GAME_VERSION_TAGLINE ='New homes. Stronger communities. Meaningful battles. Stories that live on.'
;

export const ECOLOGICAL_FACTS = [
  'Apex predators like wolves help regulate prey populations and maintain ecosystem balance.',
  'Biodiversity hotspots often contain species found nowhere else on Earth.',
  'Beavers engineer wetlands that support hundreds of other species.',
  'Mycorrhizal fungal networks connect trees and transfer nutrients through soil.',
  'Migratory species can travel thousands of miles between breeding and wintering grounds.',
  'Keystone species have disproportionately large effects on their ecosystems.',
  'Pollinators are essential for about 75% of flowering plants and 35% of global crops.',
  'Wetlands filter pollutants and reduce flooding for surrounding landscapes.',
  'Coral reefs support roughly 25% of all marine species despite covering less than 1% of the ocean floor.',
  'Rewilding degraded land can restore food webs and carbon storage over time.',
];
