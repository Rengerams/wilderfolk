import { getRenderEntityLayer, UNCACHED_RENDER_TICK, type Entity } from '../gameTypes';
import {
  syncGrassRenderGrid,
  type EntitySpatialGrid,
  USE_SPATIAL_GRID,
} from '../spatialGrid';
import type { EntityRenderMeta } from './entityRenderMeta';
import { buildRenderEntityShim } from './entityRenderMeta';
import type { RenderSoAReaderV1 } from './renderSoAReader';

export interface RenderSoABuckets {
  readonly tick: number;
  readonly grassSlots: number[];
  readonly treeSlots: number[];
  readonly animalSlots: number[];
  readonly humanSlots: number[];
  readonly shims: Entity[];
  readonly shimBySlot: Map<number, Entity>;
  /** Entity id → shim, built once per tick alongside `shims` so a per-repaint consumer (the hunt chase
  * lines) does not rebuild its own `Map` every frame. */
  readonly shimById: Map<number, Entity>;
}

let cachedTick = UNCACHED_RENDER_TICK;
let cachedMetaBySlot: EntityRenderMeta[] | undefined;
/**
 * The render buffer the buckets were built from.
 *
 * A tick counter alone is not a sufficient key: a command result carries its own render refresh, so
 * the same tick can arrive twice with a **different** buffer. Keyed on the tick alone, the second
 * call took the "nothing changed" branch and served the previous buffer's shims — so the drawn
 * position lagged a buffer behind the world on every command.
 */
let cachedReader: RenderSoAReaderV1 | null = null;
/**
 * The containers a rebuild refills in place. Only the entity shims are new objects each tick; the
 * lists and both slot indexes are the same instances, so a rebuild allocates none of them.
 */
const slotLists = {
  grassSlots: [] as number[],
  treeSlots: [] as number[],
  animalSlots: [] as number[],
  humanSlots: [] as number[],
  shims: [] as Entity[],
  shimBySlot: new Map<number, Entity>(),
  shimById: new Map<number, Entity>(),
};
let buckets: RenderSoABuckets = emptyBuckets();
let grassRenderGrid: EntitySpatialGrid | undefined;
let grassGridTick = UNCACHED_RENDER_TICK;
let grassGridMapW = 0;
let grassGridMapH = 0;

function emptyBuckets(): RenderSoABuckets {
  return {
    tick: UNCACHED_RENDER_TICK,
    ...slotLists,
  };
}

export function invalidateRenderSoABucketsCache(): void {
  cachedTick = UNCACHED_RENDER_TICK;
  cachedMetaBySlot = undefined;
  cachedReader = null;
  slotLists.grassSlots.length = 0;
  slotLists.treeSlots.length = 0;
  slotLists.animalSlots.length = 0;
  slotLists.humanSlots.length = 0;
  slotLists.shims.length = 0;
  slotLists.shimBySlot.clear();
  slotLists.shimById.clear();
  buckets = emptyBuckets();
  grassRenderGrid = undefined;
  grassGridTick = UNCACHED_RENDER_TICK;
  grassGridMapW = 0;
  grassGridMapH = 0;
}

export function updateRenderSoABuckets(
  reader: RenderSoAReaderV1,
  metaBySlot: EntityRenderMeta[] | undefined,
  tick: number,
): RenderSoABuckets {
  if (cachedTick === tick && cachedMetaBySlot === metaBySlot && cachedReader === reader) {
    return buckets;
  }

  try {
    cachedTick = tick;
    cachedMetaBySlot = metaBySlot;
    cachedReader = reader;

    const { grassSlots, treeSlots, animalSlots, humanSlots, shims, shimBySlot, shimById } = slotLists;
    grassSlots.length = 0;
    treeSlots.length = 0;
    animalSlots.length = 0;
    humanSlots.length = 0;
    shims.length = 0;
    shimBySlot.clear();
    shimById.clear();

    reader.forEachSlot((slot) => {
      if (!reader.isKnownType(slot)) return;

      const shim = buildRenderEntityShim(reader, slot, metaBySlot?.[slot]);
      // A deployed soldier is away with the war-band: never drawn standing in the village.
      if (!shim || shim.hiddenFromPlayer || shim.raidDeploymentId) return;

      const type = reader.type(slot);
      if (!type) return;

      switch (getRenderEntityLayer(type)) {
        case 'grass':
          grassSlots.push(slot);
          break;
        case 'tree':
          treeSlots.push(slot);
          break;
        case 'human':
          humanSlots.push(slot);
          break;
        case 'animal':
        default:
          animalSlots.push(slot);
          break;
      }

      shims.push(shim);
      shimBySlot.set(slot, shim);
      shimById.set(shim.id, shim);
    });

    // Depth sort based on Y coordinate
    treeSlots.sort((a, b) => reader.y(a) - reader.y(b));
    animalSlots.sort((a, b) => reader.y(a) - reader.y(b));
    humanSlots.sort((a, b) => reader.y(a) - reader.y(b));

    buckets = {
      tick,
      grassSlots,
      treeSlots,
      animalSlots,
      humanSlots,
      shims,
      shimBySlot,
      shimById,
    };

    return buckets;
  } catch (err) {
    invalidateRenderSoABucketsCache();
    throw err;
  }
}

/** Builds or reuses a tick-keyed grass spatial index from render SoA shims for the worker path. */
export function syncGrassRenderGridFromSoA(
  reader: RenderSoAReaderV1,
  metaBySlot: EntityRenderMeta[] | undefined,
  mapWidth: number,
  mapHeight: number,
  tick: number,
): EntitySpatialGrid | undefined {
  if (!USE_SPATIAL_GRID) return undefined;

  const bucketData = updateRenderSoABuckets(reader, metaBySlot, tick);
  if (
    grassRenderGrid &&
    grassGridTick === tick &&
    grassGridMapW === mapWidth &&
    grassGridMapH === mapHeight
  ) {
    return grassRenderGrid;
  }

  const grassEntities: Entity[] = [];
  for (let i = 0; i < bucketData.grassSlots.length; i++) {
    const slot = bucketData.grassSlots[i];
    const shim = bucketData.shimBySlot.get(slot);
    if (shim) grassEntities.push(shim);
  }

  grassRenderGrid = syncGrassRenderGrid(grassRenderGrid, mapWidth, mapHeight, grassEntities);
  grassGridTick = tick;
  grassGridMapW = mapWidth;
  grassGridMapH = mapHeight;

  return grassRenderGrid;
}

export function getRenderSoABuckets(): RenderSoABuckets {
  return buckets;
}