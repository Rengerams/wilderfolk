import { BUILDING_JOB_TYPES, BuildingType, GRID_SIZE } from './gameTypes';
import type { Building, WorldState } from './gameTypes';
import {
  getBuildingFootprintForType,
  snapBuildingCenter,
  type BuildingRotation,
  type CornerRotation,
  normalizeBuildingRotation,
} from './buildingRotation';
import { computeStripSegmentCenters, isStripBuildType, MAX_STRIP_SEGMENTS, type EnclosedArea } from './stripBuild';
import { isWallBuildingType } from './defenseStructures';
import {
  analyzeStripJunction,
  collectStripCenters,
  JUNCTION_PROXIMITY,
  resolveJunctionCenter,
  type StripJunctionInfo,
} from './stripJunction';

export const STRIP_SNAP_RADIUS = 38;

/** Spacing of the snap samples taken along an existing strip, in world px. */
const STRIP_SNAP_SAMPLE_PX = 12;
const STRIP_BEND_MIN_DISTANCE_PX = 30;

const ROAD_STRIP_TYPES = new Set<BuildingType>([BuildingType.Road]);
const ROAD_ENTRANCE_HOUSING_TYPES = new Set<BuildingType>([
  BuildingType.House, BuildingType.Villa, BuildingType.Mansion, BuildingType.LeaderHouse,
]);

/** Wall membership is `defenseStructures.isWallBuildingType`'s rule, not a second set here. */
export function isWallStripType(type: BuildingType): boolean {
  return isWallBuildingType(type);
}

export function isRoadStripType(type: BuildingType): boolean {
  return ROAD_STRIP_TYPES.has(type);
}

export function stripFamilyFor(type: BuildingType): 'wall' | 'road' | null {
  if (isWallStripType(type) || type === BuildingType.Wall) return 'wall';
  if (isRoadStripType(type)) return 'road';
  if (isStripBuildType(type)) return isWallStripType(type) ? 'wall' : 'road';
  return null;
}

function cellKey(x: number, y: number): string {
  return `${x},${y}`;
}

/** Endpoints of a straight strip segment (center-based chain). */
export function getStripSegmentEndpoints(
  type: BuildingType,
  cx: number,
  cy: number,
  rotation: BuildingRotation,
): [{ x: number; y: number }, { x: number; y: number }] {
  const { width, height } = getBuildingFootprintForType(type, rotation);
  const along = Math.max(width, height) / 2;
  if (normalizeBuildingRotation(rotation) === 0) {
    return [{ x: cx - along, y: cy }, { x: cx + along, y: cy }];
  }
  return [{ x: cx, y: cy - along }, { x: cx, y: cy + along }];
}

function collectSnapPoints(buildings: Building[], family: 'wall' | 'road'): { x: number; y: number }[] {
  const points: { x: number; y: number }[] = [];
  const types = family === 'wall' ? null : ROAD_STRIP_TYPES;
  for (const b of buildings) {
    const member = family === 'wall' ? isWallStripType(b.type) : types!.has(b.type);
    if (!b.completed || b.faction === 'rival' || !member) continue;
    const rot = normalizeBuildingRotation(b.rotation);
    const sampleType = b.type === BuildingType.WallGate ? BuildingType.WallGate : b.type;
    const [a, c] = getStripSegmentEndpoints(sampleType, b.x, b.y, rot);
    // The two ends and the centre leave a gap of half a tile on each side that the snap radius does
    // not reach, so a drag a third of the way along a road found nothing to connect to. Sampling the
    // whole run makes any point along an existing road a landing place for the next one.
    const span = Math.max(Math.abs(c.x - a.x), Math.abs(c.y - a.y));
    const steps = Math.max(1, Math.round(span / STRIP_SNAP_SAMPLE_PX));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      points.push({ x: a.x + (c.x - a.x) * t, y: a.y + (c.y - a.y) * t });
    }
  }
  return points;
}

function nearestSnapPoint(
  points: { x: number; y: number }[],
  x: number,
  y: number,
  maxDist: number,
): { x: number; y: number } | null {
  let best: { x: number; y: number } | null = null;
  let bestDist = maxDist * maxDist;
  for (const p of points) {
    const dx = p.x - x;
    const dy = p.y - y;
    const dSq = dx * dx + dy * dy;
    if (dSq < bestDist) {
      bestDist = dSq;
      best = p;
    }
  }
  return best;
}

/** South-facing building approaches, beyond foundations but within the road's footprint reach. */
function collectRoadEntranceSnapPoints(buildings: readonly Building[]): { x: number; y: number }[] {
  const roadHalfDepth = getBuildingFootprintForType(BuildingType.Road, 0).height / 2;
  const entrances: { x: number; y: number }[] = [];
  for (const building of buildings) {
    if (!building.completed || building.faction === 'rival') continue;
    if (!ROAD_ENTRANCE_HOUSING_TYPES.has(building.type) && !BUILDING_JOB_TYPES[building.type]) continue;
    const foundationEdge = building.y + building.height / 2;
    const approachY = foundationEdge + roadHalfDepth;
    const snappedY = snapBuildingCenter(BuildingType.Road, building.x, approachY, 0).y;
    // Validate clearance after the road's own grid snap, not only at the raw anchor.
    entrances.push({
      x: building.x,
      y: snappedY - roadHalfDepth < foundationEdge
        ? snappedY + GRID_SIZE
        : approachY,
    });
  }
  return entrances;
}

/** Snap drag endpoints to nearby strip chain endpoints. */
export function snapStripDragEndpoints(
  buildings: Building[],
  type: BuildingType,
  startX: number,
  startY: number,
  endX: number,
  endY: number,
): { startX: number; startY: number; endX: number; endY: number } {
  const family = stripFamilyFor(type);
  if (!family) return { startX, startY, endX, endY };
  const snaps = collectSnapPoints(buildings, family);
  const entrances = family === 'road' ? collectRoadEntranceSnapPoints(buildings) : [];
  if (snaps.length === 0 && entrances.length === 0) return { startX, startY, endX, endY };

  const startStripSnap = nearestSnapPoint(snaps, startX, startY, STRIP_SNAP_RADIUS);
  const endStripSnap = nearestSnapPoint(snaps, endX, endY, STRIP_SNAP_RADIUS);
  const startEntrance = startStripSnap ? null : nearestSnapPoint(entrances, startX, startY, STRIP_SNAP_RADIUS);
  const endEntrance = endStripSnap ? null : nearestSnapPoint(entrances, endX, endY, STRIP_SNAP_RADIUS);
  const startSnap = startStripSnap ?? startEntrance;
  const endSnap = endStripSnap ?? endEntrance;
  const snappedStartX = startSnap?.x ?? startX;
  const snappedEndX = endSnap?.x ?? endX;
  let snappedStartY = startSnap?.y ?? startY;
  let snappedEndY = endSnap?.y ?? endY;

  // Straight drags must use the snapped entrance's row at both ends of the strip.
  if (Math.abs(snappedEndX - snappedStartX) >= Math.abs(snappedEndY - snappedStartY)
    && Math.abs(snappedEndY - snappedStartY) < STRIP_BEND_MIN_DISTANCE_PX) {
    if (endEntrance && !startSnap) snappedStartY = snappedEndY;
    if (startEntrance && !endSnap) snappedEndY = snappedStartY;
  }
  return {
    startX: snappedStartX,
    startY: snappedStartY,
    endX: snappedEndX,
    endY: snappedEndY,
  };
}

export interface StripPlacementPiece {
  type: BuildingType;
  x: number;
  y: number;
  rotation: BuildingRotation | CornerRotation;
  /** Junction topology for renderer (tee/cross caps, T/+ wall arms). */
  junctionInfo?: StripJunctionInfo;
  /** Existing player building removed (corner swap or straight-through rebuild). */
  replacesBuildingId?: number;
}

export function resolveWallStripPlan(
  state: WorldState,
  stripType: BuildingType,
  centers: { x: number; y: number }[],
  stripRotation: BuildingRotation,
): StripPlacementPiece[] {
  const extra = centers.map((c) => ({
    x: c.x,
    y: c.y,
    rotation: stripRotation,
    type: stripType,
  }));
  const { hList, vList } = collectStripCenters(state.buildings, 'wall', extra);

  const pieces: StripPlacementPiece[] = [];
  const emitted = new Set<string>();

  for (const c of centers) {
    const snapped = snapBuildingCenter(stripType, c.x, c.y, stripRotation);
    const key = cellKey(snapped.x, snapped.y);
    if (emitted.has(key)) continue;

    const junctionPt = resolveJunctionCenter(snapped.x, snapped.y, hList, vList);
    const existing = findStripBuildingAt(state, junctionPt.x, junctionPt.y, JUNCTION_PROXIMITY * 0.75, 'wall');

    if (existing && isWallStripType(existing.type)) {
      // A perpendicular wall can intersect an existing wall; both arms must remain physical.
      if (stripType === BuildingType.Wall && existing.type === BuildingType.Wall
        && normalizeBuildingRotation(existing.rotation) !== stripRotation) {
        pieces.push({ type: stripType, x: snapped.x, y: snapped.y, rotation: stripRotation });
        emitted.add(key);
        continue;
      }
      emitted.add(key);
      // A WallGate run replaces the plain Wall it lands on — the placement owner
      // demolishes it and refunds half. Any other wall-family overlap (a Wall run
      // crossing an existing gate, or a same-type piece) is simply stepped over,
      // so the rest of the run still places.
      if (stripType === BuildingType.WallGate && existing.type === BuildingType.Wall) {
        pieces.push({
          type: stripType,
          x: existing.x,
          y: existing.y,
          rotation: normalizeBuildingRotation(existing.rotation),
          replacesBuildingId: existing.id,
        });
      }
      continue;
    }

    pieces.push({
      type: stripType,
      x: snapped.x,
      y: snapped.y,
      rotation: stripRotation,
    });
    emitted.add(key);
  }

  return pieces;
}

export function resolveRoadStripPlan(
  state: WorldState,
  centers: { x: number; y: number }[],
  stripRotation: BuildingRotation,
): StripPlacementPiece[] {
  const extra = centers.map((c) => ({
    x: c.x,
    y: c.y,
    rotation: stripRotation,
    type: BuildingType.Road,
  }));
  const { hList, vList, along } = collectStripCenters(state.buildings, 'road', extra);

  const emitted = new Set<string>();
  return centers.flatMap((c): StripPlacementPiece[] => {
    const snapped = snapBuildingCenter(BuildingType.Road, c.x, c.y, stripRotation);
    const key = cellKey(snapped.x, snapped.y);
    if (emitted.has(key)) return [];
    emitted.add(key);
    // A repeated stroke must not create another building over an existing road segment.
    const existing = state.buildings.some((b) => b.type === BuildingType.Road
      && b.faction !== 'rival' && b.x === snapped.x && b.y === snapped.y
      && normalizeBuildingRotation(b.rotation) === stripRotation);
    if (existing) return [];
    const junctionPt = resolveJunctionCenter(snapped.x, snapped.y, hList, vList);
    const info = analyzeStripJunction(junctionPt.x, junctionPt.y, hList, vList, along);
    const junctionInfo = info.kind === 'end' || info.kind === 'straight' ? undefined : info;
    return [{
      type: BuildingType.Road,
      x: snapped.x,
      y: snapped.y,
      rotation: stripRotation,
      junctionInfo,
    }];
  });
}

export function resolveStripPlan(
  state: WorldState,
  type: BuildingType,
  centers: { x: number; y: number }[],
  stripRotation: BuildingRotation,
): StripPlacementPiece[] {
  if (type === BuildingType.Road) return resolveRoadStripPlan(state, centers, stripRotation);
  if (type === BuildingType.Wall || type === BuildingType.WallGate) {
    return resolveWallStripPlan(state, type, centers, stripRotation);
  }
  return centers.map((c) => ({
    type,
    x: c.x,
    y: c.y,
    rotation: stripRotation,
  }));
}

export function findStripBuildingAt(
  state: WorldState,
  x: number,
  y: number,
  tolerance = 6,
  family?: 'wall' | 'road',
): Building | undefined {
  const familyFilter = family === 'wall'
    ? isWallStripType
    : family === 'road'
      ? isRoadStripType
      : null;
  for (const b of state.buildings) {
    if (!b.completed || b.faction === 'rival') continue;
    if (familyFilter) {
      if (!familyFilter(b.type)) continue;
    } else if (!isWallStripType(b.type) && !isRoadStripType(b.type)) {
      continue;
    }
    if (Math.hypot(b.x - x, b.y - y) <= tolerance) return b;
  }
  return undefined;
}

/** Select only matching player-built strips intersecting the drag rectangle, in stable world order. */
export function collectStripDemolitionIds(
  buildings: readonly Building[],
  type: BuildingType,
  startX: number,
  startY: number,
  endX: number,
  endY: number,
): number[] {
  const family = stripFamilyFor(type);
  if (!family) return [];
  const left = Math.min(startX, endX);
  const right = Math.max(startX, endX);
  const top = Math.min(startY, endY);
  const bottom = Math.max(startY, endY);
  const ids: number[] = [];
  for (const building of buildings) {
    if (building.faction === 'rival') continue;
    const matching = type === BuildingType.Fence
      ? building.type === BuildingType.Fence
      : family === 'wall' ? isWallStripType(building.type) : isRoadStripType(building.type);
    if (!matching) continue;
    if (building.x + building.width / 2 < left || building.x - building.width / 2 > right
      || building.y + building.height / 2 < top || building.y - building.height / 2 > bottom) continue;
    ids.push(building.id);
    if (ids.length >= MAX_STRIP_SEGMENTS) break;
  }
  return ids;
}

const ENCLOSURE_CELL = 24;

/** Flood-fill from map border; highlight regions fully surrounded by walls. */
export function findEnclosedWallAreas(
  state: WorldState,
  extraCenters: { x: number; y: number }[] = [],
): EnclosedArea[] {
  const cols = Math.ceil(state.width / ENCLOSURE_CELL);
  const rows = Math.ceil(state.height / ENCLOSURE_CELL);
  const blocked = new Uint8Array(cols * rows);

  const markBlocked = (wx: number, wy: number, radius: number) => {
    const cx = Math.floor(wx / ENCLOSURE_CELL);
    const cy = Math.floor(wy / ENCLOSURE_CELL);
    const r = Math.ceil(radius / ENCLOSURE_CELL);
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        const col = cx + dx;
        const row = cy + dy;
        if (col < 0 || row < 0 || col >= cols || row >= rows) continue;
        blocked[row * cols + col] = 1;
      }
    }
  };

  for (const b of state.buildings) {
    if (!b.completed || b.faction === 'rival') continue;
    if (!isWallStripType(b.type)) continue;
    markBlocked(b.x, b.y, Math.max(b.width, b.height) * 0.45);
  }
  for (const c of extraCenters) {
    markBlocked(c.x, c.y, 28);
  }

  const exterior = new Uint8Array(cols * rows);
  const queue: number[] = [];
  const push = (col: number, row: number) => {
    if (col < 0 || row < 0 || col >= cols || row >= rows) return;
    const idx = row * cols + col;
    if (blocked[idx] || exterior[idx]) return;
    exterior[idx] = 1;
    queue.push(idx);
  };

  for (let col = 0; col < cols; col++) {
    push(col, 0);
    push(col, rows - 1);
  }
  for (let row = 0; row < rows; row++) {
    push(0, row);
    push(cols - 1, row);
  }

  while (queue.length > 0) {
    const idx = queue.pop()!;
    const col = idx % cols;
    const row = Math.floor(idx / cols);
    push(col - 1, row);
    push(col + 1, row);
    push(col, row - 1);
    push(col, row + 1);
  }

  const seen = new Uint8Array(cols * rows);
  const areas: EnclosedArea[] = [];

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const idx = row * cols + col;
      if (blocked[idx] || exterior[idx] || seen[idx]) continue;

      let minC = col;
      let maxC = col;
      let minR = row;
      let maxR = row;
      let size = 0;
      const local: number[] = [idx];
      seen[idx] = 1;

      while (local.length > 0) {
        const cur = local.pop()!;
        size++;
        const c = cur % cols;
        const r = Math.floor(cur / cols);
        minC = Math.min(minC, c);
        maxC = Math.max(maxC, c);
        minR = Math.min(minR, r);
        maxR = Math.max(maxR, r);

        const neighbors = [c - 1 + r * cols, c + 1 + r * cols, c + (r - 1) * cols, c + (r + 1) * cols];
        for (const n of neighbors) {
          const nc = n % cols;
          const nr = Math.floor(n / cols);
          if (nc < 0 || nr < 0 || nc >= cols || nr >= rows) continue;
          if (blocked[n] || exterior[n] || seen[n]) continue;
          seen[n] = 1;
          local.push(n);
        }
      }

      if (size < 4) continue;
      areas.push({
        x: minC * ENCLOSURE_CELL,
        y: minR * ENCLOSURE_CELL,
        w: (maxC - minC + 1) * ENCLOSURE_CELL,
        h: (maxR - minR + 1) * ENCLOSURE_CELL,
      });
    }
  }

  return areas;
}

/** Freehand strip stroke: preserve every mouse turn and create one bounded placement command. */
export function buildStripPlanFromStroke(
  state: WorldState,
  type: BuildingType,
  points: readonly { x: number; y: number }[],
): { plan: StripPlacementPiece[]; enclosedAreas: EnclosedArea[] } {
  if (points.length === 0) return { plan: [], enclosedAreas: [] };
  if (points.length === 1) {
    const p = points[0];
    return buildStripPlanFromDrag(state, type, p.x, p.y, p.x, p.y, 0);
  }
  const plan: StripPlacementPiece[] = [];
  const seen = new Set<string>();
  const emit = (piece: StripPlacementPiece) => {
    const key = `${piece.type}:${piece.x}:${piece.y}:${piece.rotation}`;
    if (!seen.has(key) && plan.length < MAX_STRIP_SEGMENTS) {
      seen.add(key);
      plan.push(piece);
    }
  };
  let anchor = points[0];
  for (let i = 1; i < points.length && plan.length < MAX_STRIP_SEGMENTS; i++) {
    const start = anchor;
    const end = points[i];
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    if (dx === 0 && dy === 0) continue;
    if (plan.length > 0 && Math.max(Math.abs(dx), Math.abs(dy)) < STRIP_BEND_MIN_DISTANCE_PX) continue;
    const rotation: BuildingRotation = Math.abs(dx) >= Math.abs(dy) ? 0 : 90;
    const snapped = snapStripDragEndpoints(state.buildings, type, start.x, start.y, end.x, end.y);
    const cornerX = rotation === 0 ? snapped.endX : snapped.startX;
    const cornerY = rotation === 0 ? snapped.startY : snapped.endY;
    const first = computeStripSegmentCenters(
      type, snapped.startX, snapped.startY, cornerX, cornerY, rotation,
    );
    for (const piece of resolveStripPlan(state, type, first, rotation)) emit(piece);
    if (plan.length >= MAX_STRIP_SEGMENTS) break;
    const bend = Math.min(Math.abs(snapped.endX - snapped.startX), Math.abs(snapped.endY - snapped.startY))
      >= STRIP_BEND_MIN_DISTANCE_PX;
    anchor = bend ? end : { x: cornerX, y: cornerY };
    if (bend) {
      const turnRotation: BuildingRotation = rotation === 0 ? 90 : 0;
      const second = computeStripSegmentCenters(
        type, cornerX, cornerY, snapped.endX, snapped.endY, turnRotation,
      );
      for (const piece of resolveStripPlan(state, type, second, turnRotation)) emit(piece);
    }
  }
  const enclosedAreas = isWallStripType(type)
    ? findEnclosedWallAreas(state, plan.map((piece) => ({ x: piece.x, y: piece.y }))) : [];
  return { plan, enclosedAreas };
}

export function buildStripPlanFromDrag(
  state: WorldState,
  type: BuildingType,
  startX: number,
  startY: number,
  endX: number,
  endY: number,
  rotation: BuildingRotation,
): {
  plan: StripPlacementPiece[];
  enclosedAreas: EnclosedArea[];
} {
  const snapped = snapStripDragEndpoints(state.buildings, type, startX, startY, endX, endY);
  // A diagonal drag becomes one L-shaped stroke instead of silently discarding an axis.
  const bend = Math.min(Math.abs(snapped.endX - snapped.startX), Math.abs(snapped.endY - snapped.startY))
    >= STRIP_BEND_MIN_DISTANCE_PX;
  const cornerX = rotation === 0 ? snapped.endX : snapped.startX;
  const cornerY = rotation === 0 ? snapped.startY : snapped.endY;
  const first = computeStripSegmentCenters(
    type, snapped.startX, snapped.startY,
    bend ? cornerX : snapped.endX,
    bend ? cornerY : snapped.endY,
    rotation,
  );
  const plan = resolveStripPlan(state, type, first, rotation);
  if (bend && plan.length < MAX_STRIP_SEGMENTS) {
    const turnRotation: BuildingRotation = rotation === 0 ? 90 : 0;
    const second = computeStripSegmentCenters(
      type, cornerX, cornerY, snapped.endX, snapped.endY, turnRotation,
    );
    const turnPlan = resolveStripPlan(state, type, second, turnRotation);
    plan.push(...turnPlan.slice(0, MAX_STRIP_SEGMENTS - plan.length));
  }
  const enclosedAreas = isWallStripType(type)
    ? findEnclosedWallAreas(state, plan.map((p) => ({ x: p.x, y: p.y })))
    : [];
  return { plan, enclosedAreas };
}