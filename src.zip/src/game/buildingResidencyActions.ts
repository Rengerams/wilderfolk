import { applyLeaderHousePhase } from './leaderHouse';
import { moveResident } from './housingPipeline';
import type { WorldState } from './gameTypes';
import { assignMissingWorkers } from './workforce';
import { allPlayerHumans } from './playerHuman';
import { isAssignableHome } from './housingModel';
import { assignMissingResidences, syncResidenceOccupants } from './housingPipeline';

/** Living player humans — command actions reconcile this list only after a housing change. */
/**
 * Residence changes can affect both household placement and ordinary jobs.
 * Keep the existing reconciliation order in one named command-transition step.
 */
function reconcileAssignmentsAfterResidenceChange(state: WorldState): void {
  const humans = allPlayerHumans(state.entities);
  assignMissingResidences(humans, state.buildings, state.entities, undefined, state.genealogyRegistry,
    (ledger) => applyLeaderHousePhase(state, ledger));
  assignMissingWorkers(humans, state.buildings, state);
}

/** Mutates state — re-run automatic housing assignment for a residence. */
function applyResidentAssignment(state: WorldState, buildingId: number): WorldState {
  const building = state.buildings.find((candidate) => candidate.id === buildingId);
  if (!building || !isAssignableHome(building)) return state;

  reconcileAssignmentsAfterResidenceChange(state);
  return state;
}

/** Re-run automatic housing assignment (settlers pick homes by themselves). */
export function assignResidentToBuilding(originalState: WorldState, buildingId: number, ownership: 'isolated' | 'owned' = 'isolated'): WorldState {
  return applyResidentAssignment(ownership === 'owned' ? originalState : structuredClone(originalState), buildingId);
}

/** Remove a resident, then immediately restore housing and workforce consistency. */
export function removeResidentFromBuilding(
  originalState: WorldState,
  buildingId: number,
  humanId: number,
): WorldState {
  const state = structuredClone(originalState);
  const building = state.buildings.find((candidate) => candidate.id === buildingId);
  const human = state.entities.find((entity) => entity.id === humanId);
  if (!building || !human || human.residenceBuildingId !== buildingId) return state;

  moveResident(human, undefined, 'player', { buildings: state.buildings });
  syncResidenceOccupants(state.entities, state.buildings);
  reconcileAssignmentsAfterResidenceChange(state);
  return state;
}