import { applyLeaderHousePhase } from './leaderHouse';
/**
 * Daily population reconciliation owner called by tickLayerDaily — once per colony day.
 * Manages immigration rolls, housing capacities, dead entity pruning, and residence assignment.
 */
import type { WorldState, Entity, Building } from './gameTypes';
import type { PopulationCounts } from './entityCounts';
import { BuildingType } from './gameTypes';
import { indexLivingEntity } from './entityIndex';
import { getResidenceCapacity, isMinor } from './housingModel';
import { assignMissingResidences } from './housingPipeline';
import { createImmigrantSettler } from './worldGen';
import { findHumanSpawnNear } from './terrainSystems';
import { isPlayerHuman } from './playerHuman';
import { getTownHallImmigrationMultiplier } from './townHall';
import { addFloatingText, addNotification } from './simEffects';
import { logEvent } from './eventLog';
import type { TickContext } from './simulation/simulationTypes';
import { pruneFactionWanderStates } from './factionWander';
import { getSimRng } from './simRng';
import { pushNewEntity } from './simulation/simulationEntities';

function tickImmigration(
  state: WorldState,
  ctx: TickContext,
  allAlive: Entity[],
  counts: PopulationCounts,
): void {
  const { updatedBuildings, width, height } = ctx;

  // Single-pass scan for completed player housing
  let housingCap = 0;
  const homes: Building[] = [];

  for (let i = 0; i < updatedBuildings.length; i++) {
    const b = updatedBuildings[i];
    if (
      b.completed &&
      b.faction !== 'rival' &&
      (b.type === BuildingType.House || b.type === BuildingType.Mansion || b.type === BuildingType.Villa)
    ) {
      housingCap += getResidenceCapacity(b);
      homes.push(b);
    }
  }

  const reputation = state.villageReputation ?? 0;
  state.maxHumanPopulation = 5 + housingCap + Math.floor(reputation / 10);

  const completedHousingCount = homes.length;
  const festivalMultiplier = state.festival?.active ? 1.5 : 1.0;
  const townHallMultiplier = getTownHallImmigrationMultiplier(updatedBuildings);

  const immigrationChance = Math.min(
    0.95,
    (0.05 + reputation / 120 + completedHousingCount * 0.03) *
      festivalMultiplier *
      townHallMultiplier,
  );

  const openSlots = state.maxHumanPopulation - counts.humans;

  // Reached exactly once per colony day: `gameTick` calls `tickLayerDaily` only when
  // `state.tick % TICKS_PER_DAY === 0`, and that layer is the only caller of this function. The
  // roll is therefore a daily decision, and it must stay one — calling this a second time in the
  // same day would roll the `dailyPopulation` stream again and admit a second family.
  // Seeded: immigration is part of the world state, so the same day of the same seed admits
  // the same family. Resolved here because `setSimSeed` drops cached streams.
  const rng = getSimRng('dailyPopulation');
  if (
    state.tick > 0 &&
    openSlots > 0 &&
    rng() < immigrationChance
  ) {
    let spawnX = width / 2;
    let spawnY = height / 2;

    if (homes.length > 0) {
      const home = homes[Math.floor(rng() * homes.length)];
      spawnX = home.x + home.width / 2;
      spawnY = home.y + home.height / 2;
    }

    const rawSpawnX = spawnX + (rng() - 0.5) * 40;
    const rawSpawnY = spawnY + (rng() - 0.5) * 40;
    const spawn = findHumanSpawnNear(state, rawSpawnX, rawSpawnY);
    const newcomers = createImmigrantSettler(state, spawn.x, spawn.y, openSlots, rng);
    let admitted = 0;

    for (let i = 0; i < newcomers.length; i++) {
      const newcomer = newcomers[i];
      if (counts.humans >= state.maxHumanPopulation) break;

      // 1. Authoritative world entity array
      state.entities.push(newcomer);

      // 2. Living entities array for current frame
      allAlive.push(newcomer);

      // 3. Canonical spawn bookkeeping: ctx.newEntities (worker delta), entityById, and the
      // spatial grids. The grids are the point — this daily layer runs *after* the tick's
      // `assertSpatialGridInvariants`, and the previous hand-rolled `indexEntity` left the
      // newcomer invisible to social/hunt queries for the rest of the tick
      // (`BUG_REPORTS/2026-09-16-daily-immigrant-bypasses-the-spatial-grid.md`).
      pushNewEntity(state, ctx, newcomer);

      // 4. id → living map used by the optimistic display path
      indexLivingEntity(state, newcomer);

      counts.humans++;
      admitted++;
    }

    if (admitted > 0) {
      state.humanPopulation = counts.humans;

      const villagers = allAlive.filter(isPlayerHuman);
      // Newcomers arrive homeless, so the pass's own global fill seats them on this call whatever the
      // sweep bucket is; the tick only spreads the already-housed reassignment work.
      assignMissingResidences(villagers, updatedBuildings, allAlive, state.tick, state.genealogyRegistry,
        (ledger) => applyLeaderHousePhase(state, ledger));

      const label = admitted === 1
        ? (isMinor(newcomers[0]) ? 'A young settler arrived' : '+1 Settler arrived')
        : (admitted >= 3 ? `A settler family arrived (${admitted})` : `+${admitted} Settlers arrived`);
      addFloatingText(state, spawnX, spawnY - 18, label, '#22c55e');
      logEvent(state, 'migration', label);
      addNotification(state, 'New Settler', label, 'success', { x: spawnX, y: spawnY });
    }
  }
}

export function tickDailyPopulation(
  state: WorldState,
  ctx: TickContext,
  allAlive: Entity[],
  counts: PopulationCounts,
): void {
  // Prune dead entities backwards from allAlive
  for (let i = allAlive.length - 1; i >= 0; i--) {
    if (!allAlive[i].alive) {
      allAlive.splice(i, 1);
    }
  }

  const livingIds: number[] = new Array(allAlive.length);
  for (let i = 0; i < allAlive.length; i++) {
    livingIds[i] = allAlive[i].id;
  }
  pruneFactionWanderStates(livingIds);

  tickImmigration(state, ctx, allAlive, counts);
}