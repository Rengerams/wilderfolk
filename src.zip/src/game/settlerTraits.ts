/**
 * Settler personality traits — a trait catalog that makes each villager
 * feel like an individual. Traits are assigned at creation (1–3 per settler),
 * inherited partly from parents, and every gameplay effect is read through the
 * personality evaluator.
 */
import { createSeededRng, getSimRng, type RngStream } from './simRng';

/** Single owner of the 14 saved settler DNA trait IDs. */
export type SettlerTrait =
  | 'hardy'
  | 'brave'
  | 'gregarious'
  | 'timid'
  | 'greenthumb'
  | 'lucky'
  | 'nurturing'
  | 'insightful'
  | 'chivalrous'
  | 'resourceful'
  | 'stoic'
  | 'graceful'
  | 'intuitive'
  | 'fierce';

/** Structural read-only input avoids a gameTypes → settlerTraits → gameTypes type cycle. */
interface TraitCarrier {
  readonly traits?: readonly SettlerTrait[] | null;
}

export interface TraitDef {
  readonly id: SettlerTrait;
  readonly label: string;
  readonly emoji: string;
  /** Short player-facing description shown in the inspector. */
  readonly description: string;
}

export const TRAIT_DEFS: Readonly<Record<SettlerTrait, TraitDef>> = {
  hardy: {
    id: 'hardy',
    label: 'Hardy',
    emoji: '💪',
    description: 'Tires more slowly on hard work — endures the longest shifts.',
  },
  brave: {
    id: 'brave',
    label: 'Brave',
    emoji: '🛡️',
    description: 'Ranges farther and chases game harder while hunting.',
  },
  gregarious: {
    id: 'gregarious',
    label: 'Gregarious',
    emoji: '🗣️',
    description: 'Courts faster and chats more around the village.',
  },
  timid: {
    id: 'timid',
    label: 'Timid',
    emoji: '🐇',
    description: 'Courts slower and flees sooner from predators.',
  },
  greenthumb: {
    id: 'greenthumb',
    label: 'Greenthumb',
    emoji: '🌿',
    description: 'A patient hand with crops — farms yield more.',
  },
  lucky: {
    id: 'lucky',
    label: 'Lucky',
    emoji: '🍀',
    description: 'Better hunt luck and a bit more likely to conceive.',
  },
  nurturing: {
    id: 'nurturing',
    label: 'Nurturing',
    emoji: '💗',
    description: 'Soft-hearted — speaks for mercy when a captive is judged.',
  },
  insightful: {
    id: 'insightful',
    label: 'Insightful',
    emoji: '🔮',
    description: 'A sharp mind — the village researches a little faster.',
  },
  chivalrous: {
    id: 'chivalrous',
    label: 'Chivalrous',
    emoji: '🦁',
    description: 'Gallant and protective — adds militia strength in a raid.',
  },
  resourceful: {
    id: 'resourceful',
    label: 'Resourceful',
    emoji: '🔨',
    description: 'Solves practical problems fast — builds quicker on site.',
  },
  stoic: {
    id: 'stoic',
    label: 'Stoic',
    emoji: '🏔️',
    description: 'Calm and steady — mourns loss and recovers sooner.',
  },
  graceful: {
    id: 'graceful',
    label: 'Graceful',
    emoji: '✨',
    description: 'Poised and elegant — courts and charms a little faster.',
  },
  intuitive: {
    id: 'intuitive',
    label: 'Intuitive',
    emoji: '🦉',
    description: 'Sharp instincts and empathy — chats up coworkers more.',
  },
  fierce: {
    id: 'fierce',
    label: 'Fierce',
    emoji: '🔥',
    description: 'Hot-blooded — presses for severity over a captive and quarrels easily.',
  },
};

export const TRAIT_POOL: readonly SettlerTrait[] = [
  'hardy',
  'brave',
  'gregarious',
  'timid',
  'greenthumb',
  'lucky',
  'nurturing',
  'insightful',
  'chivalrous',
  'resourceful',
  'stoic',
  'graceful',
  'intuitive',
  'fierce',
] as const;

/** Traits drawn more often by women (community & wisdom leaning). */
const FEMALE_LEANING: ReadonlySet<SettlerTrait> = new Set<SettlerTrait>([
  'nurturing',
  'insightful',
  'gregarious',
  'lucky',
  'graceful',
  'intuitive',
  'fierce',
]);

/** Traits drawn more often by men (frontier & physical leaning). */
const MALE_LEANING: ReadonlySet<SettlerTrait> = new Set<SettlerTrait>([
  'hardy',
  'brave',
  'greenthumb',
  'chivalrous',
  'resourceful',
  'stoic',
]);

/** Bias strength when the trait matches the settler's gender (1.0 = neutral). */
const GENDER_BIAS = 1.6;
/** Neutral weight for every trait regardless of gender. */
const BASE_WEIGHT = 1.0;

/** Mutually exclusive pairs — a settler can't carry both. */
const TRAIT_OPPOSITES: ReadonlyArray<readonly [SettlerTrait, SettlerTrait]> = [
  ['brave', 'timid'],
  ['gregarious', 'timid'],
];

/** Standard trait allocation count per settler. */
const TRAIT_COUNT = 3;

/** Checks if a candidate trait conflicts with an existing set of traits. */
function conflictsWith(trait: SettlerTrait, existing: readonly SettlerTrait[]): boolean {
  for (let i = 0; i < TRAIT_OPPOSITES.length; i++) {
    const [a, b] = TRAIT_OPPOSITES[i];
    if (trait === a && existing.includes(b)) return true;
    if (trait === b && existing.includes(a)) return true;
  }
  return false;
}

/**
 * Roll a single random trait weighted by gender that doesn't conflict.
 *
 * `stream` is the injected-RNG seam: the live allocation path passes nothing and draws the colony's
 * `settlerTraits` stream, while save-load backfill passes its own derived stream.
 */
function pickTrait(
  existing: SettlerTrait[],
  gender?: 'male' | 'female',
  stream?: RngStream,
): SettlerTrait {
  const pool: SettlerTrait[] = [];
  for (let i = 0; i < TRAIT_POOL.length; i++) {
    const t = TRAIT_POOL[i];
    if (!existing.includes(t) && !conflictsWith(t, existing)) {
      pool.push(t);
    }
  }

  if (pool.length === 0) {
    return existing[0] ?? 'hardy';
  }

  const leaningSet = gender === 'female' ? FEMALE_LEANING : MALE_LEANING;
  const weights = pool.map((t) => (leaningSet.has(t) ? GENDER_BIAS : BASE_WEIGHT));
  const total = weights.reduce((s, w) => s + w, 0);

  let roll = (stream ?? getSimRng('settlerTraits'))() * total;
  for (let i = 0; i < pool.length; i++) {
    roll -= weights[i];
    if (roll <= 0) return pool[i];
  }

  return pool[pool.length - 1];
}

/**
 * Assign random traits for a new settler (gender-weighted and non-conflicting).
 *
 * One allocation rule for both paths: `stream` is the only difference between a live roll and the
 * legacy save-load backfill, which injects a stream of its own so it cannot consume live draws.
 */
export function rollSettlerTraits(
  existing: SettlerTrait[] = [],
  gender?: 'male' | 'female',
  stream?: RngStream,
): SettlerTrait[] {
  const traits = [...existing];
  while (traits.length < TRAIT_COUNT) {
    traits.push(pickTrait(traits, gender, stream));
  }
  return traits;
}

/**
 * Canonical baseline DNA for a settler saved before traits existed.
 *
 * Derived from the colony seed and the citizen's own id, so the fill is stable for a save file, uses
 * the canonical allocation rule above, and never draws from — or perturbs — a live RNG stream.
 */
export function rollLegacySettlerTraits(
  colonySeed: number,
  entityId: number,
  gender?: 'male' | 'female',
): SettlerTrait[] {
  return rollSettlerTraits([], gender, createSeededRng(colonySeed, `legacySettlerTraits:${entityId}`));
}

/**
 * The recognized traits a saved array may keep, in the order it wrote them.
 *
 * Non-arrays, unknown ids, duplicates, mutually exclusive pairs and anything past the three
 * canonical slots are dropped; an existing nonempty valid set is never extended.
 */
export function validSettlerTraits(saved: unknown): SettlerTrait[] {
  if (!Array.isArray(saved)) return [];
  const kept: SettlerTrait[] = [];
  for (const value of saved) {
    if (typeof value !== 'string' || !TRAIT_POOL.includes(value as SettlerTrait)) continue;
    const trait = value as SettlerTrait;
    if (kept.includes(trait) || conflictsWith(trait, kept)) continue;
    if (kept.length >= TRAIT_COUNT) break;
    kept.push(trait);
  }
  return kept;
}

/** Per-trait chance a parent passes personality to a child. */
const INHERIT_CHANCE = 0.5;
/** Hard cap on how many traits a child can inherit from parents. */
const MAX_INHERITED = 3;

/**
 * DNA-like inheritance: each parent trait has a 50% chance to pass to the
 * child, drawing from both parents and rejecting mutually exclusive traits.
 */
export function inheritSettlerTraits(
  mother?: TraitCarrier,
  father?: TraitCarrier,
): SettlerTrait[] {
  const inherited: SettlerTrait[] = [];
  const parents = [mother, father];
  const rng = getSimRng('settlerTraits');

  for (let p = 0; p < parents.length; p++) {
    const parentTraits = parents[p]?.traits ?? [];
    for (let t = 0; t < parentTraits.length; t++) {
      const trait = parentTraits[t];
      if (inherited.length >= MAX_INHERITED) break;
      if (
        rng() < INHERIT_CHANCE &&
        !inherited.includes(trait) &&
        !conflictsWith(trait, inherited)
      ) {
        inherited.push(trait);
      }
    }
  }

  return inherited;
}


/** True when the entity carries the given trait. */
export function hasTrait(entity: TraitCarrier, trait: SettlerTrait): boolean {
  return entity.traits?.includes(trait) ?? false;
}