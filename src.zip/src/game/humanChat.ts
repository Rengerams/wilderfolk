import type { DialogueTree } from './dialogueTrees';
import { TICKS_PER_HOUR } from './dayCycleClock';
import type { Season, WeatherType } from './gameTypes';

export type HumanChatContext =
  | 'social'
  | 'home'
  | 'courtship'
  | 'work'
  | 'visitor'
  | 'rival'
  | 'hunt'
  | 'child'
  | 'school'
  | 'pregnant'
  | 'affair'
  | 'sleep'
  | 'renffr'
  | 'fear'
  | 'winter'
  | 'festival'
  | 'guard'
  | 'food'
  | 'election';

export interface ChatPickOptions {
  season?: Season;
  weather?: WeatherType;
  festivalActive?: boolean;
  foodLow?: boolean;
}

export interface ChatWorldHints {
  season?: Season;
  weather?: WeatherType;
  festivalActive?: boolean;
  food?: number;
}

export type ChatSpeaker = {
  id: number;
  chatPhrase?: string;
  chatTicks?: number;
  chatPartnerId?: number;
  chatDialogueSessionKey?: string;
  dialogueRecentScenes?: Record<string, { id: string; tick: number }>;
  dialogueRecentLines?: Record<string, number>;
  isJuvenile?: boolean;
  name?: string;
  /** Read-only contextual eligibility hints, supplied by the real Entity. */
  pregnant?: boolean;
  partnerId?: number;
  childrenIds?: readonly number[];
  residenceBuildingId?: number;
};

/** A participant is busy while either a visible line or paired dialogue session is active. */
export function isDialogueBusy(entity: Pick<ChatSpeaker, 'chatTicks' | 'chatDialogueSessionKey'>): boolean {
  return (entity.chatTicks ?? 0) > 0 || entity.chatDialogueSessionKey != null;
}

/** A spoken tree line remains visible for roughly 2.5–5 game hours. */
export const DIALOGUE_LINE_BASE_HOURS = 2.5;
export const DIALOGUE_LINE_CHAR_HOURS = 0.08;
export const CHAT_BUBBLE_MAX_CHARS_PER_LINE = 38;
export const CHAT_BUBBLE_MAX_LINES = 3;

interface DialogueSession {
  tree: DialogueTree;
  step: number;
  entityAId: number;
  entityBId: number;
  entityARef: ChatSpeaker;
  entityBRef: ChatSpeaker | null;
  solo: boolean;
  durationHours?: number;
}

const dialogueSessions = new Map<string, DialogueSession>();

export function chatHintsFromWorld(world: ChatWorldHints): ChatPickOptions {
  return {
    season: world.season,
    weather: world.weather,
    festivalActive: world.festivalActive,
    foodLow: (world.food ?? 99) < 12,
  };
}

export function wrapChatLines(
  text: string,
  maxCharsPerLine = CHAT_BUBBLE_MAX_CHARS_PER_LINE,
  maxLines = CHAT_BUBBLE_MAX_LINES,
): string[] {
  const words = text.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return ['…'];

  const lines: string[] = [];
  let current = '';
  
  for (const word of words) {
    // If adding this word exceeds the line limit, push the current line
    if (current && (current.length + 1 + word.length > maxCharsPerLine)) {
      lines.push(current);
      if (lines.length >= maxLines) {
        // We've hit the max lines, append ellipsis to the last added line
        const last = lines[lines.length - 1];
        lines[lines.length - 1] = last.slice(0, maxCharsPerLine - 1) + '…';
        return lines;
      }
      current = word;
    } else {
      // Add to current line
      current = current ? `${current} ${word}` : word;
    }
  }

  // Push any remaining text
  if (current) {
    if (lines.length < maxLines) {
      lines.push(current);
    } else {
      // If we already have maxLines, append to the last one with ellipsis
      const last = lines[lines.length - 1];
      lines[lines.length - 1] = last.slice(0, maxCharsPerLine - 1) + '…';
    }
  }

  return lines.length > 0 ? lines : ['…'];
}

/** Flatten wrapped lines for storage in chatPhrase (renderer splits on newline). */
export function formatChatLine(line: string, speaker?: Pick<ChatSpeaker, 'name'>): string {
  const firstName = speaker?.name?.split(/\s+/)[0] ?? 'friend';
  const substituted = line.replace(/\{name\}/g, firstName);
  return wrapChatLines(substituted).join('\n');
}

export function ticksForDialogueLine(text: string): number {
  const durationHours = DIALOGUE_LINE_BASE_HOURS + text.length * DIALOGUE_LINE_CHAR_HOURS;
  return Math.max(TICKS_PER_HOUR, Math.round(durationHours * TICKS_PER_HOUR));
}

function sessionKeyFor(aId: number, bId: number): string {
  const lo = Math.min(aId, bId);
  const hi = Math.max(aId, bId);
  return `${lo}:${hi}`;
}

function clearEntityChat(entity: ChatSpeaker): void {
  entity.chatTicks = undefined;
  entity.chatPhrase = undefined;
}

/** Release a live session and both of its attached participants immediately. */
export function releaseDialogueSession(entity: ChatSpeaker): void {
  const key = entity.chatDialogueSessionKey;
  if (!key) return;
  clearDialogueSession(key, entity);
}

function clearDialogueSession(key: string, entityA?: ChatSpeaker, entityB?: ChatSpeaker): void {
  const session = dialogueSessions.get(key);
  dialogueSessions.delete(key);
  for (const participant of [entityA, entityB, session?.entityARef, session?.entityBRef]) {
    if (!participant || participant.chatDialogueSessionKey !== key) continue;
    participant.chatDialogueSessionKey = undefined;
    participant.chatPartnerId = undefined;
    clearEntityChat(participant);
  }
}

function resolveSessionEntities(
  entity: ChatSpeaker,
  resolvePartner: (id: number) => ChatSpeaker | null | undefined,
): { session: DialogueSession; self: ChatSpeaker; partner: ChatSpeaker | null } | null {
  const key = entity.chatDialogueSessionKey;
  if (!key) return null;
  const session = dialogueSessions.get(key);
  if (!session) return null;

  const partnerId = entity.chatPartnerId;
  const partner = partnerId != null ? resolvePartner(partnerId) ?? null : null;
  
  // If non-solo and partner is missing, clean up
  if (!session.solo && !partner) {
    clearDialogueSession(key, entity, undefined);
    return null;
  }

  const self = entity;
  if (session.solo) return { session, self, partner: null };
  return { session, self, partner };
}

function showDialogueStep(
  tree: DialogueTree,
  step: number,
  entityA: ChatSpeaker,
  entityB: ChatSpeaker | null,
  solo: boolean,
  durationHours?: number,
): void {
  const line = tree.lines[step];
  if (!line) return;

  const ticks = durationHours === undefined ? ticksForDialogueLine(line.text) : Math.max(4, Math.round(durationHours * TICKS_PER_HOUR));
  const formatted = formatChatLine(line.text);

  if (solo || !entityB) {
    clearEntityChat(entityB ?? entityA);
    entityA.chatPhrase = formatted;
    entityA.chatTicks = ticks;
    return;
  }

  const role = line.speaker === tree.speakers[0] ? 0 : 1;
  const active = role === 0 ? entityA : entityB;
  const idle = role === 0 ? entityB : entityA;
  
  // Clear the idle participant so they don't show two bubbles
  clearEntityChat(idle);
  
  active.chatPhrase = formatChatLine(line.text, active);
  active.chatTicks = ticks;
}

export function startDialogueTreeChat(
  entityA: ChatSpeaker,
  entityB: ChatSpeaker | null,
  tree: DialogueTree,
  solo = false,
  durationHours?: number,
): void {
  // `isDialogueBusy`, not a raw `chatTicks` read: a participant is busy while either a visible line
  // *or* a paired session is live, and `showDialogueStep` clears the idle half's line while keeping its
  // session key. The raw test therefore read the idle half as free, and `entityB.chatDialogueSessionKey
  // = key` below overwrote an in-flight partner's key — one settler speaking two dialogue trees at once
  // while the old session entry stayed live. `isDialogueBusy` is the
  // contract `tests/socialLife.dialogueBusy.test.ts` pins.
  if (isDialogueBusy(entityA)) return;
  if (!solo && entityB && isDialogueBusy(entityB)) return;

  const key = solo || !entityB
    ? `solo:${entityA.id}`
    : sessionKeyFor(entityA.id, entityB.id);

  if (dialogueSessions.has(key)) return;

  dialogueSessions.set(key, {
    tree,
    step: 0,
    entityAId: entityA.id,
    entityBId: entityB?.id ?? entityA.id,
    entityARef: entityA,
    entityBRef: entityB,
    solo: solo || !entityB,
    durationHours,
  });

  entityA.chatDialogueSessionKey = key;
  entityA.chatPartnerId = entityB?.id;
  if (entityB) {
    entityB.chatDialogueSessionKey = key;
    entityB.chatPartnerId = entityA.id;
  }

  showDialogueStep(tree, 0, entityA, entityB, solo || !entityB, durationHours);
}

/** Solo scenes can finish without a world/entity resolver (e.g. headless tests). */
const NO_CHAT_PARTNER = (_id: number): null => null;

function resolveSessionSpeaker(
  entityId: number,
  self: ChatSpeaker,
  partner: ChatSpeaker | null,
): ChatSpeaker | null {
  if (self.id === entityId) return self;
  if (partner?.id === entityId) return partner;
  return null;
}

function advanceDialogue(
  entity: ChatSpeaker,
  resolvePartner: (id: number) => ChatSpeaker | null | undefined,
): boolean {
  const resolved = resolveSessionEntities(entity, resolvePartner);
  if (!resolved) return false;

  const { session, self, partner } = resolved;
  const tree = session.tree;
  const sessionKey = self.chatDialogueSessionKey!;
  
  if (!session.solo && !partner) {
    clearDialogueSession(sessionKey, self, undefined);
    return false;
  }

  const entityA = resolveSessionSpeaker(session.entityAId, self, partner) ?? self;
  const entityB = session.solo
    ? null
    : resolveSessionSpeaker(session.entityBId, self, partner);
    
  if (!session.solo && !entityB) {
    clearDialogueSession(sessionKey, entityA, undefined);
    return false;
  }

  const nextStep = session.step + 1;
  if (nextStep >= tree.lines.length) {
    clearDialogueSession(sessionKey, entityA, entityB ?? undefined);
    return true;
  }

  session.step = nextStep;
  showDialogueStep(tree, nextStep, entityA, entityB, session.solo, session.durationHours);
  return true;
}

/** Scripted speech interrupts the current session and frees both participants. */
export function prepareScriptedDialogue(
  entity: ChatSpeaker,
  resolvePartner?: (id: number) => ChatSpeaker | null | undefined,
): void {
  const key = entity.chatDialogueSessionKey;
  if (key) {
    const session = dialogueSessions.get(key);
    const otherId = session
      ? (session.entityAId === entity.id ? session.entityBId : session.entityAId)
      : entity.chatPartnerId;
    const other = otherId != null ? resolvePartner?.(otherId) ?? undefined : undefined;
    clearDialogueSession(key, entity, other);
  }
  entity.chatDialogueSessionKey = undefined;
  entity.chatPartnerId = undefined;
  clearEntityChat(entity);
}

export function tickHumanChat(
  entity: ChatSpeaker,
  resolvePartner?: (id: number) => ChatSpeaker | null | undefined,
): void {
  // Reclaim an orphaned session key FIRST, before the visible-line gate below.
  //
  // The key is what `isDialogueBusy` reads, and the only place it used to be released sat behind
  // `if (!entity.chatTicks) return;` — unreachable for the *idle* half of a pair, whose visible line
  // was already cleared by `showDialogueStep`. `resetDialogueSessions()` empties the map on every
  // renderer-cache reset (boot, and every session swap), so a save/load during a paired dialogue
  // stranded that settler: `resolveSessionEntities` returns null on a missing entry, so it could never
  // advance, and it stayed excluded from greetings, workplace banter and ambient pairing until it
  // happened to speak a solo line.
  const orphanKey = entity.chatDialogueSessionKey;
  if (orphanKey && !dialogueSessions.has(orphanKey)) {
    entity.chatDialogueSessionKey = undefined;
    entity.chatPartnerId = undefined;
    clearEntityChat(entity);
    return;
  }

  if (!entity.chatTicks || entity.chatTicks <= 0) return;
  entity.chatTicks--;
  if (entity.chatTicks > 0) return;

  if (entity.chatDialogueSessionKey) {
    // Solo lines must advance/finish even when no external partner resolver exists.
    // Paired sessions still require the real resolver; do not invent a partner.
    const key = entity.chatDialogueSessionKey;
    const session = dialogueSessions.get(key);
    const advanced = (resolvePartner || session?.solo)
      ? advanceDialogue(entity, resolvePartner ?? NO_CHAT_PARTNER)
      : false;
    if (advanced) return;
    // `advanceDialogue` returning false means the session is gone (a forced phrase reclaimed it, or the
    // partner vanished). Release both halves, not just this one.
    const goneKey = entity.chatDialogueSessionKey;
    if (goneKey && !dialogueSessions.has(goneKey)) {
      const partnerId = entity.chatPartnerId;
      const counterpart = partnerId != null ? resolvePartner?.(partnerId) ?? undefined : undefined;
      clearDialogueSession(goneKey, entity, counterpart);
      if (counterpart) clearEntityChat(counterpart);
    }
  }

  clearEntityChat(entity);
}

/**
 * Ends an ordinary (non-dialogue) chat because the settler has gone home for the
 * night. Returns true when something was actually cleared.
 *
 * A scripted dialogue session is deliberately left alone: the dialogue tree owns it,
 * not the sleep schedule, and ending it here would cut a story beat mid-line. Only the
 * ambient chatter — which used to follow a settler indoors and put a speech bubble over
 * somebody in bed — is stopped.
 */
export function endAmbientHumanChat(entity: ChatSpeaker): boolean {
  if (entity.chatDialogueSessionKey) return false;
  if ((entity.chatTicks ?? 0) <= 0 && entity.chatPhrase == null) return false;
  clearEntityChat(entity);
  entity.chatPartnerId = undefined;
  return true;
}

export function getAnimatedChatDots(tick: number, entityId: number): string {
  const phase = (Math.floor(tick / 4) + entityId) % 3;
  return '.'.repeat(phase + 1);
}

export function getChatBubbleText(
  entity: Pick<ChatSpeaker, 'chatPhrase' | 'chatTicks' | 'id'>,
  tick: number,
): string {
  const talking = (entity.chatTicks ?? 0) > 0;
  if (!talking) return '';
  // Prefer stored tree line; only animate dots if phrase was lost in transfer.
  const phrase = entity.chatPhrase?.trim();
  if (phrase) return phrase;
  return getAnimatedChatDots(tick, entity.id);
}

export function resetDialogueSessions(): void {
  dialogueSessions.clear();
}

/**
 * Remove a dead/despawned entity's dialogue session and clear its chat state.
 *
 * The counterpart is released explicitly when a resolver is supplied. The old comment here claimed the
 * partner's "next tick … clean itself up" — that was false for the idle half, whose `chatTicks` is 0, so
 * `tickHumanChat` returned before it could reclaim anything and the survivor stayed dialogue-busy on a
 * session with no owner. The hoisted reclaim there now catches the case
 * even without a resolver; passing one releases the partner immediately instead of a tick later.
 */
export function cleanupEntityDialogueState(
  entity: ChatSpeaker,
  resolvePartner?: (id: number) => ChatSpeaker | null | undefined,
): void {
  const key = entity.chatDialogueSessionKey;
  if (key) {
    const session = dialogueSessions.get(key);
    const counterpartId = session
      ? (session.entityAId === entity.id ? session.entityBId : session.entityAId)
      : entity.chatPartnerId;
    const counterpart =
      counterpartId != null ? resolvePartner?.(counterpartId) ?? undefined : undefined;
    clearDialogueSession(key, entity, counterpart);
    if (counterpart) clearEntityChat(counterpart);
  }
  entity.chatDialogueSessionKey = undefined;
  entity.chatPartnerId = undefined;
  clearEntityChat(entity);
}