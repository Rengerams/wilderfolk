import type { Entity, WorldState } from './gameTypes';
import { JobType } from './gameTypes';
import { evaluateTraitInfluence } from './personality/traitEvaluation';
import { logEvent } from './eventLog';
import { playerHumansFrom } from './playerHuman';
import { getSimRng } from './simRng';
import { adjustHumanStaminaFromEnergy } from './simulation/humanPhysiology';
import { RELATIONSHIP_REVISION, bumpRevision } from './entityRevision';

 const FRIEND_PREFIX = 'friend_';
const FEUD_PREFIX = 'feud_';

const RELATIONSHIP_RNG_OWNER = 'relationships';

export const FRIEND_CLOSE_THRESHOLD = 60;

const friendKey = (id: number) => `${FRIEND_PREFIX}${id}`;
const feudKey = (id: number) => `${FEUD_PREFIX}${id}`;

const hasOwn = (obj: object, key: string) => Object.prototype.hasOwnProperty.call(obj, key);

const GROUP_SAMPLE_SIZE = 40;

const FEUD_ROLL_BUDGET = 20_000;

const MAX_LIVE_FEUDS_PER_SETTLER = 3;

export const MAX_CLOSE_FRIENDS_PER_SETTLER = 6;

const FRIENDSHIP_GROUP_BUMP = 0.6;
const FRIENDSHIP_CHILDHOOD_BUMP = 0.3;
export const FRIENDSHIP_DECAY_PER_DAY = 0.1;

const FEUD_DECAY_PER_DAY = 0.4;
const FEUD_ENERGY_DRAIN = 0.15;
const FEUD_BREWING_THRESHOLD = 30;

const INCOMPATIBLE_PAIR_FEUD_CHANCE_PER_DAY = 0.00005;
const INCOMPATIBLE_PAIR_FEUD_AMOUNT = 30;

function tradeOf(e: Entity): Entity['job'] | null {
  return e.job && e.job !== JobType.Settler ? e.job : null;
}

function sharesContext(a: Entity, b: Entity): boolean {
  if (a.residenceBuildingId != null && a.residenceBuildingId === b.residenceBuildingId) return true;
  if (a.workerBuildingId != null && a.workerBuildingId === b.workerBuildingId) return true;
  const trade = tradeOf(a);
  if (trade != null && trade === tradeOf(b)) return true;
  if (a.childhoodFriendsIds?.includes(b.id) || b.childhoodFriendsIds?.includes(a.id)) return true;
  return false;
}

function sampleGroup(group: Entity[], rng: () => number): Entity[] {
  if (group.length <= GROUP_SAMPLE_SIZE) return group;
  const offset = Math.floor(rng() * group.length);
  const out = new Array<Entity>(GROUP_SAMPLE_SIZE);
  for (let k = 0; k < GROUP_SAMPLE_SIZE; k++) out[k] = group[(offset + k) % group.length];
  return out;
}

function pushToGroup<K>(groups: Map<K, Entity[]>, key: K, e: Entity): void {
  const arr = groups.get(key);
  if (arr) arr.push(e);
  else groups.set(key, [e]);
}

export function friendshipScore(e: Entity, otherId: number): number {
  return e.friendships?.[friendKey(otherId)] ?? 0;
}

export function feudScore(e: Entity, otherId: number): number {
  return e.feuds?.[feudKey(otherId)] ?? 0;
}

function hurtFriendshipRecord(entity: Entity, key: string, amount: number): void {
  const next = writableFriendships(entity);
  next[key] = Math.max(0, (next[key] ?? 0) - amount);
}

export function hurtFriendship(a: Entity, b: Entity, amount: number): void {
  if (a.id === b.id || amount <= 0) return;
  hurtFriendshipRecord(a, friendKey(b.id), amount);
  hurtFriendshipRecord(b, friendKey(a.id), amount);
}

/** Replace a record before an in-place edit, so the rollback snapshot keeps the old object. */
function writableFriendships(entity: Entity): Record<string, number> {
  const next = { ...(entity.friendships ?? {}) };
  entity.friendships = next;
  bumpRevision(entity, RELATIONSHIP_REVISION);
  return next;
}

function writableFeuds(entity: Entity): Record<string, number> {
  const next = { ...(entity.feuds ?? {}) };
  entity.feuds = next;
  bumpRevision(entity, RELATIONSHIP_REVISION);
  return next;
}

function writableFeudPeaks(entity: Entity): Record<string, number> {
  const next = { ...(entity.feudPeaks ?? {}) };
  entity.feudPeaks = next;
  bumpRevision(entity, RELATIONSHIP_REVISION);
  return next;
}

export function friendCount(e: Entity): number {
  if (!e.friendships) return 0;
  let count = 0;
  for (const val of Object.values(e.friendships)) {
    if (val >= FRIEND_CLOSE_THRESHOLD) count++;
  }
  return count;
}

/** Keep only the strongest MAX close bonds per settler; legacy saves can carry more than the cap. */
export function clampCloseFriendships(people: Entity[]): void {
  for (const person of people) {
    const friendships = person.friendships;
    if (!friendships) continue;
    let closeCount = 0;
    for (const key in friendships) {
      if (key.startsWith(FRIEND_PREFIX) && friendships[key] >= FRIEND_CLOSE_THRESHOLD) closeCount++;
    }
    if (closeCount <= MAX_CLOSE_FRIENDS_PER_SETTLER) continue;
    const close = Object.entries(friendships)
      .filter(([key, value]) => key.startsWith(FRIEND_PREFIX) && value >= FRIEND_CLOSE_THRESHOLD)
      .sort((a, b) => b[1] - a[1]);
    for (const [key, value] of close.slice(MAX_CLOSE_FRIENDS_PER_SETTLER)) {
      const next = writableFriendships(person);
      next[key] = Math.min(value, FRIEND_CLOSE_THRESHOLD - 1);
    }
  }
}

/** Repair close bonds in imported/legacy state without changing weaker acquaintances.
 * Strongest mutual friendships take priority; ties use stable settler IDs.
 */
export function reconcileCloseFriendships(people: Entity[]): void {
  const byId = new Map(people.map(person => [person.id, person]));
  const edges: Array<{ a: Entity; b: Entity; strength: number }> = [];
  for (const a of people) {
    for (const [key, value] of Object.entries(a.friendships ?? {})) {
      if (!key.startsWith(FRIEND_PREFIX) || !Number.isFinite(value) || value < FRIEND_CLOSE_THRESHOLD) continue;
      const otherId = Number(key.slice(FRIEND_PREFIX.length));
      const b = byId.get(otherId);
      if (!b || b.id <= a.id) continue;
      const reverse = friendshipScore(b, a.id);
      if (reverse < FRIEND_CLOSE_THRESHOLD) continue;
      edges.push({ a, b, strength: Math.min(value, reverse) });
    }
  }
  edges.sort((x, y) => y.strength - x.strength || x.a.id - y.a.id || x.b.id - y.b.id);
  const accepted = new Map<number, number>();
  const originallyMutual = new Set(edges.map(({ a, b }) => `${a.id}|${b.id}`));
  const retained = new Set<string>();
  for (const { a, b } of edges) {
    if ((accepted.get(a.id) ?? 0) >= MAX_CLOSE_FRIENDS_PER_SETTLER ||
        (accepted.get(b.id) ?? 0) >= MAX_CLOSE_FRIENDS_PER_SETTLER) continue;
    accepted.set(a.id, (accepted.get(a.id) ?? 0) + 1);
    accepted.set(b.id, (accepted.get(b.id) ?? 0) + 1);
    retained.add(`${a.id}|${b.id}`);
  }
  for (const a of people) {
    let closeCount = friendCount(a);
    for (const [key, value] of Object.entries(a.friendships ?? {})) {
      if (!key.startsWith(FRIEND_PREFIX) || value < FRIEND_CLOSE_THRESHOLD) continue;
      const otherId = Number(key.slice(FRIEND_PREFIX.length));
      const b = byId.get(otherId);
      if (!b || b.id === a.id) {
        if (b?.id === a.id) {
          const next = writableFriendships(a);
          delete next[key];
          closeCount -= 1;
        }
        continue;
      }
      const pair = a.id < b.id ? `${a.id}|${b.id}` : `${b.id}|${a.id}`;
      if (retained.has(pair)) continue;
      // A one-way imported bond below the ceiling is still a valid recorded
      // friendship. Only demote excess close bonds; the normal daily pass will
      // remove links to people who have actually died.
      if (!originallyMutual.has(pair) && closeCount < MAX_CLOSE_FRIENDS_PER_SETTLER) continue;
      // Drop just below the close-friend threshold, preserving acquaintance history.
      const next = writableFriendships(a);
      next[key] = Math.min(value, FRIEND_CLOSE_THRESHOLD - 1);
      closeCount -= 1;
    }
  }
}

export interface BondCensus {
  closeBonds: number;
  withFriend: number;
  isolated: number;
}

export function bondCensus(people: Entity[]): BondCensus {
  let closeBonds = 0;
  let withFriend = 0;
  for (const p of people) {
    let mine = 0;
    const friendships = p.friendships;
    if (friendships) {
      for (const key in friendships) {
        if (!hasOwn(friendships, key)) continue;
        if (friendships[key] < FRIEND_CLOSE_THRESHOLD) continue;
        mine += 1;
        const otherId = Number(key.substring(FRIEND_PREFIX.length));
        if (p.id < otherId) closeBonds += 1;
      }
    }
    if (mine > 0) withFriend += 1;
  }
  return { closeBonds, withFriend, isolated: people.length - withFriend };
}

export function activeFeudCount(e: Entity): number {
  if (!e.feuds) return 0;
  let count = 0;
  for (const val of Object.values(e.feuds)) {
    if (val > 0) count++;
  }
  return count;
}

export function advanceSocialRelationships(
  state: WorldState,
  allAlive: Entity[],
  peopleForPass?: Entity[],
  rng: () => number = getSimRng(RELATIONSHIP_RNG_OWNER),
): void {
  const people = peopleForPass ?? playerHumansFrom(allAlive);
  if (people.length < 2) return;
  reconcileCloseFriendships(people);

  const byId = new Map(people.map((e) => [e.id, e]));
  const aliveIds = new Set(allAlive.map((e) => e.id));

  const residenceGroups = new Map<number, Entity[]>();
  const workplaceGroups = new Map<number, Entity[]>();
  const jobGroups = new Map<string, Entity[]>();
  for (const p of people) {
    if (p.residenceBuildingId != null) pushToGroup(residenceGroups, p.residenceBuildingId, p);
    if (p.workerBuildingId != null) pushToGroup(workplaceGroups, p.workerBuildingId, p);
    const trade = tradeOf(p);
    if (trade != null) pushToGroup(jobGroups, trade, p);
  }

  const pairKey = (a: number, b: number) => (a < b ? `${a}|${b}` : `${b}|${a}`);

  const bumpedPairs = new Set<string>();
  const feudRolledPairs = new Set<string>();
  let feudRollsLeft = FEUD_ROLL_BUDGET;

  /** One copy-on-write clone per settler per pass; a replaced map is re-cloned on demand. */
  const bumpedFriendships = new Map<Entity, Record<string, number>>();
  const writableForBump = (entity: Entity): Record<string, number> => {
    let map = bumpedFriendships.get(entity);
    if (!map || map !== entity.friendships) {
      map = writableFriendships(entity);
      bumpedFriendships.set(entity, map);
    }
    return map;
  };

  const liveFeudsById = new Map<number, number>();
  const closeFriendsById = new Map<number, number>();
  for (const p of people) {
    const feuds = activeFeudCount(p);
    if (feuds > 0) liveFeudsById.set(p.id, feuds);
    const friends = friendCount(p);
    if (friends > 0) closeFriendsById.set(p.id, friends);
  }

  const bumpFriendship = (a: Entity, b: Entity, amt: number) => {
    if (a.id === b.id) return;
    const key = pairKey(a.id, b.id);
    if (bumpedPairs.has(key)) return;
    bumpedPairs.add(key);

    if (feudScore(a, b.id) > 0) return;

    const before = friendshipScore(a, b.id);
    const next = Math.min(100, before + amt);
    if (before < FRIEND_CLOSE_THRESHOLD && next >= FRIEND_CLOSE_THRESHOLD) {
      if ((closeFriendsById.get(a.id) ?? 0) >= MAX_CLOSE_FRIENDS_PER_SETTLER) return;
      if ((closeFriendsById.get(b.id) ?? 0) >= MAX_CLOSE_FRIENDS_PER_SETTLER) return;
      closeFriendsById.set(a.id, (closeFriendsById.get(a.id) ?? 0) + 1);
      closeFriendsById.set(b.id, (closeFriendsById.get(b.id) ?? 0) + 1);
    }

    const aFriendships = writableForBump(a);
    const bFriendships = writableForBump(b);
    aFriendships[friendKey(b.id)] = next;
    bFriendships[friendKey(a.id)] = next;
  };

  const driftIntoFeud = (a: Entity, b: Entity) => {
    if (a.id === b.id || feudRollsLeft <= 0) return;
    const key = pairKey(a.id, b.id);
    if (feudRolledPairs.has(key)) return;
    feudRolledPairs.add(key);
    feudRollsLeft--;

    if (feudScore(a, b.id) > 0) return;
    if ((liveFeudsById.get(a.id) ?? 0) >= MAX_LIVE_FEUDS_PER_SETTLER) return;
    if ((liveFeudsById.get(b.id) ?? 0) >= MAX_LIVE_FEUDS_PER_SETTLER) return;

    const clashes = evaluateTraitInfluence(a, { kind: 'social', activity: 'feudClash', other: b }).exact.clashCount;
    if (clashes === 0) return;
    if (rng() >= clashes * INCOMPATIBLE_PAIR_FEUD_CHANCE_PER_DAY) return;

    startFeud(state, a, b, INCOMPATIBLE_PAIR_FEUD_AMOUNT);
    liveFeudsById.set(a.id, (liveFeudsById.get(a.id) ?? 0) + 1);
    liveFeudsById.set(b.id, (liveFeudsById.get(b.id) ?? 0) + 1);
  };

  for (const group of [...residenceGroups.values(), ...workplaceGroups.values(), ...jobGroups.values()]) {
    if (group.length < 2) continue;
    const sample = sampleGroup(group, rng);
    for (let i = 0; i < sample.length; i++) {
      for (let j = i + 1; j < sample.length; j++) {
        bumpFriendship(sample[i], sample[j], FRIENDSHIP_GROUP_BUMP);
        driftIntoFeud(sample[i], sample[j]);
      }
    }
  }

  for (const p of people) {
    for (const fId of p.childhoodFriendsIds ?? []) {
      const f = byId.get(fId);
      if (f) bumpFriendship(p, f, FRIENDSHIP_CHILDHOOD_BUMP);
    }
  }

  /** One copy-on-write clone per settler and field per pass; a replaced map re-clones. */
  type RelationshipField = 'friendships' | 'feuds' | 'feudPeaks';
  const decayMaps = new Map<Entity, Partial<Record<RelationshipField, Record<string, number>>>>();
  const mapForDecay = (entity: Entity, field: RelationshipField): Record<string, number> => {
    let entry = decayMaps.get(entity);
    if (!entry) {
      entry = {};
      decayMaps.set(entity, entry);
    }
    let map = entry[field];
    if (!map || map !== entity[field]) {
      map = field === 'friendships'
        ? writableFriendships(entity)
        : field === 'feuds'
          ? writableFeuds(entity)
          : writableFeudPeaks(entity);
      entry[field] = map;
    }
    return map;
  };

  for (const p of people) {
    const feuds = p.feuds;
    if (!feuds) continue;

    for (const key in feuds) {
      if (!hasOwn(feuds, key)) continue;
      const otherId = Number(key.substring(FEUD_PREFIX.length));
      if (Number.isNaN(otherId)) continue;

      const other = byId.get(otherId);
      if (!other) {
        if (!aliveIds.has(otherId)) {
          delete mapForDecay(p, 'feuds')[key];
          if (p.feudPeaks) delete mapForDecay(p, 'feudPeaks')[key];
        }
        continue;
      }

      const otherKey = feudKey(p.id);

      if (p.id > otherId) {
        if (!other.feuds || !hasOwn(other.feuds, otherKey)) {
          mapForDecay(other, 'feuds')[otherKey] = feuds[key];
        }
        continue;
      }

      const next = Math.max(0, feuds[key] - FEUD_DECAY_PER_DAY);

      if (next <= 0) {
        const peak = Math.max(p.feudPeaks?.[key] ?? 0, other.feudPeaks?.[otherKey] ?? 0);
        delete mapForDecay(p, 'feuds')[key];
        if (other.feuds) {
          const otherFeuds = mapForDecay(other, 'feuds');
          if (otherKey in otherFeuds) delete otherFeuds[otherKey];
        }
        if (p.feudPeaks) delete mapForDecay(p, 'feudPeaks')[key];
        if (other.feudPeaks) {
          const otherPeaks = mapForDecay(other, 'feudPeaks');
          if (otherKey in otherPeaks) delete otherPeaks[otherKey];
        }

        // A feud announced when it crossed the brewing threshold is announced when it ends:
        // the drift feud peaks at exactly that threshold, so this is the pair to the start line.
        if (peak >= FEUD_BREWING_THRESHOLD) {
          logEvent(state, 'event', `${p.name ?? 'A settler'} and ${other.name ?? 'another settler'} have settled their feud`);
        }
      } else {
        mapForDecay(p, 'feuds')[key] = next;
        mapForDecay(other, 'feuds')[otherKey] = next;

        adjustHumanStaminaFromEnergy(p, -FEUD_ENERGY_DRAIN);
        adjustHumanStaminaFromEnergy(other, -FEUD_ENERGY_DRAIN);
      }
    }
  }

  for (const p of people) {
    const friendships = p.friendships;
    if (!friendships) continue;

    for (const key in friendships) {
      if (!hasOwn(friendships, key)) continue;
      const otherId = Number(key.substring(FRIEND_PREFIX.length));
      if (Number.isNaN(otherId)) continue;

      const other = byId.get(otherId);
      if (!other) {
        if (!aliveIds.has(otherId)) delete mapForDecay(p, 'friendships')[key];
        continue;
      }
      if (p.id > otherId) continue;
      if (sharesContext(p, other)) continue;

      const next = Math.max(0, friendships[key] - FRIENDSHIP_DECAY_PER_DAY);
      const otherKey = friendKey(p.id);
      if (next <= 0) {
        delete mapForDecay(p, 'friendships')[key];
        if (other.friendships) {
          const otherFriendships = mapForDecay(other, 'friendships');
          if (otherKey in otherFriendships) delete otherFriendships[otherKey];
        }
      } else {
        mapForDecay(p, 'friendships')[key] = next;
        mapForDecay(other, 'friendships')[otherKey] = next;
      }
    }
  }

  for (const p of people) {
    const strongCount = friendCount(p);
    if (strongCount === 0) continue;
    const boost = Math.min(2, strongCount * 0.8);
    adjustHumanStaminaFromEnergy(p, boost);
  }
}

export function startFeud(state: WorldState, wronged: Entity, wrongdoer: Entity, amount = 25): void {
  if (wronged.id === wrongdoer.id) return;

  const wrongedFeuds = writableFeuds(wronged);
  const wrongdoerFeuds = writableFeuds(wrongdoer);
  const wrongedPeaks = writableFeudPeaks(wronged);
  const wrongdoerPeaks = writableFeudPeaks(wrongdoer);

  const wrongedKey = feudKey(wrongdoer.id);
  const wrongdoerKey = feudKey(wronged.id);

  const wrongedBefore = wrongedFeuds[wrongedKey] ?? 0;
  const wrongdoerBefore = wrongdoerFeuds[wrongdoerKey] ?? 0;

  const newWrongedScore = Math.min(100, wrongedBefore + amount);
  const newWrongdoerScore = Math.min(100, wrongdoerBefore + amount);

  wrongedFeuds[wrongedKey] = newWrongedScore;
  wrongdoerFeuds[wrongdoerKey] = newWrongdoerScore;

  wrongedPeaks[wrongedKey] = Math.max(wrongedPeaks[wrongedKey] ?? 0, newWrongedScore);
  wrongdoerPeaks[wrongdoerKey] = Math.max(wrongdoerPeaks[wrongdoerKey] ?? 0, newWrongdoerScore);

  hurtFriendship(wronged, wrongdoer, amount);

  if (wrongedBefore < FEUD_BREWING_THRESHOLD && newWrongedScore >= FEUD_BREWING_THRESHOLD) {
    logEvent(state, 'scandal', `A feud is brewing between ${wronged.name ?? 'a settler'} and ${wrongdoer.name ?? 'another settler'}`);
  }
}